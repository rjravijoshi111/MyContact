import React, { Component } from 'react';
import { Provider } from 'react-redux';
import ReduxNavigation from "./ReduxNavigation";
import { store } from './reducers';
import { Root,StyleProvider } from "native-base";
import getTheme from './theme/components';
import commonColor from './theme/variables/commonColor';

class App extends Component {

    constructor(props){
        super(props);
        
        if (__DEV__) {
            global.XMLHttpRequest = global.originalXMLHttpRequest ?
                global.originalXMLHttpRequest :
                global.XMLHttpRequest;
            global.FormData = global.originalFormData ?
                global.originalFormData :
                global.FormData;
            global.Blob = global.originalBlob ?
                global.originalBlob :
                global.Blob;
            global.FileReader = global.originalFileReader ?
                global.originalFileReader :
                global.FileReader;
        }
    }

    render() {

        return (
            <StyleProvider style={getTheme(commonColor)}>
            <Root>
                <Provider store={store}>
                    <ReduxNavigation />
                </Provider>
            </Root>
            </StyleProvider>
        );
    }
}

export default App;

