module.exports = {
    BASE_URL : "http://18b9cw0ehqksx6e9.azurewebsites.net/api/",
    SERVICEVERSION : "1.5.0",
    API : {
        LOGIN: "login",
    },
}  