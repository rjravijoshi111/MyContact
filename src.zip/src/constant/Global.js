const globals = {
    sample_url : "https://www.gstatic.com/webp/gallery/1.webp",
}
export default globals; 
