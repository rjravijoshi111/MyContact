import React from "react";
import { BackHandler, View, Dimensions } from "react-native";
import { connect } from "react-redux";
import { NavigationActions } from "react-navigation";
import { SkypeIndicator } from 'react-native-indicators';
import { App } from "./reducers";
const { height, width } = Dimensions.get("window");

class ReduxNavigation extends React.Component {
    componentDidMount() {
        BackHandler.addEventListener("hardwareBackPress", this.onBackPress);
    }

    componentWillUnmount() {
        BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
    }

    onBackPress = () => {
        const { nav, dispatch } = this.props;
        if (nav.index === 0) {
            return false;
        }
        dispatch(NavigationActions.back());
        return true;
    };

    render() {
        const { nav, dispatch } = this.props;

        return (
            <View style={{flex:1}}>
                <App state={nav} dispatch={dispatch} />
                {this.props.isLoading && <View style={{height,width, backgroundColor:"rgba(0,0,0,0.4)",alignItems:'center',justifyContent:'center',position:'absolute',zIndex:1}}>
                    <SkypeIndicator color='white' animating={this.props.isLoading} size={40} />
                </View>}
            </View>
        );
    }
}

const mapStateToProps = state => ({
    nav: state.nav,
    isLoading: state.auth.isLoading
});

export default connect(mapStateToProps)(ReduxNavigation);