import { combineReducers } from 'redux';
import {
    createNavigationReducer
} from "react-navigation-redux-helpers";
import auth from '../modules/auth/auth.reducer';
import profile from '../modules/profile/profile.reducer';
import settings from '../modules/settings/settings.reducer';
import home from '../modules/home/home.reducer';
import myRoute from '../modules/myRoute/myRoute.reducer';
import error from '../modules/errors/error.reducer';

import SelectRoleReducer from '../modules/selectRole/role.reducer';
import MyCredit from '../modules/myCredit/myCredit.reducer';
import Navigator from '../components/navigation';
const navReducer = createNavigationReducer(Navigator);

const rootReducer = combineReducers({
    error:error,
    auth: auth,
    nav: navReducer,
    profile:profile,
    settings:settings,
    home:home,
    myRoute:myRoute,
    role:SelectRoleReducer,
    myCredit:MyCredit
});

export default rootReducer;