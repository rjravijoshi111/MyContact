import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import {
    reduxifyNavigator,
    createReactNavigationReduxMiddleware,
    createReduxContainer
} from "react-navigation-redux-helpers";
import rootReducer from './RootReducer';
import Navigator from '../components/navigation';

import logger from 'redux-logger';
import { jwt } from './Middleware';

// Note: createReactNavigationReduxMiddleware must be run before reduxifyNavigator
const middleware = createReactNavigationReduxMiddleware(
    state => state.nav
);

// export const App = reduxifyNavigator(Navigator, "root");
export const App = createReduxContainer(Navigator, "root")
const rootStore = createStore(rootReducer, applyMiddleware(jwt, thunk, logger,middleware));
export const store = rootStore;




