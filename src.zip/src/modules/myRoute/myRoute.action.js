export const START_POINT_ADDRESS = 'START_POINT_ADDRESS';
export const END_POINT_ADDRESS = 'END_POINT_ADDRESS';
export const START_POINT = 'START_POINT';
export const END_POINT = 'END_POINT';
export const ROUTE_NAME = 'ROUTE_NAME';
export const START_HOURS = 'START_HOURS';
export const DESIRE_STOP = 'DESIRE_STOP';
export const FREQUENCY_DAYS = 'FREQUENCY_DAYS';
export const CREATE_ROUTE_SUCCESS = 'CREATE_ROUTE_SUCCESS';

export const startPointAddressChanged = (text) => {
    return {
        type : START_POINT_ADDRESS,
        payload : text
    };
};

export const endPointAddressChanged = (text) => {
    return {
        type : END_POINT_ADDRESS,
        payload : text
    };
};

export const startPointChanged = (text) => {
    return {
        type : START_POINT,
        payload : text
    };
};

export const endPointChanged = (text) => {
    return {
        type : END_POINT,
        payload : text
    };
};

export const routeNameChanged = (text) => {
    return {
        type : ROUTE_NAME,
        payload : text
    };
};

export const startHoursChanged = (text) => {
    return {
        type : START_HOURS,
        payload : text
    };
};

export const desireStopChanged = (text) => {
    return {
        type : DESIRE_STOP,
        payload : text
    };
};

export const frequencyDaysChanged = (text) => {
    return {
        type : FREQUENCY_DAYS,
        payload : text
    };
};

export const createRouteSuccess = () => {
    return {
        type : CREATE_ROUTE_SUCCESS,
    };
};