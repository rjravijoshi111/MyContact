import { HttpPost, HttpGet } from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";
import APPCONSTATNT from '../../constant/appConstant';
class MyRouteApi {

    static createPath = async (data) => {
        console.log("Request Data-->",JSON.stringify(data))
        return await HttpPost(data, getApi('createRoute')).
            then(response => {
                return response;
            }).
            then(handleTokenErrors).
            catch(error => {
                throw error;
            });
    }
}

export default MyRouteApi;
