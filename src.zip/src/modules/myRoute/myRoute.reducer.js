import {
    START_POINT_ADDRESS,
    END_POINT_ADDRESS,
    START_POINT,
    END_POINT,
    ROUTE_NAME,
    START_HOURS,
    DESIRE_STOP,
    FREQUENCY_DAYS,
    CREATE_ROUTE_SUCCESS
} from './myRoute.action';

const INITIAL_STATE = {
    startPointAddress : '',
    endPointAddress : '',
    startPoint: {},
    endPoint: {},
    routeName: '',
    startHours : '',
    desireStop : '',
    frequencyDays : []
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case START_POINT_ADDRESS:
            return { ...state, startPointAddress: action.payload };
        case END_POINT_ADDRESS:
            return { ...state, endPointAddress: action.payload };
        case START_POINT:
            return { ...state, startPoint: action.payload };
        case END_POINT:
            return { ...state, endPoint: action.payload };
        case ROUTE_NAME:
            return { ...state, routeName: action.payload };
        case START_HOURS:
            return { ...state, startHours: action.payload };
        case DESIRE_STOP:
            return { ...state, desireStop: action.payload };
        case FREQUENCY_DAYS:
            return { ...state, frequencyDays: action.payload };
        case CREATE_ROUTE_SUCCESS:
            return { ...state, 
                startPointAddress : '',
                endPointAddress : '',
                startPoint: {},
                endPoint: {},
                routeName: '',
                startHours : '',
                desireStop : '',
                frequencyDays : [] 
            };
        default:
            return state;
    }
};
// Actions