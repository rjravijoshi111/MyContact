import {  } from 'react-native';
import MyRouteApi from './myRoute.api';
import { asyncError, generalError } from '../errors/error.service';
import * as AuthAction from '../auth/auth.action';
import * as MyRouteAction from './myRoute.action';
import {Toast} from "native-base";
import {NavigationActions} from "react-navigation";
import {getProfileData, getEmergancyContact} from '../profile/profile.service';
import Storage from "../utils/Storage";
import { API } from '../utils/api';
import AsyncStorage from '@react-native-community/async-storage';
import decodePolyline from 'decode-google-map-polyline';
export const TAG = "== auth.service.js :"

export const createRoute = (payload,_this) => async dispatch => {
    dispatch(AuthAction.setAuthPending());
    dispatch(AuthAction.setLoadingIndicator(true));
    let route = await getDirections(payload.start.latitude+","+payload.start.longitude,payload.end.latitude+","+payload.end.longitude)
    if(route == null){
        _this.awesomAlert.simpleAlert("", "No Route Found. Please enter diffrent routes.",() => {
            dispatch(AuthAction.setLoadingIndicator(false));
        })
        return null
    }
    payload["route"] = route;
    console.log("route-->",JSON.stringify(route));
	return MyRouteApi.createPath(payload)
		.then(response => {
            dispatch(AuthAction.setLoadingIndicator(false));
            console.log("Response-->",JSON.stringify(response));
            if(response.code == 1002){
                _this.awesomAlert.simpleAlert("", "Create Route sucessfully", () => {
                    dispatch(MyRouteAction.createRouteSuccess());
                    _this.props.navigation.goBack();
                })
            }else{
                Alert.simpleAlert("", response.messages[response.messages.length-1], () => {})
            }
		})
		.catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
			dispatch(generalError(error));
		});
};

const getDirections = (startLoc, destinationLoc) => {
    return new Promise( async function(resolve, reject) {
        try {
            let resp = await fetch(`https://maps.googleapis.com/maps/api/directions/json?origin=${ startLoc }&destination=${ destinationLoc }&key=AIzaSyBqQU0jRa-gINTA6T8Q-Dik4N0qFQSHvqM&sensor=false&mode=driving&alternatives=false`)
            let respJson = await resp.json();
            console.log("respJson-->",JSON.stringify(respJson))
            if(respJson.status != "ZERO_RESULTS"){
                let points = decodePolyline(respJson.routes[0].overview_polyline.points);
                let coords = points.map((point, index) => {
                    return  {
                        latitude : point.lat,
                        longitude : point.lng
                    }
                })
                resolve(coords)
            }else{
                resolve(null)
                reject("No Route Found")
            }
        } catch(error) {
            reject(error)
        }
    })
}