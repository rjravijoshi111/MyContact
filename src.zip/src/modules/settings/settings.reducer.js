import {
    OLD_PASSWORD_CHANGED,
    NEW_PASSWORD_CHANGED,
    NEW_PASSWORD_REPEAT_CHANGED,
    PASSWORD_CHANGE_SUCCESS,
    PASSWORD_CHANGE_FAIL,
    PUSH_NOTIFICATION,
    EMAIL_NOTIFICATION,
    NEWS_LETTERS
} from './settings.action';

const INITIAL_STATE = {
    old_password: '',
    new_password: '',
    new_password_repeat:'',
    push_notification : 0,
    email_notification : 0,
    news_letter : 0,
    passwordChangedSuccessfully : false
};


export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case OLD_PASSWORD_CHANGED:
            return { ...state, old_password: action.payload };
        case NEW_PASSWORD_CHANGED:
            return { ...state, new_password: action.payload };
        case NEW_PASSWORD_REPEAT_CHANGED:
            return { ...state, new_password_repeat: action.payload };
        case PASSWORD_CHANGE_SUCCESS:
            return {
                ...state,
                old_password : '',
                new_password : '',
                new_password_repeat : '',
                passwordChangedSuccessfully : true
            };
        case PASSWORD_CHANGE_FAIL:
            return {
                ...state,
                passwordChangedSuccessfully : false
            };
        case PUSH_NOTIFICATION:
            return { ...state, push_notification: action.payload };
        case EMAIL_NOTIFICATION:
            return { ...state, email_notification: action.payload };
        case NEWS_LETTERS:
            return { ...state, news_letter: action.payload };
        default:
            return state;
    }
};
// Actions



