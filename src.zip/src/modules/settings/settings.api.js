import { HttpPost, HttpGet, HttpPut} from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";
import APPCONSTATNT  from '../../constant/appConstant';
class SettingsApi {
    static changePassword = async (current_password, password) => {
        let data = {current_password,password}
        return await HttpPut(data,getApi('changePassword')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }
    static updateNotifications = async (NotificationOn,EmailNotification,Newsletter) => {
        let data = {NotificationOn,EmailNotification,Newsletter}
        return await HttpPut(data,getApi('updateNotificationSetting')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }
}

export default SettingsApi;