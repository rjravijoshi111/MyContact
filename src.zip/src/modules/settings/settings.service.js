
import SettingsApi from './settings.api';
import { asyncError, generalError } from '../errors/error.service';
import * as AuthAction from '../auth/auth.action';
import * as SettingsAction from './settings.action'
import {Toast} from "native-base";
import {NavigationActions} from "react-navigation";
import Storage from "../utils/Storage";

export const changePassword = (oldPassword,newPassword) => dispatch => {
    dispatch(AuthAction.setLoadingIndicator(true));
	return SettingsApi.changePassword(oldPassword,newPassword)
		.then(response => {
            console.log("Change Password-->",JSON.stringify(response))
            dispatch(AuthAction.setLoadingIndicator(false));
            if(response.code == 1008){
                dispatch(SettingsAction.setPasswordChangeSuccess(response.message));
                // dispatch(NavigationActions.navigate({ routeName: 'Auth' }));
            }else{
                dispatch(SettingsAction.setPasswordChangeError(response.messages[response.messages.length-1]));
                Toast.show({
                    text: response.messages[response.messages.length-1],
                    buttonText: 'Okay',
                    type: "danger"
                });
            }
		})
		.catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
			dispatch(generalError(error));
		});
};