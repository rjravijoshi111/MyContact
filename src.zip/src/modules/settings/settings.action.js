
export const OLD_PASSWORD_CHANGED = 'OLD_PASSWORD_CHANGED';
export const NEW_PASSWORD_CHANGED = 'NEW_PASSWORD_CHANGED';
export const NEW_PASSWORD_REPEAT_CHANGED = 'NEW_PASSWORD_REPEAT_CHANGED';

export const PUSH_NOTIFICATION = 'PUSH_NOTIFICATION';
export const EMAIL_NOTIFICATION = 'EMAIL_NOTIFICATION';
export const NEWS_LETTERS = 'NEWS_LETTERS';

export const PASSWORD_CHANGE_SUCCESS = 'PASSWORD_CHANGE_SUCCESS';
export const PASSWORD_CHANGE_FAIL = 'PASSWORD_CHANGE_FAIL';

export const oldPasswordChanged = (text) => {
    return {
        type: OLD_PASSWORD_CHANGED,
        payload: text
    };
};

export const newPasswordChanged = (text) => {
    return {
        type: NEW_PASSWORD_CHANGED,
        payload: text
    };
};

export const newPasswordRepeatChanged = (text) => {
    return {
        type: NEW_PASSWORD_REPEAT_CHANGED,
        payload: text
    };
};

export const setPasswordChangeSuccess = newPassword => {
    return {
        type: PASSWORD_CHANGE_SUCCESS,
        newPassword,
    };
};

export const setPasswordChangeError = changePasswordError => {
    return {
        type: PASSWORD_CHANGE_FAIL,
        changePasswordError
    };
};

export const pushNotification = (flag) => {
    return {
        type: PUSH_NOTIFICATION,
        payload: flag
    };
};

export const emailNotification = (flag) => {
    return {
        type: EMAIL_NOTIFICATION,
        payload: flag
    };
};

export const newsLatter = (flag) => {
    return {
        type: NEWS_LETTERS,
        payload: flag
    };
};