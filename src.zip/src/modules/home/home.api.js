import { HttpPost, HttpGet} from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";
import APPCONSTATNT  from '../../constant/appConstant';
class HomeApi {
    static getAllRequestsRoute = async () => {
        return await HttpGet(getApi('getAllRequestsRoute'))
            .then(response => response)
            .then(handleTokenErrors).catch(error => {
            throw error;
        })
    }
}

export default HomeApi;