export const ROUTE_REQUEST = 'ROUTE_REQUEST';

export const getRouteRequest = (request) => {
    return {
        type : ROUTE_REQUEST,
        payload : request
    };
};