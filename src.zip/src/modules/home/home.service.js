import {  } from 'react-native';
import HomeApi from './home.api';
import { asyncError, generalError } from '../errors/error.service';
import * as HomeAction from './home.action';
import {Toast} from "native-base";
import {NavigationActions} from "react-navigation";
import {getProfileData, getEmergancyContact} from '../profile/profile.service';
import Storage from "../utils/Storage";
import * as ProfileAction from "../profile/profile.action";
import * as AuthAction from "@modules/auth/auth.action";
import * as RoleAction from "../selectRole/role.action";
import { API } from '../utils/api';
import AsyncStorage from '@react-native-community/async-storage';
export const TAG = "== home.service.js :"

export const getRouteRequest = () => dispatch => {
    // dispatch(AuthAction.setLoadingIndicator(true));
	return HomeApi.getAllRequestsRoute()
		.then(response => {
            dispatch(AuthAction.setLoadingIndicator(false));
            if(response.code == 1002){
                dispatch(AuthAction.setLoadingIndicator(false));
            }else{
                
            }
		})
		.catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
			dispatch(generalError(error));
		});
};