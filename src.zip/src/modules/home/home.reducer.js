import {
    ROUTE_REQUEST,
} from './home.action';

const INITIAL_STATE = {
    routeRequest: '',
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case ROUTE_REQUEST:
            return { ...state, routeRequest: action.payload };
        default:
            return state;
    }
};
// Actions