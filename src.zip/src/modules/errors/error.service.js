

import { store } from '../../reducers';
import {REFRESH_EXPIRED,INVALID_TOKEN} from '../../modules/auth/auth.action'
import { connectionError } from '../errors/error.reducer';

// token errors handled here to keep out of service files
export const handleTokenErrors = response => {
	console.log('response token error',response);
	if (response.code && response.code === 401) {
		store.dispatch({ type: INVALID_TOKEN });
	}
	return response;
};

// general errors are for non-request specific problems that can occur with
// many requests, such as network errors and app specific, general errors
export const generalError = response => {
	if (response == 'TypeError: Network request failed') {
		return store.dispatch(connectionError('Network request failed'));
		// other checks for connection issues
	} else {
		// generic errors
	}
};
