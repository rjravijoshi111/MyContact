import {NavigationActions} from "react-navigation";
import {} from "react-native";
import {asyncError} from "../errors/error.service";
import AsyncStorage from '@react-native-community/async-storage';

export const ROLE_SELECTED = 'ROLE_SELECTED';

const _saveItem = async (item, selectedValue) => {
    try {
        await AsyncStorage.setItem(item, selectedValue);
    } catch (error) {
        throw error;
    }
};

export const roleSelected = (role) =>  (dispatch) => {
    dispatch({
        type: ROLE_SELECTED,
        payload: role.toString()
    });
    _saveItem('user_role', role.toString())
        .then(resp => {
            dispatch(NavigationActions.navigate({ routeName: 'Main',param:role }));
        })
        .catch(error => {
            console.log(error);
        });

};