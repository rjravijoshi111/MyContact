import {
    ROLE_SELECTED
} from './role.action';

const INITIAL_STATE = {
    user_role: null
};

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case ROLE_SELECTED:
            return { ...state, user_role: action.payload };
        default:
            return state;
    }
};