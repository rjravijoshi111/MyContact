import {
    EMAIL_CHANGED,
    PASSWORD_CHANGED,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,
    LOGIN_USER,
    PASSWORD_REPEAT_CHANGED,
    NAME_CHANGED,
    LAST_NAME_CHANGED,
    EMAIL_CONFIRM_CODE_CHANGED,
    PHONE_CHANGED,
    TERMS_CHANGED,
    REGISTER_USER_SUCCESS,
    REGISTER_USER,
    REGISTER_USER_FAIL,
    LOADING_CHANGED,
    FORGOT_PASSWORD_FAIL,
    SET_AUTH_PENDING,
    SET_LOGIN_SUCCESS,
    SET_LOGIN_ERROR,
    SET_REGISTER_SUCCESS,
    SET_REGISTER_ERROR,
    SET_LOGOUT,
    SAVE_APP_TOKEN,
    INVALID_TOKEN, REFRESHING_TOKEN, TOKEN_REFRESHED, SET_USER_PROFILE, IS_LOADING
} from './auth.action';

const INITIAL_STATE = {
    email: '',
    password: '',
    password_repeat:'',
    name:'',
    last_name:'',
    phone:'',
    user: null,
    error: '',
    loading: false,
    terms:false,
    code:'',
    token:'',
    authPending: false,
    loggedIn: false,
    registered: false,
    loginError: false,
    regError: false,
    authToken: null,
    refreshToken: null,
    tokenIsValid: null,
    pendingRefreshingToken: null
};


export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case EMAIL_CHANGED:
            return { ...state, email: action.payload };
        case PASSWORD_CHANGED:
            return { ...state, password: action.payload };
        case PASSWORD_REPEAT_CHANGED:
            return { ...state, password_repeat: action.payload };
        case NAME_CHANGED:
            return { ...state, name: action.payload };
        case LAST_NAME_CHANGED:
            return { ...state, last_name: action.payload };
        case PHONE_CHANGED:
            return { ...state, phone: action.payload };
        case TERMS_CHANGED:
            return { ...state, terms: action.payload };
        case EMAIL_CONFIRM_CODE_CHANGED:
            return { ...state, code: action.payload };
        case LOADING_CHANGED:
            return {...state,loading:action.payload};
        case LOGIN_USER:
            return { ...state, loading: true, error: '' };
        case LOGIN_USER_SUCCESS:
            return { ...state, ...INITIAL_STATE, token: action.payload };
        case LOGIN_USER_FAIL:
            return { ...state, error: action.payload, password: '', loading: false };
        case REGISTER_USER:
            return { ...state, loading: true, error: '' };
        case FORGOT_PASSWORD_FAIL:
            return{...state, error: action.payload, loading: false}
        case REGISTER_USER_SUCCESS:
            return { ...state, ...INITIAL_STATE};
        case REGISTER_USER_FAIL:
            return { ...state, error: action.payload, loading: false };
        case SET_AUTH_PENDING:
            return {
                ...state,
                authPending: true
            };
        case SET_LOGIN_SUCCESS:
            return {
                ...state,
                email:'',
                password:'',
                authPending: false,
                loggedIn: true,
                loginError: false,
                authToken: action.authToken,
                refreshToken: action.refreshToken,
                unique_person:action.unique_person,
                issue_date:action.issue_date,
                expired_date:action.expired_date,
                user_Role:action.user_Role
            };
        case SET_LOGIN_ERROR:
            return {
                ...state,
                authPending: false,
                loggedIn: false,
                loginError: action.loginError
            };
        case SET_REGISTER_SUCCESS:
            return {
                ...state,
                authPending: false,
                regError: false,
                registered: true
            };
        case SET_REGISTER_ERROR:
            return {
                ...state,
                authPending: false,
                regError: action.regError
            };
        case SET_LOGOUT:
            return {
                ...state,
                authToken: false,
                refreshToken: false,
                loggedIn: false
            };
        case INVALID_TOKEN:
            return {
                ...state,
                tokenIsValid: false
            };
        case REFRESHING_TOKEN:
            return {
                ...state,
                pendingRefreshingToken: true,
                tokenIsValid: false
            };
        case TOKEN_REFRESHED:
            return {
                ...state,
                pendingRefreshingToken: null,
                tokenIsValid: true
            };
        case SAVE_APP_TOKEN:
            return {
                ...state,
                authToken: action.authToken
            };
        case SET_USER_PROFILE:
            return {
                ...state,
                user: action.payload
            };
        case IS_LOADING:
            return {
                ...state,
                isLoading: action.isLoading
            };
        default:
            return state;
    }
};
// Actions



