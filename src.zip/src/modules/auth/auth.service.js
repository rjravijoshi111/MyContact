import {  } from 'react-native';
import AuthApi from './auth.api';
import { asyncError, generalError } from '../errors/error.service';
import * as AuthAction from './auth.action';
import {Toast} from "native-base";
import {NavigationActions} from "react-navigation";
import {getProfileData, getEmergancyContact} from '../profile/profile.service';
import Storage from "../utils/Storage";
import * as ProfileAction from "../profile/profile.action";
import * as RoleAction from "../selectRole/role.action";
import { API } from '../utils/api';
import AsyncStorage from '@react-native-community/async-storage';
export const TAG = "== auth.service.js :"

const _saveItem = async (item) => {
	try {
        Storage.setItem('authToken', item.token);
        Storage.setItem('refreshToken', item.refresh_token);
        Storage.setItem('uniquePerson', item.unique_person);
        Storage.setItem('issueDate', item.issue_date);
        Storage.setItem('expiredDate', item.expired_date);
	} catch (error) {
		throw error;
	}
};

const  _dispatchItem = async  dispatch => {
    try {
        await dispatch(getProfileData());
        await dispatch(getEmergancyContact());
    } catch (error) {
        throw error;
    }
};

export const refreshToken = data => dispatch => {
    console.log('nononononon',data);
    return AuthApi.refreshToken(data)
		.then(response => {
		    console.log('yes its here',response);
		    if (response.code == 1007) {
				_saveItem(response.content)
					.then(resp => {
					    console.log('doneeeee');
						return true;
					})
					.catch(error => {
						dispatch(asyncError(error));
					});
			}
		})
		.catch(error => {
			dispatch(generalError(error));
		});
};

// used on app startup
export const checkAuthStatus = () => async dispatch => {
	try {
        let authToken = null;
        let refreshToken= null;
        let uniquePerson= null;
        let issueDate= null;
        let expiredDate= null;
        let userRole = null;
        await Storage.getItem('authToken').then(result=>{
                 authToken =  result;
            });
        await Storage.getItem('refreshToken').then(result=>{
                refreshToken =  result;
            });
        await Storage.getItem('uniquePerson').then(result=>{
                uniquePerson =  result;
            });
        await Storage.getItem('issueDate').then(result=>{
                issueDate =  result;
            });
        await Storage.getItem('expiredDate').then(result=>{
                expiredDate =  result;
            });
        await Storage.getItem('user_role').then(result=>{
                userRole =  result;
            });
        if (authToken != null && refreshToken != null) {
            dispatch(AuthAction.setLoginSuccess(authToken, refreshToken,uniquePerson,issueDate,expiredDate));
		}
		return authToken;
	} catch (error) {
		dispatch(asyncError(error));
	}
};

export const logout = () => async dispatch => {
	dispatch(AuthAction.setLogout());
	try {
		await AsyncStorage.removeItem('authToken');
        AuthHandler.startApp();
	} catch (error) {
		dispatch(asyncError(error));
	}
};

export const register = (name,last_name,email,phone, password,password_repeat,client_id) => dispatch => {
    dispatch(AuthAction.setAuthPending());
    dispatch(AuthAction.setLoadingIndicator(true));
	return AuthApi.register(name,last_name,email,phone, password,password_repeat,client_id)
		.then(response => {
            dispatch(AuthAction.setLoadingIndicator(false));
            if(response.code == 1002){
                dispatch(AuthAction.setRegisterSuccess());
                dispatch(NavigationActions.navigate({ routeName: 'ConfirmEmail' }));
            }else{
                dispatch(AuthAction.setRegisterError(response.messages[response.messages.length-1]));
                Toast.show({
                    text: response.messages[response.messages.length-1],
                    buttonText: 'Okay',
                    type: "danger"
                });
            }
		})
		.catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
			dispatch(generalError(error));
		});
};

export const login = (email, password,client_id) => dispatch => {
    // dispatch(AuthAction.setAuthPending());
    dispatch(AuthAction.setLoadingIndicator(true));
    console.log("Login-->1");
    return AuthApi.login(email, password,client_id)
		.then(response => {
            console.log("Response Login-->",JSON.stringify(response));
            dispatch(AuthAction.setLoadingIndicator(false));
            if (response.code == 1007) {
				dispatch(
                    AuthAction.setLoginSuccess(response.content.token, response.content.refresh_token,response.content.unique_person,response.content.issue_date,response.content.expired_date)
				);
                _saveItem(response.content)
					.then(resp => {
                        // Storage.getItem('user_profile').then(result=>{
                        //     if(result){
                        //         dispatch(ProfileAction.setUserProfile(result));
                        //         // Storage.getItem('user_role').then((result) => {
                        //         //     if(result){
                        //         //         dispatch(NavigationActions.navigate({ routeName: 'Main' }));
                        //         //     }else{
                        //                 dispatch(NavigationActions.navigate({ routeName: 'SelectRole' }));
                        //             // }
                        //         // });
                        //     }else{
                                /*_dispatchItem(dispatch).then(result=>{
                                    Storage.getItem('user_role').then((result) => {
                                        // if(result){
                                        //     dispatch(NavigationActions.navigate({ routeName: 'Main' }));
                                        // }else{
                                            dispatch(NavigationActions.navigate({ routeName: 'SelectRole' }));
                                        // }
                                    });
                                });*/
                        //     }
                        // });
                        Storage.getItem('user_role').then((result) => {
                            if(result){
                                dispatch(NavigationActions.navigate({ routeName: 'Main' }));
                            }else{
                                dispatch(NavigationActions.navigate({ routeName: 'SelectRole' }));
                            }
                        });

					})
					.catch(error => {
                        Toast.show({
                            text: error,
                            buttonText: 'Okay',
                            type: "danger"
                        });
					});
            }else if(response.code == 1006) {
                dispatch(AuthAction.setLoginError(response.messages[response.messages.length-1]));
                return AuthApi.resendCode(email).then(response =>{
                    console.log("Response resend-->",JSON.stringify(response));
                    if(response.code == 1007){
                        dispatch(NavigationActions.navigate({ routeName: 'ConfirmEmail' }));
                    }else{
                        Toast.show({
                            text: response.messages[response.messages.length-1],
                            buttonText: 'Okay',
                            type: "danger"
                        });
                    }  
                })
                
            }else {
                Toast.show({
                    text: response.messages[response.messages.length-1],
                    buttonText: 'Okay',
                    type: "danger"
                });
				dispatch(AuthAction.setLoginError(response.messages[response.messages.length-1]));
			}
		})
		.catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
            dispatch(AuthAction.setLoginError(error));
            Toast.show({
                text: error,
                buttonText: 'Okay',
                type: "danger"
            });
		});
};

export const checkEmail = (email,code) => async (dispatch) => {
    dispatch(AuthAction.setAuthPending());
    return AuthApi.checkMail(email,code).then(response => {
        if(response.code == 1007){
            dispatch(AuthAction.setRegisterSuccess());
            dispatch(NavigationActions.navigate({ routeName: 'Login' }));
        }else{
            dispatch(AuthAction.setRegisterError(response.messages[response.messages.length-1]));
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });

        }
	}).catch(error=>{
        Toast.show({
            text: error,
            buttonText: 'Okay',
            type: "danger"
        });
        dispatch(AuthAction.setRegisterError(error));
	})
};


export const forgotPassword = (email,phone) => async (dispatch) => {
    dispatch(AuthAction.setAuthPending());
    dispatch(AuthAction.setLoadingIndicator(true));
    return AuthApi.forgotPassword(email,phone).then(response => {
        dispatch(AuthAction.setLoadingIndicator(false));
        if(response.code == 1007){
            dispatch(AuthAction.setRegisterSuccess());
            dispatch(NavigationActions.navigate({ routeName: 'Login' }));
        }else{
            dispatch(AuthAction.setRegisterError(response.messages[response.messages.length-1]));
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });
        }
    }).catch(error=>{
        dispatch(AuthAction.setLoadingIndicator(false));
        Toast.show({
            text: error,
            buttonText: 'Okay',
            type: "danger"
        });
        dispatch(AuthAction.setRegisterError(error));
    })
};

export const loginFacebook = (email,name,uid,client_id) => dispatch => {
    dispatch(AuthAction.setAuthPending());
    dispatch(AuthAction.setLoadingIndicator(true));
    return AuthApi.loginFacebook(email,name,uid,client_id)
        .then(response => {
            console.log("Response Login-->",JSON.stringify(response));
            dispatch(AuthAction.setLoadingIndicator(false));
            if (response.code == 1007) {
                dispatch(
                    AuthAction.setLoginSuccess(response.content.token, response.content.refresh_token,response.content.unique_person,response.content.issue_date,response.content.expired_date)
                );
                _saveItem(response.content)
                    .then(resp => {
                        _dispatchItem(dispatch).then(result=>{
                            Storage.getItem('user_role').then((result) => {
                                // if(result){
                                //     dispatch(NavigationActions.navigate({ routeName: 'Main' }));
                                // }else{
                                dispatch(NavigationActions.navigate({ routeName: 'SelectRole' }));
                                // }
                            });
                        });
                        //     }
                        // });
                    })
                    .catch(error => {
                        Toast.show({
                            text: error,
                            buttonText: 'Okay',
                            type: "danger"
                        });
                    });
            }else {
                Toast.show({
                    text: response.messages[response.messages.length-1],
                    buttonText: 'Okay',
                    type: "danger"
                });
                dispatch(AuthAction.setLoginError(response.messages[response.messages.length-1]));
            }
        })
        .catch(error => {
            dispatch(AuthAction.setLoadingIndicator(false));
            Toast.show({
                text: error,
                buttonText: 'Okay',
                type: "danger"
            });
        });
};