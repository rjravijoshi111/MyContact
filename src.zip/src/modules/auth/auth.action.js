export const EMAIL_CHANGED = 'EMAIL_CHANGED';
export const NAME_CHANGED = 'NAME_CHANGED';
export const LAST_NAME_CHANGED = 'LAST_NAME_CHANGED';
export const PHONE_CHANGED = 'PHONE_CHANGED';
export const PASSWORD_CHANGED = 'PASSWORD_CHANGED';
export const PASSWORD_REPEAT_CHANGED = 'PASSWORD_REPEAT_CHANGED';
export const TERMS_CHANGED = 'TERMS_CHANGED';
export const EMAIL_CONFIRM_CODE_CHANGED = 'EMAIL_CONFIRM_CODE_CHANGED';


export const LOGIN_USER_SUCCESS = 'LOGIN_USER_SUCCESS';
export const LOGIN_USER_FAIL = 'LOGIN_USER_FAIL';
export const LOGIN_USER = 'LOGIN_USER';

export const REGISTER_USER_SUCCESS = 'REGISTER_USER_SUCCESS';
export const REGISTER_USER_FAIL = 'REGISTER_USER_FAIL';
export const REGISTER_USER = 'REGISTER_USER';

export const FORGOT_PASSWORD_FAIL = 'FORGOT_PASSWORD_FAIL';

export const LOADING_CHANGED = 'LOADING_CHANGED';

export const ROLE_SELECTED = 'ROLE_SELECTED';

export const NOT_STARTED = 'NOT_STARTED';
export const LOADING = 'LOADING';
export const SUCCESS = 'SUCCESS';
export const ERROR = 'ERROR';
export const SET_AUTH_PENDING = 'SET_AUTH_PENDING';
export const SET_LOGIN_SUCCESS = 'SET_LOGIN_SUCCESS';
export const SET_LOGIN_ERROR = 'SET_LOGIN_ERROR';
export const SET_REGISTER_SUCCESS = 'SET_REGISTER_SUCCESS';
export const SET_REGISTER_ERROR = 'SET_REGISTER_ERROR';
export const SET_LOGOUT = 'SET_LOGOUT';
export const SAVE_APP_TOKEN = 'SAVE_APP_TOKEN';
export const INVALID_TOKEN = 'INVALID_TOKEN';
export const REFRESHING_TOKEN = 'REFRESHING_TOKEN';
export const TOKEN_REFRESHED = 'TOKEN_REFRESHED';
export const REFRESH_EXPIRED = 'REFRESH_EXPIRED';
export const GET_USER_PROFILE = "GET_USER_PROFILE";
export const SET_USER_PROFILE = 'SET_USER_PROFILE';
export const IS_LOADING = 'IS_LOADING';


export const getUserProfile = (text) => {
    return {
        type : GET_USER_PROFILE,
        payload : text
    };
};

export const emailChanged = (text) => {
    return {
        type: EMAIL_CHANGED,
        payload: text
    };
};

export const passwordChanged = (text) => {
    return {
        type: PASSWORD_CHANGED,
        payload: text
    };
};

export const passwordRepeatChanged = (text) => {
    return {
        type: PASSWORD_REPEAT_CHANGED,
        payload: text
    };
};

export const nameChanged = (text) => {
    return {
        type: NAME_CHANGED,
        payload: text
    };
};

export const lastNameChanged = (text) => {
    return {
        type: LAST_NAME_CHANGED,
        payload: text
    };
};

export const phoneChanged = (text) => {
    return {
        type: PHONE_CHANGED,
        payload: text
    };
};

export const termsChanged = (text) => {
    return {
        type: TERMS_CHANGED,
        payload: text
    };
};

export const confirmCodeChanged = (text) =>{
    return {
        type:EMAIL_CONFIRM_CODE_CHANGED,
        payload:text
    }
}

export const loadingChanged = (text) =>{
    return {
        type:LOADING_CHANGED,
        payload:text
    }
}


export const setAuthPending = () => {
    return {
        type: SET_AUTH_PENDING
    };
};
export const setLoginSuccess = (authToken, refreshToken,unique_person,issue_date,expired_date) => {
    return {
        type: SET_LOGIN_SUCCESS,
        authToken,
        refreshToken,
        unique_person,
        issue_date,
        expired_date
    };
};
export const setLoginError = loginError => {
    return {
        type: SET_LOGIN_ERROR,
        loginError
    };
};
export const setRegisterSuccess = () => {
    return {
        type: REGISTER_USER_SUCCESS
    };
};
export const setRegisterError = regError => {
    return {
        type: SET_REGISTER_ERROR,
        regError
    };
};
export const setLogout = () => {
    return {
        type: SET_LOGOUT
    };
};
export const saveAppToken = authToken => {
    return {
        type: SAVE_APP_TOKEN,
        authToken
    };
};
export const setLoadingIndicator = isLoading => {
    return {
        type: IS_LOADING,
        isLoading
    };
};


