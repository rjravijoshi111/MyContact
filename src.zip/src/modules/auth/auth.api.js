import { HttpPost, HttpGet} from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";
import APPCONSTATNT  from '../../constant/appConstant';
class AuthApi {


    static login = async (email, password,client_id) => {
        console.log("Login API call")
        return await HttpPost({'email':email, 'password':password,'client_id':client_id},getApi('login')).
        then(response=>{
            console.log("Login API Response-->",JSON.stringify(response));
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            console.log("Login API error-->",error);
            throw error;
        });
    }
    static register = async (name,last_name,email,phone, password,password_repeat,client_id) => {
        return await HttpPost({name:name,last_name:last_name,email:email,phone:phone, password:password,password_repeat:password_repeat,client_id:client_id},getApi('register')).
        then(response=>{
            return response;
        }).
        catch(error => {
            throw error;
        });
    }

    static refreshToken = async  ({refresh_token,client_id}) => {
        console.log('jjjjjjjjjjjjj');
        return await HttpPost({refresh_token:refresh_token,client_id:client_id},getApi('refreshToken')).
        then(response=>{
            console.log('qqqqqqqqq',response);
            return response;
        }).
        catch(error => {
            throw error;
        });
    }

    static checkMail = async  (email,code) => {
        return await HttpPost({email:email,code:code},getApi('activateAccount')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }
    static forgotPassword = async  (email,phone) => {
        return await HttpPost({email:email,phone:phone},getApi('recoveryPassword')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }

    static resendCode = async (email) => {
        return await HttpGet(getApi('resendCode',"?email="+email)).then(response => {
            return response;
        }).
        // then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }

    static loginFacebook = async (email,name,uid,client_id) => {
        return await HttpPost({'email':email, 'name':name,'uid':uid,'client_id':client_id},getApi('loginFacebook')).
        then(response=>{
            return response;
        }).
        catch(error => {
            throw error;
        });
    }
}

export default AuthApi;
