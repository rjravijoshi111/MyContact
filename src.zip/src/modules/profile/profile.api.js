import { HttpPost,HttpDelete,HttpGet,HttpPut,HttpFile } from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";
class ProfileApi {


    static getProfileData = async () => {
        return await HttpGet(getApi('getProfile'))
            .then(response => response)
            .then(handleTokenErrors).catch(error => {
            throw error;
        })
    }

    static updateProfile = async (data) => {
        console.log("changeProfile URL -->",JSON.stringify(data))
        return await HttpPut(data,getApi('changeProfile')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }

    static updateProfilePhoto = async (data) =>{
        return await HttpFile(data,getApi('updateProfilePhoto')).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }

    static updatePersonalDoc = async (data) =>{
        let param = {doc_type:data.doc_type};
        return await HttpFile(data,getApi('updatePersonalDoc',param)).
        then(response=>{
            return response;
        }).
        then(handleTokenErrors).
        catch(error => {
            throw error;
        });
    }

    static getEmergancyContact = async () => {
        return await HttpGet(getApi('getEmergancyContact')).then(response => {
            return response;
        }).then(handleTokenErrors).catch(error => {
            throw error;
        })
    }

    static updateEmergancyContact = async (data) => {
        return await HttpPost(data,getApi('updateEmergancyContact')).then(response=>{
            return response;
        }).
        then(handleTokenErrors).catch(error => {
            throw error;
        });
    }
}
export default ProfileApi;
