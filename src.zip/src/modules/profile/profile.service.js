import ProfileApi from "./profile.api";
import * as ProfileAction from "./profile.action";
import {NavigationActions} from "react-navigation";
import {Toast} from "native-base";
import Storage from "../utils/Storage";
import * as AuthAction from "../auth/auth.action";
export const TAG = "== profile.service.js :";

export const getProfileData = (uniqueId) => async (dispatch) => {
    //dispatch(AuthAction.getUserProfile());
    return ProfileApi.getProfileData(uniqueId).then(response => {
        console.log(TAG,"getProfileData response : " + JSON.stringify(response));
        dispatch(ProfileAction.setUserProfile(response.content));
        Storage.setItem('user_profile',response.content);
    })
}

export const updateProfile = (data) => async (dispatch) => {
    //dispatch(AuthAction.getUserProfile());
    dispatch(AuthAction.setLoadingIndicator(true));
    console.log(TAG,"update profile data : " + JSON.stringify(data));
    return ProfileApi.updateProfile(data).then(response => {
        console.log(TAG,"profile response : " + JSON.stringify(response));
        if(Object.keys(response.content).length > 0){
            dispatch(getProfileData());
            return true;
        }else{
            dispatch(AuthAction.setLoadingIndicator(false));
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });
            return false;
        }
    })
}

export const updateProfilePhoto = (data) => async (dispatch) => {
    return await ProfileApi.updateProfilePhoto(data).then(response => {
        console.log(TAG,"response : " + JSON.stringify(response));
        if(Object.keys(response.content).length > 0){
            dispatch(ProfileAction.setUserProfilePic(response.content.profile_image_url));
            Storage.updateItem('user_profile','profile_image_url',response.content.profile_image_url);
        }else{
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });
        }
    })
}

export const updatePersonalDoc = (data) => async (dispatch) => {
    console.log('sdfs',data);
    return ProfileApi.updatePersonalDoc(data).then(response => {
        console.log(TAG,"response : " + JSON.stringify(response));
        if(Object.keys(response.content).length > 0){
            dispatch(ProfileAction.setUserProfilePic(response.content.profile_image_url));
            // Storage.updateItem('user_profile','profile_image_url',response.content.profile_image_url);
        }else{
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });
        }
    })
}

export const getEmergancyContact = (uniqueId) => async (dispatch) => {
    //dispatch(AuthAction.getUserProfile());
    console.log(TAG,"getEmergancyContact");
    return ProfileApi.getEmergancyContact(uniqueId).then(response => {
        console.log(TAG,"getEmergancyContact response : " + JSON.stringify(response));
        if(response.content != undefined && response.content != null)
            dispatch(ProfileAction.setEmergancyContact(response.content));
        else   
            dispatch(ProfileAction.setEmergancyContact({
                "name" : "",
                "phone" : "",
                "email" : ""
            }));
         Storage.setItem('user_profile_emergency_contact',response.content);
    })
}

export const updateEmergancyContact = (data) => async (dispatch) => {
    //dispatch(AuthAction.getUserProfile());
    console.log(TAG,"update updateEmergancyContact : " + JSON.stringify(data));
    return ProfileApi.updateEmergancyContact(data).then(response => {
        console.log(TAG,"updateEmergancyContact response : " + JSON.stringify(response));
        if(Object.keys(response.content).length > 0){
            dispatch(AuthAction.setLoadingIndicator(false));
            dispatch(ProfileAction.setEmergancyContact(response.content));
            dispatch(NavigationActions.navigate({ routeName: 'Profile' }));
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "success"
            });
        }else{
            dispatch(AuthAction.setLoadingIndicator(false));
            Toast.show({
                text: response.messages[response.messages.length-1],
                buttonText: 'Okay',
                type: "danger"
            });
        }
    })
}