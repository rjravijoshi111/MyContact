import {
    SET_USER_PROFILE,
    SET_USER_PROFILE_PIC,
    SET_EMERGANCY_CONTACT
} from './profile.action';

const INITIAL_STATE = {
    user: null,
    error: '',
    loading: false
};


export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case SET_USER_PROFILE:
            return {
                ...state,
                user: action.payload
            };
        case SET_USER_PROFILE_PIC:
            state.user['profile_image_url'] = action.payload;
            return {
                ...state
            }
        case SET_EMERGANCY_CONTACT:
            state.user['emergancy_contact'] = action.payload;
            return {
                ...state,
            };
        default:
            return state;
    }
};
// Actions



