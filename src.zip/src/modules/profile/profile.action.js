export const SET_USER_PROFILE = 'SET_USER_PROFILE';
export const SET_USER_PROFILE_PIC = 'SET_USER_PROFILE_PIC';
export const SET_EMERGANCY_CONTACT = 'SET_EMERGANCY_CONTACT';


/************************************** Action Creator ************************************************/

export const setUserProfile = userObj => {
    return {
        type: SET_USER_PROFILE,
        payload:userObj
    };
}

export const setUserProfilePic = img => {
    return {
        type: SET_USER_PROFILE_PIC,
        payload:img
    };
}

export const setEmergancyContact = emergancyContact => {
    return {
        type: SET_EMERGANCY_CONTACT,
        payload:emergancyContact
    };
}
