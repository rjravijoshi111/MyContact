import { HttpPost, HttpGet } from '../utils/HttpClient';
import { handleTokenErrors } from '../errors/error.service';
import getApi from "../utils/ApiList";

class MyCreditApi {

    static getTotalCredit = async () => {
        return await HttpGet(getApi('myCredit'))
            .then(response => response)
            .then(handleTokenErrors).catch(error => {
                throw error;
            })
    }
}

export default MyCreditApi;
