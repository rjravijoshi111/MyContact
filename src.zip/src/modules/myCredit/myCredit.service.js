import MyCreditApi from './myCredit.api';
import * as MyCreditAction from "./myCredit.action";
import Storage from "@modules/utils/Storage";
export const getTotalCredit = () => async (dispatch) => {
    return MyCreditApi.getTotalCredit().then(response => {
        console.log("MY CREDIT RESPONSE : " + JSON.stringify(response.content));
        dispatch(MyCreditAction.setCreditTotal(response.content));
        Storage.setItem('TotalCredit', response.content);
    })
}