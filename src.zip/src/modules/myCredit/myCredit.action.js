export const SET_CREDIT_TOTAL = 'SET_CREDIT_TOTAL';


/************************************** Action Creator ************************************************/

export const setCreditTotal = userObj => {
    console.log("MY CREDIT ACTION", userObj.total_credit);
    return {
        type: SET_CREDIT_TOTAL,
        payload: userObj.total_credit
    };
}

