import {
    SET_CREDIT_TOTAL
} from './myCredit.action';


const INITIAL_STATE = {
    total_credit: 0,
    error: '',
    loading: false
};

export default (state = INITIAL_STATE, action) => {
    console.log("MY CREDIT REDUCER", action.payload);
    switch (action.type) {
        case SET_CREDIT_TOTAL:
            return {
                total_credit: action.payload
            };
        default:
            return state;
    }
}