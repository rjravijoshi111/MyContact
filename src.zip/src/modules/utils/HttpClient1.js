import axios from 'axios';
import { API_URL,SERVICE_VERSION } from 'react-native-dotenv';

import Storage from './Storage';
/*
  Base client config for your application.
  Here you can define your base url, headers,
  timeouts and middleware used for each request.
*/
// To see all the requests in the chrome Dev tools in the network tab.
XMLHttpRequest = GLOBAL.originalXMLHttpRequest ?
    GLOBAL.originalXMLHttpRequest :
    GLOBAL.XMLHttpRequest;

// fetch logger
global._fetch = fetch;
global.fetch = function (uri, options, ...args) {
    return global._fetch(uri, options, ...args).then((response) => {
        console.log('Fetch', { request: { uri, options, ...args }, response });
        return response;
    });
};
Storage.getItem('authToken').then((result) => {
    if(result != ''){
        axios.defaults.headers.common['Authorization'] = '';
        delete axios.defaults.headers.common['Authorization'];

        if (result) {
            axios.defaults.headers.common['Authorization'] = `${result}`;
        }
    }
});
const client = axios.create({
    baseURL: API_URL,
    timeout: 10000,
    headers: {
        'content-type': 'application/json',
        grant_type: "allow",
        service_version: SERVICE_VERSION
    },
});

// Custom middleware for requests (this one just logs the error).
client.interceptors.request.use(config => config, (error) => {
    console.log('Failed to make request with error:');
    console.log(error);
    return Promise.reject(error);
});

// Custom middleware for responses (this one just logs the error).
client.interceptors.response.use(response => response, (error) => {
    console.log('Request got response with error:');
    console.log(error);
    return Promise.reject(error);
});

export default client;
