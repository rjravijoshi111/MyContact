import RNFetchBlob from 'rn-fetch-blob'

export const HttpPost = async (data, apiData) => await HttpReq('POST',data,apiData);

export const HttpPut = async (data, apiData) => await HttpReq('PUT',data,apiData);

export const HttpDelete =async (data, apiData) => await HttpReq('DELETE',data,apiData);
export const HttpFile = async (data,apiData) => await HttpFileReq('POST',data,apiData);

// To see all the requests in the chrome Dev tools in the network tab.
XMLHttpRequest = GLOBAL.originalXMLHttpRequest ?
    GLOBAL.originalXMLHttpRequest :
    GLOBAL.XMLHttpRequest;

// fetch logger
global._fetch = fetch;
global.fetch = function (uri, options, ...args) {
    return global._fetch(uri, options, ...args).then((response) => {
        console.log('Fetch', { request: { uri, options, ...args }, response });
        return response;
    });
};
const HttpReq =  async (method,data, apiData) => {
    const json = JSON.stringify(data);

    let response =  await fetch(apiData.url, {
        method,
        headers: apiData.headers,
        body: json,
    });
    // only proceed once second promise is resolved
    return await response.json();
}

const HttpFileReq =  async (method,data, apiData) => {
    let response =  await RNFetchBlob.fetch(method,apiData.url,apiData.headers,[data]);
    // only proceed once second promise is resolved

    // let response =  await fetch(apiData.url, {
    //     method,
    //     headers: apiData.headers,
    //     body: data,
    // });
    return await response.json();
}

export const HttpGet = async (apiData) => {

    //console.log(apiData.url);
    //console.log(apiData.headers);

    console.log("APIData-->",JSON.stringify(apiData))
    const options = {
        method: 'GET',
        headers: apiData.headers,
    };
    let response =  await fetch(apiData.url,options);
    // only proceed once second promise is resolved
    return await response.json();


}


/* CODIGOS DE RESPUESTA API

    InvalidModel = 1000,
    RegisterDuplicated = 1001,
    RegisterCreated = 1002,
    InternalError = 1003,
    RegisterRemoved = 1004,
    RegisterNotFound = 1005,
    Inactive = 1006,
    Correct = 1007,
    RegisterUpdated = 1008,
    TransactionDone = 1009,
    RefreshTokenCorrect = 1010,
    MaxUpload = 1011
*
*
* */