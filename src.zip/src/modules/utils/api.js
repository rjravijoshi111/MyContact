import React from 'react';
import { Alert } from 'react-native';
import APPCONSTATNT  from '../../constant/appConstant';

export const API = {

    login: (onResponse, data, isHeaderRequired) => {
        request(onResponse, data, 'POST', "JSON", isHeaderRequired, APPCONSTATNT.BASE_URL + APPCONSTATNT.API.LOGIN, buildHeader());
    },
}

export const buildHeader = (headerParams = {}) => {
    var header = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'grant_type': "allow",
        'service_version': APPCONSTATNT.SERVICEVERSION
    }
    Object.assign(header, headerParams);
    return header;
}

async function request(onResponse, data, type, returnType, isHeaderRequired, featureURL, secureRequest) {
    let response = '';
    let responseJSON;
    console.log("featureURL >>> " + featureURL);
    console.log("secureRequest " + JSON.stringify(secureRequest));
    console.log("data >>> " + JSON.stringify(data));
    console.log("returnType " + returnType);
    console.log("isHeaderRequired " + isHeaderRequired);
    console.log("type " + type);

    try {
        if (type === 'GET') {
            if (isHeaderRequired) {
                console.log("Request Call get with Header");
                response = await fetch(featureURL, {
                    method: type,
                    headers: secureRequest
                });
            }
            else {
                console.log("Request Call get without header");
                response = await fetch(featureURL, {
                    method: type,
                });
            }
        }
        else {
            console.log("Request Call post with header");
            response = await fetch(featureURL, {
                method: type,
                headers: secureRequest,
                body: JSON.stringify(data)
            });
        }
        console.log("response " + JSON.stringify(response));
        console.log("response status " + response.status);
        if (returnType === 'TEXT') {
            responseJSON = await response.text();
        }
        else {
            responseJSON = await response.json();
        }
        console.log("responseJSON " + JSON.stringify(responseJSON));

        if (response.status == 200) {
            console.log("onResponse success ");
            onResponse.success(responseJSON);
        } else {
            console.log("onResponse error");
            onResponse.error(responseJSON);
        }
        if (onResponse.complete) {
            console.log("onResponse complete");
            onResponse.complete();
        }
    } catch (error) {
        console.log("onResponse catch error " + error);
        if (onResponse.complete) {
            console.log("onResponse catch complete");
            onResponse.complete();
        }
    }
}
