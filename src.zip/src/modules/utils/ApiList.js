import { store } from "../../reducers";

const baseUrl = "http://18b9cw0ehqksx6e9.azurewebsites.net/api/";

const serviceVersion = "1.5.0";

const ApiPaths = {
    login: {
        end: () => "Person/login",
        headers: () => {
            return {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": baseUrl,
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    loginGoogle: {
        end: () => "Person/login/Google",
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    loginFacebook: {
        end: () => "Person/login/Facebook",
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    register: {
        end: () => "Person/RegisterUser",
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    refreshToken: {
        end: () => `Person/RefreshToken/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "refresh_token",
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },

    activateAccount: {
        end: () => "Person/ActivateAccount",
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },

    resendCode: {
        end: () => `Person/Code?email=${store.getState().auth.email}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },

    recoveryPassword: {
        end: () => "Person/RecoveryPassword",
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            }
        }

    },

    //endUrl in object required
    getProfile: {
        end: () => `Person/Profile/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },
    updateProfilePhoto: {
        end: () => `Person/Photo/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },
    updatePersonalDoc: {
        end: param => `Person/File/${param.doc_type}/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },
    changePassword: {
        end: () => `Person/Password/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },

    deleteACard: {
        end: params => `UserRider/${params.uid}/CardInfo/${params.unique_card}`,
        headers: params => {
            return {
                "Content-Type": "application/json",
                Authorization: params.auth,
                service_version: serviceVersion
            };
        }
    },
    updateProfile: {
        end: params => `Person/Profile/${params.uid}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    changeProfile: {
        end: () => `Person/Profile/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },
    getEmergancyContact: {
        end: () => `Person/${store.getState().auth.unique_person}/EmergencyContact`,
        headers: () => {
            return {
                Authorization: store.getState().auth.authToken,
                service_version: serviceVersion
            };
        }
    },
    updateEmergancyContact: {
        end: () => `Person/${store.getState().auth.unique_person}/EmergencyContact`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                // grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    updateNotificationSetting: {
        end: () => `SyncSettings/NotificationSetting/${store.getState().auth.unique_person}`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                // grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    getAllRequestsRoute: {
        end: () => `UserDriver/${store.getState().auth.unique_person}/Request/`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                // grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    createRoute: {
        end: () => `UserDriver/${store.getState().auth.unique_person}/Route/`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                // grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
    myCredit: {
        end: () => `UserRider/${store.getState().auth.unique_person}/Credit/Total`,
        headers: () => {
            return {
                "Content-Type": "application/json",
                Authorization: store.getState().auth.authToken,
                // grant_type: "allow",
                service_version: serviceVersion
            };
        }
    },
};

const getApi = (service, params = undefined) => {
    return {
        url: baseUrl + ApiPaths[service].end(params),
        headers: ApiPaths[service].headers(params)
    };
};

export default getApi;
