import React  from 'react';
var validator = require('validator');
import {  Toast } from 'native-base';
import Lang from '@src/config/localization';

const namePattern = /^[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð,.'-] *[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð, .'-]+$/

const mailPattern =
    '^[^<>()[\\]\\\\,;:\\%#^\\s@\\"$?&!@]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z0-9]+\\.)+[a-zA-Z]{2,}))$';

const passPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$";

const phonePattern = "^[0-9]{10,14}$";

const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}$/;

const codePattern = "^[0-9]{6}$";

export const maxLengthPass = 14;

const empty = "\t";
const noError = "false";
export const validateConfirmMail = ({ code }) =>{
    if (validator.isEmpty(code))
    {
        Toast.show({
            text: Lang.signup.empty,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    if(!validator.isNumeric(code)){
        Toast.show({
            text: Lang.confirmEmail.invalidCode,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    if(code.length != 6){
        Toast.show({
            text: Lang.confirmEmail.shortCode,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    return true;
}

export const validateForgotPassword = ({ email }) =>{
    if (validator.isEmpty(email))
    {
        Toast.show({
            text: Lang.signup.empty,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    if (!validator.isEmail(email))
    {
        Toast.show({
            text: Lang.signup.wrongMail,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    return true;
}

export const validateRegister = ({ name,last_name,email,phone, password,password_repeat,terms }) => {
    if (
        validator.isEmpty(name) ||
        validator.isEmpty(last_name) ||
        validator.isEmpty(email) ||
        validator.isEmpty(phone) ||
        validator.isEmpty(password) ||
        validator.isEmpty(password_repeat)
    ) {
        Toast.show({
            text: Lang.signup.empty,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    if (!name.match(namePattern)) {
        Toast.show({
            text: Lang.signup.nameLetters,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (!last_name.match(namePattern)) {
        Toast.show({
            text: Lang.signup.lNameLetters,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (!email.match(mailPattern)) {
        Toast.show({
            text: Lang.signup.wrongMail,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (phone.length < 10) {
        Toast.show({
            text: Lang.signup.shortPhone,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    if (!phone.match(phonePattern)) {
        Toast.show({
            text: Lang.signup.invalidPhone,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (password.length < 8) {
        Toast.show({
            text: Lang.signup.shortPass,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    /*if (!password.match(passPattern)) {
        console.log(password.match(passPattern));
        Toast.show({
            text: Lang.signup.invalidPass,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }*/

    if (password_repeat !== password) {
        Toast.show({
            text: Lang.signup.notEqualPass,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (!terms) {
        Toast.show({
            text: Lang.signup.notAgree,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    return true;
};

export const validateLogin = ({ email,password}) => {
    if (
        validator.isEmpty(email) ||
        validator.isEmpty(password)
    ) {
        Toast.show({
            text: Lang.signup.empty,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }

    if (!validator.isEmail(email)) {
        Toast.show({
            text: Lang.signup.wrongMail,
            buttonText: 'Okay',
            type: "danger"
        });
        return false;
    }
    return true;
};

export const validateUpdateProfile = ({ email,date,name,last_name,phone,company_name,curp,rfc,birthday},Alert) =>{

    if (validator.isEmpty(email)) {
        Alert.simpleAlert("", Lang.updateProfile.email +Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.email +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    if (validator.isEmpty(phone)) {
        Alert.simpleAlert("", Lang.updateProfile.phone+Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.phone+Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    if (validator.isEmpty(company_name)) {
        Alert.simpleAlert("", Lang.updateProfile.company_name + Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.company_name + Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    if (validator.isEmpty(name)) {
        Alert.simpleAlert("", Lang.updateProfile.name +Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.name +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }

    if (validator.isEmpty(last_name)) {
        Alert.simpleAlert("", Lang.updateProfile.last_name +Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.name +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }

    if (validator.isEmpty(birthday)) {
        Alert.simpleAlert("", Lang.updateProfile.birthday +Lang.updateProfile.required, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.birthday +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    if (!validator.isEmail(email)) {
        Alert.simpleAlert("", Lang.signup.wrongMail, () => {})
        // Toast.show({
        //     text: Lang.signup.wrongMail,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    return true;
}
export const validatechangePassword = ({old_password,new_password,new_password_repeat},Alert) =>{
    
    if (validator.isEmpty(old_password)) {
        Alert.simpleAlert("", Lang.ChangePassword.passwordIncorrect, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.email +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }

    // if (validator.isEmpty(new_password)) {
    //     Alert.simpleAlert("", Lang.ChangePassword.passwordWarning, () => {})
    //     // Toast.show({
    //     //     text: Lang.updateProfile.email +Lang.updateProfile.required,
    //     //     buttonText: 'Okay',
    //     //     type: "danger"
    //     // });
    //     return false;
    // }
    
    if (!new_password.match(passwordPattern)) {
        Alert.simpleAlert("", Lang.ChangePassword.passwordWarning, () => {})
        // Toast.show({
        //     text: Lang.signup.invalidPhone,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }

    if (!validator.equals(new_password,new_password_repeat)) {
        Alert.simpleAlert("", Lang.ChangePassword.passwordDoNotMatch, () => {})
        // Toast.show({
        //     text: Lang.updateProfile.email +Lang.updateProfile.required,
        //     buttonText: 'Okay',
        //     type: "danger"
        // });
        return false;
    }
    return true;
}

export const validateCreatePath = ({ startPointAddress,endPointAddress,startHours,routeName,desireStop,frequencyDays },Alert) =>{
    const { chooseNameOfRoute,emptyStartPoint,emptyEndPoint,emptyStartingHours,emptyDesireStop,emptyFrequency} = Lang.createDrivePath
    if (validator.isEmpty(startPointAddress)) {
        Alert.simpleAlert("", emptyStartPoint, () => {})
        return false;
    }
    if (validator.isEmpty(endPointAddress)) {
        Alert.simpleAlert("", emptyEndPoint, () => {})
        return false;
    }
    if (validator.isEmpty(routeName)) {
        Alert.simpleAlert("", chooseNameOfRoute, () => {})
        return false;
    }
    if (validator.isEmpty(startHours+"")) {
        Alert.simpleAlert("", emptyStartingHours, () => {})
        return false;
    }
    if (validator.isEmpty(desireStop+"")) {
        Alert.simpleAlert("", emptyDesireStop, () => {})
        return false;
    }
    if (frequencyDays.length == 0) {
        Alert.simpleAlert("", emptyFrequency, () => {})
        return false;
    }
    return true;
}
