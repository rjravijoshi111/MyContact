import strings from './Localization';

export default strings;
