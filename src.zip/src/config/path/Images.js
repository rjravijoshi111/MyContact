export default imagePaths = {

    //Common
    logoApp: require('@assets/icons/logo_Guigo_contorno_blanco.png'),
    backgroundApp: require('@assets/icons/Fondo_Guigo_degrade.png'),
    roleCircle: require('@assets/icons/circle.png'),//@assets/common/Circulo.png - YA

    //Login
    facebookIcon: require('@assets/icons/Facebook_con_sombra.png'),
    googleIcon: require('@assets/icons/Google_con_sombra.png'),

    //Signup
    mailIcon: require('@assets/icons/Icono_username.png'),
    emailIcon: require('@assets/icons/Icono_email.png'),
    passwordIcon: require('@assets/icons/Icono_password.png'),
    phoneIcon: require('@assets/icons/Phone_number.png'),

    //ConfirmRegister
    keyboardIcon: require('@assets/icons/keyboardIcon.png'),
    guigoCircle: require('@assets/icons/guigoCircle.png'),//@assets/confirmregister/guigoCircle.png

    //SelectRole
    cardImage: require('@assets/icons/Rectangle_rounded.png'),
    driver: require('@assets/icons/Conductor.png'),
    driverShadowed: require('@assets/icons/Conductor_con_sombra.png'),
    passenger: require('@assets/icons/Pasajero.png'),
    passengerShadowed: require('@assets/icons/Pasajero_con_sombra.png'),

    //tabScreen
    home: require('@assets/icons/Icono_home.png'),
    profile: require('@assets/icons/Icono_perfil.png'),
    messenger: require('@assets/icons/Icono_messenger.png'),
    notification: require('@assets/icons/Icono_notification.png'),
    start: require('@assets/icons/Icono_start.png'),
    location: require('@assets/icons/Icono_ubicacion.png'),

    //drawer navigator AGREGAR NUEVOS ICONOS
    hamburger: require('@assets/icons/Icono_menu.png'),
    routes: require('@assets/icons/menu_direcciones.png'),  //Direcciones_menu.png
    record: require('@assets/icons/menu_historial.png'),
    credits: require('@assets/icons/menu_creditos.png'),
    payments: require('@assets/icons/menu_pagos.png'),
    invite: require('@assets/icons/menu_amigos.png'),
    settings: require('@assets/icons/menu_ajustes.png'),
    help: require('@assets/icons/menu_ayuda.png'),

    //Profile
    savedMoney: require('@assets/icons/iconos.png'),
    guigoTravels: require('@assets/icons/iconos2.png'),
    weightco2: require('@assets/icons/iconos3.png'),
    handFacebook: require('@assets/icons/handFacebook.png'),
    thumbsup_sin_background: require('@assets/icons/Thumbsup_sin_background.png'),
    coche_menu: require('@assets/icons/coche_menu.png'),
    //icoP_name:require('@assets/icons/Icono_perfil_name.png'),
    icoP_name: require('@assets/icons/icono_persona.png'),
    //icoP_age:require('@assets/icons/Icono_perfil_age.png'),
    icoP_age: require('@assets/icons/icono_calendario.png'),
    //icoP_phone:require('@assets/icons/Icono_perfil_phone.png'),
    icoP_phone: require('@assets/icons/icono_telefono.png'),
    icoP_mail: require('@assets/icons/Icono_perfil_mail.png'),
    icoP_company: require('@assets/icons/Icono_perfil_company.png'),
    icoP_woman: require('@assets/icons/Icono_woman.png'),
    icoP_men: require('@assets/icons/Icono_men.png'),
    icoP_upload: require('@assets/icons/subirImagen.png'),
    preferences_chat: require('@assets/icons/chat.png'),
    preferences_smoker: require('@assets/icons/fumador.png'),
    preferences_music: require('@assets/icons/musica.png'),
    preferences_news: require('@assets/icons/noticias.png'),
    uploadPlusIcon: require('@assets/icons/baseline_add_circle_black_18dp.png'),
    imageUploadToolTipIcon: require('@assets/icons/icono_signo_de_interrogacion.png'),
    iconSmoker: require('@assets/icons/Icono_fumeur.png'),
    // iconNews:require('@assets/icons/Icono_news.png'),
    // iconChat:require('@assets/icons/Icono_Chat.png'),
    // iconMusic:require('@assets/icons/Icono_music.png'),
    varified: require('@assets/icons/Verificado.png'),
    plus_coche: require('@assets/icons/Plus_coche.png'),


    //Notification
    notification_bell: require('@assets/icons/icono_notification_blanco.png'),
    notification_profile_guigo: require('@assets/icons/Circulo_con_Guigo.png'),
    ratting: require('@assets/icons/Estrella_llena.png'),
    boardind_pass_con_sombra: require('@assets/icons/boardind_pass_con_sombra.png'),
    icono_triangulo_rojo: require('@assets/icons/icono_triangulo_rojo.png'),
    Icono_start: require('@assets/icons/Icono_start.png'),

    //profile
    profile_round: require('@assets/icons/guigoCircle.png'),


    //home
    conductor: require('@assets/icons/Conductor_con_sombra.png'),
    direction: require('@assets/icons/Direction_2.png'),
    luchador_con_sombra: require('@assets/icons/Luchador_con_sombra.png'),
    oops: require('@assets/icons/oops.png'),
    mis_rutas: require('@assets/icons/mis_rutas.png'),
    barra_RUUTA: require("@assets/icons/Barra_RUUTA.png"),
    circulo_Numero_1: require("@assets/icons/Circulo_numero_1.png"),
    circulo_Numero_2: require("@assets/icons/Circulo_numero_2.png"),
    circulo_Numero_3: require("@assets/icons/Circulo_numero_3.png"),

    circulo_domingo: require("@assets/icons/Circulo_domingo.png"),
    circulo_Jueves: require("@assets/icons/Circulo_Jueves.png"),
    circulo_Lunes: require("@assets/icons/Circulo_Lunes.png"),

    circulo_Martes: require("@assets/icons/Circulo_Martes.png"),
    circulo_Miercoles: require("@assets/icons/Circulo_Miercoles.png"),
    circulo_Sabado: require("@assets/icons/Circulo_Sabado.png"),
    circulo_Viernes: require("@assets/icons/Circulo_Viernes.png"),

    posicion_actual: require("@assets/icons/posicion_actual.png"),
    baseline_keyboard_arrow_right: require("@assets/icons/baseline-keyboard_arrow_right-24px.png"),

    verificado: require("@assets/icons/Verificado.png"),
    iconChat: require("@assets/icons/Icono_Chat.png"),
    iconMusic: require("@assets/icons/Icono_music.png"),
    iconNews: require("@assets/icons/Icono_news.png"),

    image_report_a_problem_con_sombra: require("@assets/icons/Image_report_a_problem_con_sombra.png"),
    boarding_pass_con_sombra: require("@assets/icons/boarding_pass_con_sombra.png"),
    coche: require("@assets/icons/coche.png"),

    cochinito: require("@assets/icons/Image_cochinito.png"),
    monedas: require("@assets/icons/Monedas.png"),
    guigo_coche_blanco: require("@assets/icons/Guigo_coche_blanco.png"),
    nube_Co2: require("@assets/icons/Nube_Co2.png"),
    inviteFriend :require("@assets/icons/Invite_friends_color_con_sombra.png"),
    thumbsup :require("@assets/icons/Thumbsup_amarillo.png"),
    shareIcon :require("@assets/icons/Icono_share.png"),

    guigo_redondo_verde:require("@assets/icons/Guigo_redondo_verde.png"),
    help:require("@assets/icons/help2.png"),
    icono_como_funciona:require("@assets/icons/Icono_como_funciona.png"),
    icono_contact_us:require("@assets/icons/icono_contact_us.png"),
    icono_Terminos_y_condiciones:require("@assets/icons/Icono_Terminos_y_condiciones.png"),
    baseline_toggle_off:require("@assets/icons/baseline-toggle_off-24px(1).png"),
    baseline_toggle_on:require("@assets/icons/baseline-toggle_off-24px(1rose).png"),
    icono_perfil_correo:require("@assets/icons/Icono_perfil_correo.png"),
    icono_newsletter:require("@assets/icons/icono_newsletter.png"),
    icono_payment:require("@assets/icons/icono_payment.png"),
    icono_cambiar_contrasena:require("@assets/icons/icono_cambiar_contrasena.png"),
    icono_cerrar_sesion:require("@assets/icons/Icono_cerrar_sesion.png"),
    image_cuenta_con_sombra:require("@assets/icons/Image_cuenta_con_sombra.png"),
    image_credit_card_con_sombra:require("@assets/icons/Image_credit_card_con_sombra.png"),
    check_doc:require("@assets/icons/check_doc.png"),
    image_start_con_sombra:require("@assets/icons/Image_start_con_sombra.png"),
    image_punto_de_llegada_con_sombra:require("@assets/icons/Image_punto_de_llegada_con_sombra.png")
}