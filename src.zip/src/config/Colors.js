const colors = {
    black: "#231F20",
    white: "#FFFFFF",
    red: "#EE3B2B",
    blue: "#355C7D",
    yellow: "#ECBE2B",
    green: "#78C699",
    pink: "#ed55cb",
    app: "#96bcc1"
};
export default colors;
