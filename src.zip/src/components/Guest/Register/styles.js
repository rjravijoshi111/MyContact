import {Dimensions, StyleSheet} from 'react-native';
import {widthPercentageToDP,heightPercentageToDP} from '@src/config/Helper';
const width = widthPercentageToDP(50);
const height = heightPercentageToDP(50);
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent: "center",
        alignItems: 'center',
    },
    titleContainer:{
        justifyContent: "center",
        alignItems: 'center',
        marginBottom: 20
    },
    title:{
        fontWeight:"300",
        fontSize:25,
    },
    inputContainer:{
        flex: 1,
        justifyContent: "center",
        alignItems: 'center',
    },
    input:{
        justifyContent: "center",
        alignItems: 'center',
        marginBottom: 10,
    },
    inputStyle:{
        width:Dimensions.get('window').width*.90,
    },
    textJoin:{
        flexDirection: "row",
        justifyContent: "flex-start",
        alignItems: 'center',
        width:Dimensions.get('window').width*.90
    },
    checkcox:{
        width: 50,
        height:50
    },
    switch: {
        transform: [{ scaleX: 0.75 }, { scaleY: 0.75 }]
    },
    button:{
        backgroundColor:'#345C7C',
        width: 185,
        height: 49.5,

    },
    buttonContainer:{
        flex: 1,
        justifyContent: "center",
        alignItems: 'center',
        paddingTop: 40

    },
    registerNow : {
        width: 104,
        height: 18,
        fontSize: 18,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0,
        textAlign: "left",
        color: "#ffffff"
    }
});
export default styles;