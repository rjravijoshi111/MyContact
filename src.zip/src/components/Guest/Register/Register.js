import React, { Component } from 'react';
import {
    StatusBar,
    View,
    Switch, ScrollView
} from 'react-native';
import { Container, Header, Left, Body, Right, Icon, Content, Text, Title, Button } from 'native-base';

import { connect } from 'react-redux';
import { BackgroundImage, IconTextInput, Button as CustomButton, Spinner } from "@src/components/comman";
import images from "@src/config/path/Images";
import styles from './styles';
import colors from '@src/config/Colors';
import Lang from '@src/config/localization';
import { validateRegister } from '@src/config/Validation';

import { emailChanged, nameChanged, passwordChanged, passwordRepeatChanged, lastNameChanged, phoneChanged, termsChanged, loadingChanged, isLoadingIndicator } from "@modules/auth/auth.action";
import { register } from "@modules/auth/auth.service";
class Register extends Component {


    onEmailChange(text) {
        this.props.emailChanged(text);
    }

    onNameChange(text) {
        this.props.nameChanged(text);
    }

    onLastNameChange(text) {
        this.props.lastNameChanged(text);
    }

    onPhoneChange(text) {
        this.props.phoneChanged(text);
    }

    onPasswordChange(text) {
        this.props.passwordChanged(text);
    }

    onPasswordRepeatChange(text) {
        this.props.passwordRepeatChanged(text);
    }
    onTermsChange(val) {
        this.props.termsChanged(val);
    }
    onButtonPress() {
        const { name, last_name, email, phone, password, password_repeat, terms } = this.props;
        const fields = { name, last_name, email, phone, password, password_repeat, terms };
        const result = validateRegister(fields);
        if (result) {
            let client_id = "0D4416AB-37DE-4585-AB45-930A7CD38B28";
            this.props.register(name, last_name, email, phone, password, password_repeat, client_id);
        }
        return false;
    }
    renderButton() {
        // if (this.props.authPending) {
        //     return <Spinner style={styles.button} size="large" />;
        // }

        return (
            <CustomButton style={styles.button} onPress={this.onButtonPress.bind(this)}>{Lang.signup.register}</CustomButton>
        );
    }
    render() {
        const { navigation } = this.props;
        return (
            <BackgroundImage>
                <Container style={{ backgroundColor: "transparent" }}>
                    <Header style={{ backgroundColor: "transparent", elevation: 1 }} iosBarStyle={"light-content"} noShadow>
                        <Left style={{ flex: 0.2 }}>
                            <Button transparent onPress={() => navigation.navigate("Login")}>
                                <Icon name='arrow-back' style={{ color: "black" }} />
                            </Button>
                        </Left>
                        <Body>
                            <Title style={{ color: "black" }}>Login/Register</Title>
                        </Body>
                        <Right style={{ flex: 0.2 }} />
                    </Header>
                    <Content style={{ paddingTop: 20}}>
                        <View style={styles.inputContainer}>
                            <View style={styles.input}>
                                <IconTextInput
                                    iconPath={images.mailIcon}
                                    placeholder={Lang.signup.name}
                                    returnKeyType='next'
                                    maxLength={20}
                                    submitSubscriber={() => this.inputLast.textInput.focus()}
                                    onChangeText={this.onNameChange.bind(this)}
                                    value={this.props.name}
                                    inputStyle={styles.inputStyle}
                                />
                            </View>
                            <View style={styles.input}>
                                <IconTextInput
                                    ref={input => (this.inputLast = input)}
                                    iconPath={images.mailIcon}
                                    placeholder={Lang.signup.lastName}
                                    returnKeyType='next'
                                    maxLength={20}
                                    submitSubscriber={() => this.inputEmail.textInput.focus()}
                                    onChangeText={this.onLastNameChange.bind(this)}
                                    value={this.props.last_name}
                                    inputStyle={styles.inputStyle}
                                />
                            </View>
                            <View style={styles.input}>
                                <IconTextInput
                                    keyboardType="email-address"
                                    ref={input => (this.inputEmail = input)}
                                    iconPath={images.emailIcon}
                                    placeholder={Lang.signup.email}
                                    returnKeyType='next'
                                    submitSubscriber={() => this.inputPhone.textInput.focus()}
                                    onChangeText={this.onEmailChange.bind(this)}
                                    value={this.props.email}
                                    inputStyle={styles.inputStyle}

                                />
                            </View>
                            <View style={styles.input}>
                                <IconTextInput
                                    keyboardType="phone-pad"
                                    ref={input => (this.inputPhone = input)}
                                    iconPath={images.phoneIcon}
                                    placeholder={Lang.signup.phone}
                                    returnKeyType='next'
                                    maxLength={10}
                                    submitSubscriber={() => this.inputPass.textInput.focus()}
                                    onChangeText={this.onPhoneChange.bind(this)}
                                    value={this.props.phone}
                                    inputStyle={styles.inputStyle}

                                />
                            </View>
                            <View style={styles.input}>
                                <IconTextInput
                                    secureTextEntry={true}
                                    ref={input => (this.inputPass = input)}
                                    iconPath={images.passwordIcon}
                                    placeholder={Lang.signup.pass}
                                    returnKeyType='next'
                                    maxLength={14}
                                    submitSubscriber={() => this.inputConfirm.textInput.focus()}
                                    onChangeText={this.onPasswordChange.bind(this)}
                                    value={this.props.password}
                                    inputStyle={styles.inputStyle}

                                />
                            </View>
                            <View style={styles.input}>
                                <IconTextInput
                                    secureTextEntry={true}
                                    ref={input => (this.inputConfirm = input)}
                                    iconPath={images.passwordIcon}
                                    placeholder={Lang.signup.confirm}
                                    returnKeyType='done'
                                    maxLength={14}
                                    onChangeText={this.onPasswordRepeatChange.bind(this)}
                                    value={this.props.password_repeat}
                                    inputStyle={styles.inputStyle}

                                />
                            </View>
                            <View style={styles.textJoin}>
                                <Switch
                                    style={styles.switch}
                                    trackColor={colors.blue}
                                    onValueChange={this.onTermsChange.bind(this)}
                                    value={this.props.terms}
                                />
                                <Text >{Lang.signup.agree} {Lang.signup.terms}</Text>
                            </View>
                        </View>
                        <View style={styles.buttonContainer}>
                            {this.renderButton()}
                        </View>
                    </Content>
                </Container>
            </BackgroundImage>
        );
    }
}

const mapStateToProps = state => ({
    email: state.auth.email,
    phone: state.auth.phone,
    name: state.auth.name,
    last_name: state.auth.last_name,
    password: state.auth.password,
    password_repeat: state.auth.password_repeat,
    terms: state.auth.terms,
    authPending: state.auth.authPending
});

const mapDispatchToProps = dispatch => ({
    register: (name, last_name, email, phone, password, password_repeat, client_id) => dispatch(register(name, last_name, email, phone, password, password_repeat, client_id)),
    nameChanged: (name) => dispatch(nameChanged(name)),
    lastNameChanged: (last_name) => dispatch(lastNameChanged(last_name)),
    emailChanged: (email) => dispatch(emailChanged(email)),
    passwordChanged: (password) => dispatch(passwordChanged(password)),
    passwordRepeatChanged: (password) => dispatch(passwordRepeatChanged(password)),
    phoneChanged: (phone) => dispatch(phoneChanged(phone)),
    termsChanged: (terms) => dispatch(termsChanged(terms)),
    loadingChanged: (loading) => dispatch(loadingChanged(loading)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Register);
