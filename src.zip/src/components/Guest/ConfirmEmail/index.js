import ConfirmEmail from './ConfirmEmail';

export default ConfirmEmail;
