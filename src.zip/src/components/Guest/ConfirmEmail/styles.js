import {Dimensions,  StyleSheet} from 'react-native';
import {widthPercentageToDP,heightPercentageToDP} from '@src/config/Helper';
import colors from '@src/config/Colors';
const width = widthPercentageToDP(90);
const height = heightPercentageToDP(50);
const styles = StyleSheet.create({
    baseContainer: {
        borderWidth: 0,
        flexDirection: "column",
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageContainer: {
        borderColor: "red",
        borderWidth: 0,
        zIndex: 10000,
        alignContent: "center",
        alignItems: "center",
        backgroundColor: "transparent"
    },
    cardContainer: {
        top: -40,
        borderColor: "red",
        borderWidth: 0,
        zIndex: 5000,
        alignContent: "center",
        alignItems: "center",
        backgroundColor: "transparent",
        width: width,
        justifyContent: "center",
        height:height
        //height: 200
    },

    adviceText: {
        color: colors.black,
        textAlign: "center",
        fontSize: 10,

    },

    guigoCircle: {
        //resizeMode: "contain",
        width: Dimensions.get("window").width * 0.9 * 0.33,
        height: Dimensions.get("window").width * 0.9 * 0.33,
        alignItems: "center",
        alignContent: "center"
    },

    card: {
        //top: -60,
        backgroundColor: colors.white,
        //paddingTop: Dimensions.get("window").width * 0.1485,
        width: Dimensions.get("window").width * 0.9,
        //left: Dimensions.get("window").width * 0.05,
        height: Dimensions.get("window").width * 0.9 * 1.11,
        alignItems: "center",
        justifyContent: "space-between",
        //android
        elevation: 9,
        //only iOs
        shadowOpacity: 0.5, //only works if backgroundColor defined
        shadowRadius: 4, //shadow fuzzyness
        shadowOffset: { width: 1, height: 4 },
        paddingVertical: 16,
        paddingHorizontal: 16,
        zIndex: 50,
        borderColor: "purple",
        borderWidth: 0
    },
    button:{
        backgroundColor:'#345C7C',
        width: 174,
        height: 49.5,

    }
});
export default styles;