import React, { Component } from 'react';
import {BackgroundImage, IconTextInput, Button, Spinner} from "@src/components/comman";
import {connect} from "react-redux";
import { View,Text,Dimensions,Image} from 'react-native';
import styles from './styles';
import images from "@src/config/path/Images";
import Lang from '@src/config/localization';
import {confirmCodeChanged} from "@modules/auth/auth.action";
import {checkEmail} from  "@modules/auth/auth.service";
import {validateConfirmMail} from '@src/config/Validation';

class ConfirmEmail extends Component {

    onCodeChanged(val){
        this.props.confirmCodeChanged(val);
    }
    onButtonPress() {
        const { email,code} = this.props;
        const fields = { code };
        const result = validateConfirmMail(fields);
        if(result){
            this.props.checkEmail(email,code);
        }
        return false;
    }
    renderButton() {
        const {validate} = Lang.confirmEmail;
        if (this.props.authPending) {
            return <Spinner style={styles.button} size="large" />;
        }

        return (
            <Button  style={styles.button} onPress={this.onButtonPress.bind(this)}>{validate}</Button>
        );
    }
    render(){
        const {enterDigit,enterDigits,advice} = Lang.confirmEmail;
        return (
            <BackgroundImage>
                <View style={styles.baseContainer}>
                    <View style={styles.imageContainer}>
                        <Image source={images.guigoCircle} style={styles.guigoCircle} />
                    </View>
                    <View style={styles.cardContainer}>
                        <View style={styles.card}>
                            <View></View>
                            <Text style={styles.adviceText}>{advice}</Text>
                            <Text style={styles.adviceText}>{enterDigits}</Text>
                            <IconTextInput
                                iconPath={images.keyboardIcon}
                                placeholder={enterDigit}
                                returnKeyType='next'
                                maxLength={6}
                                keyboardType="numeric"
                                inputStyle={{width:Dimensions.get('window').width*.85,top:-20}}
                                value={this.props.code}
                                onChangeText={this.onCodeChanged.bind(this)}
                            ></IconTextInput>
                            {this.renderButton()}
                        </View>
                    </View>
                </View>
            </BackgroundImage>
        );
    }
}
const mapStateToProps = state => ({
    email:state.auth.email,
    code:state.auth.code,
    authPending:state.auth.authPending
});
const mapDispatchToProps = dispatch => ({
    confirmCodeChanged: (code) => dispatch(confirmCodeChanged(code)),
    checkEmail: (email,code) => dispatch(checkEmail(email,code)),
});


export default connect(mapStateToProps,mapDispatchToProps)(ConfirmEmail);
