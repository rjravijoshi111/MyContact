import React, { Component } from 'react';
import {BackgroundImage, IconTextInput, Button as CustomButton, Spinner} from "@src/components/comman";
import {connect} from "react-redux";
import { Dimensions, Image,View, TouchableOpacity, StyleSheet} from 'react-native';
import styles from './styles';
import Lang from '@src/config/localization';
import images from "@src/config/path/Images";
import {emailChanged} from  "@modules/auth/auth.action";
import {forgotPassword} from "@modules/auth/auth.service";
import {validateForgotPassword} from '@src/config/Validation';
import {Body, Container, Content, Header, Icon, Left, Title,Text,Item,Input,Form,Button, Right} from "native-base";

class ForgotPassword extends Component {

    onEmailChange(val){
        this.props.emailChanged(val);
    }
    
    onButtonPress() {
        const { email} = this.props;
        const fields = {email};
        const result = validateForgotPassword(fields);
        if(result){
            let phone="9999999999";
            this.props.forgotPassword(email,phone);
        }
        return false;
    }
    renderButton() {
        const {validate} = Lang.forgotPassword;
        // if (this.props.authPending) {
        //     return <Spinner style={styles.button} size="large" />;
        // }

        return (
            <CustomButton  style={styles.button} onPress={this.onButtonPress.bind(this)}>{validate}</CustomButton>
        );
    }
    render(){
        const {mail,title,indications,notReceived} = Lang.forgotPassword;
        const {navigation} = this.props;
        return (
            <Container style={{ backgroundColor: "transparent",flex: 1 }}  >
                <Header style={{ backgroundColor: "transparent", elevation: 1 }} iosBarStyle={"light-content"} noShadow>
                    <Left style={{flex:0.2}}>
                        <Button  transparent onPress={() => navigation.navigate("Login")}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                    <Title style={{ color: "black" }}>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content style={{ paddingTop: 50 }} contentContainerStyle={{flex:1}}>
                    <View style={{ flex: 1}}>
                    <View style={{ paddingLeft: 10 }}>
                        <Text style={styles.label}>{indications}</Text>
                    </View>
                    <Form style={{ paddingTop: 30 }}>
                        <Item>
                            <Input placeholder={mail} keyboardType="email-address"
                                   value={this.props.email}
                                   autoCapitalize={"none"}
                                   onChangeText={this.onEmailChange.bind(this)}  />
                        </Item>
                    </Form>

                    <View style={{ paddingTop: 50,flexDirection: 'row',justifyContent: 'center',alignItems: 'center' }}>
                        {this.renderButton()}
                    </View>
                    <View style={{ paddingTop: 20,}}>
                        <TouchableOpacity style={[styles.forgetButtonContainer]} onPress={() => navigation.navigate("ForgotPassword")}>
                            <Text style={styles.label} >{notReceived}</Text>
                        </TouchableOpacity>
                    </View>
                    </View>

                </Content>
            </Container>
        );
    }

}
const mapStateToProps = state => ({
    email:state.auth.email,
    authPending:state.auth.authPending
});
const mapDispatchToProps = dispatch => ({
    forgotPassword: (email,phone) => dispatch(forgotPassword(email,phone)),
    emailChanged: (email) => dispatch(emailChanged(email))
});

export default connect(mapStateToProps,mapDispatchToProps)(ForgotPassword);