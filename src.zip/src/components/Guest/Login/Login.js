import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image, ScrollView,
    Dimensions
} from 'react-native';
import { connect } from 'react-redux';
import {BackgroundImage,IconTextInput,Button,Spinner} from "@src/components/comman";
import images from "@src/config/path/Images";
import styles from './styles';
import Lang from '@src/config/localization';
import {emailChanged,passwordChanged,loadingChanged} from  "@modules/auth/auth.action";
import {login,loginFacebook} from  "@modules/auth/auth.service";
import {validateLogin} from '@src/config/Validation';
import {Container,Content} from "native-base";
//Login Facebook
import { LoginManager,AccessToken } from "react-native-fbsdk"
const { height, width } = Dimensions.get("screen");

class Login extends Component {

    constructor( props ) {
        // allow the user this in constructor
        super( props );

        // only needed if used in a callback
        this.loginFacebook = this.loginFacebook.bind(this);
    }

    onEmailChange(text) {
        this.props.emailChanged(text);
    }

    onPasswordChange(text) {
        this.props.passwordChanged(text);
    }

    onButtonPress() {
        const { email,password} = this.props;
        const fields = { email, password};
        const result = validateLogin(fields);
        if(result){
            let client_id = "0D4416AB-37DE-4585-AB45-930A7CD38B28";
            this.props.login(email, password,client_id);
            // console.log("API")
            // fetch('https://mywebsite.com/endpoint/', {
            // method: 'POST',
            // headers: {
            //     Accept: 'application/json',
            //     'Content-Type': 'application/json',
            //     'grant_type' : 'allow',
            //     'service_version' : '1.5.0'
            // },
            // body: JSON.stringify({
            //         email: email,
            //         password: password,
            //         client_id: client_id
            //     }),
            // })
            // .then((response) => response.json())
            // .then((responseJson) => {
            //   console.log("Response-->",JSON.stringify(responseJson))
            // })
            // .catch((error) => {
            //   console.error(error);
            // });
        }
        return false;
    }
    onLoadingChange(){
        this.props.loadingChanged(false);
    }
    renderButton() {
        // if (this.props.authPending) {
        //     return <Spinner style={styles.button} size="large" />;
        // }

        return (
            <Button style={styles.button} onPress={this.onButtonPress.bind(this)}>{Lang.login.txtLogin}</Button>
        );
    }

    async loginFacebook() {
        // alert("1234")
        let _this = this;
        try {
            let result = await LoginManager.logInWithReadPermissions(['public_profile'])
            if (result.isCancelled) {
                alert('Login was cancelled');
            } else {
                AccessToken.getCurrentAccessToken().then((data) => {
                    const { accessToken } = data;
                    fetch('https://graph.facebook.com/v2.5/me?fields=email,name,friends&access_token=' + accessToken)
                        .then((response) => response.json())
                        .then((json) => {
                            let client_id = "0D4416AB-37DE-4585-AB45-930A7CD38B28";
                            this.props.loginFacebook(json.email,json.name,json.id,client_id);
                        })
                        .catch(() => {
                            // reject('ERROR GETTING DATA FROM FACEBOOK')
                        })
                })
            }
        } catch (error) {
            alert('Login failed with error: ' + error)
        }
    }

    render() {
        const { navigation } = this.props;
        return (
            <BackgroundImage>
                <Container style={styles.container}>
                    <Content style={{height: height}} bounces={false}>
                        <View style={styles.mainView}>
                            <View style={styles.topContainer}>
                                <View>
                                    <Image source={images.logoApp} style={styles.logoTag} resizeMode={"contain"} />
                                </View>
                                <View>
                                    <Text style={{fontSize:height * 0.03,color:'#211915'}}>{Lang.login.signupwith}</Text>
                                </View>
                                <View style={styles.socialIconContainer}>
                                    <TouchableOpacity style={styles.iconContainer}>
                                        <Image source={images.googleIcon} style={styles.googleIcon} />
                                    </TouchableOpacity>
                                    <TouchableOpacity style={styles.iconContainer} onPress={this.loginFacebook}>
                                        <Image source={images.facebookIcon} style={styles.fbIcon}  />
                                    </TouchableOpacity>
                                </View>
                            </View>
                            <View style={styles.askContainer}>
                                <Text style={{fontSize:18,color:'#211915'}}>{Lang.login.already}</Text>
                            </View>    
                            <View style={styles.centerContainer}>
                                <View>
                                    <View>
                                        <IconTextInput
                                            inputStyle={{ marginTop: height * 0.01 }}
                                            keyboardType="email-address"
                                            iconPath={images.mailIcon}
                                            placeholder={Lang.signup.email}
                                            returnKeyType='next'
                                            submitSubscriber={() => this.inputEmail.textInput.focus()}
                                            onChangeText={this.onEmailChange.bind(this)}
                                            value={this.props.email}
                                        />
                                    </View>
                                    <View style={{marginTop: 5 }}>
                                        <IconTextInput
                                            secureTextEntry={true}
                                            returnKeyType="done"
                                            inputStyle={{ marginTop: 10 }}
                                            iconPath={images.passwordIcon}
                                            placeholder={Lang.signup.pass}
                                            ref={input => (this.inputEmail = input)}
                                            onChangeText={this.onPasswordChange.bind(this)}
                                            value={this.props.password}
                                        />
                                    </View>
                                    <View>
                                        <View style={styles.buttonContainer}>   
                                            {this.renderButton()}
                                        </View>
                                        <TouchableOpacity style={[styles.buttonContainer,styles.forgetButtonContainer]} onPress={() => navigation.navigate("ForgotPassword")}>
                                            <Text style={{fontSize:12.5,color:'#211915'}}>{Lang.login.forgotPassword}</Text>
                                        </TouchableOpacity>

                                    </View>
                                </View>
                            </View>
                            <View style={styles.bottomContainer}>
                                <View style={styles.bottomButtonContainer}>
                                    <Button  style={styles.button} onPress={() => navigation.navigate("Register")}>{Lang.login.txtSignup}</Button>
                                </View>
                                <View style={styles.bottomText}>
                                    <Text sstyle={{fontSize:12.5,color:'#211915'}}>{Lang.login.terms}</Text>
                                </View>
                            </View>
                        </View>
                    </Content>
                </Container>
            </BackgroundImage>
        );
    }
}

const mapStateToProps = state => ({
    email:state.auth.email,
    password:state.auth.password,
    authPending:state.auth.authPending
});


const mapDispatchToProps = dispatch => ({
    login: (email, password,client_id) => dispatch(login(email, password,client_id)),
    loginFacebook: (email, name,uid,client_id) => dispatch(loginFacebook(email, name,uid,client_id)),
    emailChanged: (email) => dispatch(emailChanged(email)),
    passwordChanged: (password) => dispatch(passwordChanged(password)),
    loadingChanged: (loading) => dispatch(loadingChanged(loading)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Login);
