import { StyleSheet,Dimensions} from 'react-native';
const { height, width } = Dimensions.get("screen");
const styles = StyleSheet.create({
    container:{
        // margin: 10,
        backgroundColor: "transparent",
    },
    mainView : {
        height : height - 20,
        padding: 10
    },
    topContainer:{
        justifyContent: "center",
        alignItems: 'center',
        height : height * 0.28,
    },
    logoTag:{
        // width: 199.5,
        height: height * 0.09,
        width : height * 0.3,
    },
    googleIcon:{
        // width: 110.5,
        // height: 110.5
        height: height * 0.15,
        width : height * 0.15,
    },
    fbIcon:{
        height: height * 0.15,
        width : height * 0.15,
    },
    socialIconContainer:{
        flexDirection: 'row',
    },
    iconContainer:{
        flex: 1,
        justifyContent: "center",
        alignItems: 'center',
    },
    askContainer:{
        justifyContent: "flex-start",
        alignItems: 'flex-start',
    },
    centerContainer:{
        alignItems: 'center',
    },
    button:{
        backgroundColor:'#345C7C',
        width: 174,
        // height: 49.5,
        height: height * 0.07,
        // width : height * 0.15,
        // marginTop:10

    },
    buttonContainer:{
        flexDirection: 'row',
        justifyContent:'flex-end',
        marginRight: 10,
        marginTop: 10,
    },
    bottomContainer:{
        justifyContent: "center",
        alignItems: 'center',
        flex: 1,
        // flexGrow: 1,
        // height: Dimensions.get('window').height*0.2,
        // marginTop:10,
    },
    forgetButtonContainer:{
        marginRight: 25,
        marginTop: 10
    },
    bottomButtonContainer:{
        justifyContent:'flex-end',
    },
    bottomText:{
        justifyContent:'center',
        marginTop:height * 0.018
    }
});

export default styles;
