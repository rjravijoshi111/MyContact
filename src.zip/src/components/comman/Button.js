import React from 'react';
import {TouchableOpacity,Text,View,StyleSheet} from 'react-native';

const Button = props =>(
    <TouchableOpacity onPress={props.onPress} >
        <View style={[styles.button,props.style]}>
            <Text style={[styles.buttonText,props.buttonTextStyle]}>{props.children}</Text>
        </View>
    </TouchableOpacity>
);
const styles = StyleSheet.create({

    button:{
        justifyContent: "center",
        alignItems: "center",
        alignSelf:'stretch',
        backgroundColor:'#345C7C'
    },
    buttonText:{
        fontSize: 18,
        fontWeight: "bold",
        fontStyle: "normal",
        letterSpacing: 0,
        textAlign: "left",
        color: "#ffffff"

    }
});
export  {Button};

