import React,{ Component } from 'react';
import { View,Image,Text,TouchableOpacity, Dimensions,StyleSheet} from 'react-native';
import Lang from '@src/config/localization';

import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
const { height, width } = Dimensions.get("window");

export class ListItem extends Component{
    constructor(props){
        super(props);
    }

    render(){
        const { countless, sntaFe, closingHours, input } = Lang.requestList;
        const { buttonColor, buttonText } = this.props
        return(
            <View style={styles.itemMailContainer}>
                <View style={{flexDirection:'row',paddingHorizontal: 10}}>
                    <View style={{flex:1}}>
                        <View style={{flexDirection:'row'}}>
                            <View style={{padding:5}}>
                                <Image source={images.icoP_men} style={{height:50,width:50}} resizeMode={"cover"} />
                            </View>
                            <View style={styles.itemTopMiddaleView}>
                                <Text style={styles.label}>{"Jade"}</Text>
                                <View style={{alignItems:'flex-start'}}>
                                    <StarRating
                                        disabled={true}
                                        maxStars={5}
                                        rating={3}
                                        starSize={20}
                                        emptyStarColor={"#EDBF3F"}
                                        fullStarColor={"#EDBF3F"}
                                        // selectedStar={(rating) => this.onStarRatingPress(rating)}
                                    />
                                </View>
                            </View>
                        </View>
                        <View style={styles.itemMiddleView}>
                            <Image source={images.direction} style={{height:50,width:20}} resizeMode={"contain"} />
                            <View style={styles.itemMiddleInnerView}>
                                <Text style={styles.label}>{countless}</Text>
                                <Text style={styles.label}>{sntaFe}</Text>
                            </View>
                        </View>
                    </View>
                    
                    <View style={styles.itemTopRightView}>
                        <Text style={[styles.label,styles.label2]}>{"LMM"}<Text style={{color:'lightgray',fontWeight:'normal',fontSize:12}}>{"JVSD"}</Text></Text>
                        <View style={{}}>
                            <Text style={[styles.label,styles.label2]}>{closingHours}</Text>
                            <Text style={[styles.label,styles.label3]}>{"07:15"}</Text>
                        </View>
                        <View>
                            <Text style={[styles.label,styles.label2]}>{input}</Text>
                            <Text style={[styles.label,styles.label3]}>{"50 créditos Guigo!"}</Text>
                        </View>
                    </View>
                </View>
                <TouchableOpacity style={[styles.seeButton,{backgroundColor: buttonColor,}]} onPress={this.props.navigation}>
                    <Text style={[styles.label,{color:'#fff'}]}>{buttonText}</Text>
                </TouchableOpacity>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    label: {
        fontSize: 12,
        fontFamily: 'Roboto'
    },
    label2: {
        fontWeight: 'bold',
        color: '#355c7d'
    },
    label3: {
        textAlign: 'right'
    },
    seeButton: {
        borderRadius: 0,
        height: 18,
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    itemMailContainer: {
        backgroundColor: '#fff', marginHorizontal: 20, marginTop: 20
    },
    itemTopMiddaleView: {
        flex: 1, paddingHorizontal: 10, justifyContent: 'space-evenly'
    },
    itemMiddleView: {
        flexDirection: 'row', flex: 1, alignItems: 'center'
    },
    itemMiddleInnerView: {
        justifyContent: 'space-between', height: '100%', paddingVertical: 2, paddingLeft: 10
    },
    itemTopRightView: {
        flex: 0.6, alignItems: 'flex-end', justifyContent: 'space-around'
    },
    title: { marginTop: 15, color: '#355c7d', fontSize: 15, fontWeight: 'bold' },
});
