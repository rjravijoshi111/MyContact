import React from 'react';
import {View, ActivityIndicator} from 'react-native';

const Spinner = ({ size,style }) => {
    return (

        <View style={[styles.button,style]}>
            <View style={styles.spinnerStyle}>
                <ActivityIndicator size={size || 'large'} />
            </View>
        </View>
    );
};
export  {Spinner};
const styles = {
    spinnerStyle: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    button:{
        justifyContent: "center",
        alignItems: "center",
        backgroundColor:'#345C7C',
    },
};



