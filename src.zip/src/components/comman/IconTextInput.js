import React, {Component} from 'react';
import {
    StyleSheet,
    View,
    TextInput,
    Image,
    Dimensions
} from 'react-native';
import colors from '@src/config/Colors';

const cardElevation = 5;


export  class IconTextInput extends Component {
    constructor(props){

        super(props);

        this.state = {
            text: '',
            capitalized:'false',
        }

    }

    render () {
        return (
            <View style={styles.center}>
                <View style={[styles.TextInputContainer,this.props.inputStyle]}>
                    <TextInput
                        style={[styles.TextInputStyle,this.props.style]}
                        underlineColorAndroid='transparent'
                        defaultValue={this.props.text}
                        onSubmitEditing={this.props.submitSubscriber}
                        {...this.props}
                        autoCapitalize={'none'}
                        ref={c => this.textInput = c}
                    />
                    <Image
                        source={this.props.iconPath}
                        style={styles.iconStyle}/>
                </View>
            </View>
        );
    }

}
const styles = StyleSheet.create({
    center:{
        width:Dimensions.get('window').width,
        justifyContent:'center',
        alignItems:'center',
    },
    TextInputContainer: {
        flexDirection:'row',
        width:Dimensions.get('window').width*.95,
        alignItems:'center',
        justifyContent: 'center',
        marginHorizontal:1,
        borderColor: colors.gray,
        //borderWidth: 0.5,
        height: 50,
        backgroundColor: colors.white,

        //only android
        elevation: cardElevation,

        //only iOs
        shadowOpacity: 0.5, //only works if backgroundColor defined
        shadowRadius: cardElevation, //shadow fuzzyness
        shadowOffset: {width: 1, height:cardElevation},
    },
    iconStyle:{
        flex:1,
        height:16,
        marginRight: 10,
        resizeMode: 'contain',
    },
    TextInputStyle:{
        fontSize:14,
        flex:9,
        color:colors.black,
        paddingLeft:10,

    }
});