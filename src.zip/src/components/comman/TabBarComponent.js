import React from 'react'
import { Keyboard, Image } from 'react-native'
import { TabBarBottom } from 'react-navigation'
import images from "@src/config/path/Images";
import { Button, Text, Icon, Footer, FooterTab } from "native-base";

const iconSize = 25;

class TabBarComponent extends React.PureComponent {

    constructor(props) {
      super(props)
  
      this.keyboardWillShow = this.keyboardWillShow.bind(this)
      this.keyboardWillHide = this.keyboardWillHide.bind(this)
  
      this.state = {
        isVisible: true
      }
    }
  
    componentWillMount() {
      this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardWillShow)
      this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardWillHide)
    }
  
    componentWillUnmount() {
      this.keyboardWillShowSub.remove()
      this.keyboardWillHideSub.remove()
    }
  
    keyboardWillShow = event => {
      this.setState({
        isVisible: false
      })
    }
  
    keyboardWillHide = event => {
      this.setState({
        isVisible: true
      })
    }
  
    render() {
      return this.state.isVisible ?
        <Footer>
            <FooterTab >
                <Button
                    transparent
                    active={this.props.navigation.state.index == 0}
                    onPress={() => this.props.navigation.navigate("Home")}>
                    <Image style={{height:iconSize,resizeMode:'contain',tintColor:'#ffffff'}} source={images.home} />
                </Button>
                <Button
                    transparent
                    active={this.props.navigation.state.index == 1}
                    onPress={() => this.props.navigation.navigate("Profile")}>
                    <Image style={{height:iconSize,resizeMode:'contain',tintColor:'#ffffff'}} source={images.profile}/>
                </Button>
                <Button
                    transparent
                    active={this.props.navigation.state.index == 2}
                    onPress={() => this.props.navigation.navigate("Messenger")}>
                    <Image style={{height:iconSize,resizeMode:'contain',tintColor:'#ffffff'}} source={images.messenger}/>
                </Button>
                <Button
                    transparent
                    active={this.props.navigation.state.index == 3}
                    onPress={() => this.props.navigation.navigate("Notification")}>
                    <Image style={{height:iconSize,resizeMode:'contain',tintColor:'#ffffff'}} source={images.notification}/>
                </Button>
                <Button
                    transparent
                    active={this.props.navigation.state.index == 4}
                    onPress={() => {this.props.navigation.navigate("StartRoute")}}>
                    <Image style={{height:iconSize,resizeMode:'contain', tintColor:'#ffffff'}} source={images.start}/>
                </Button>
            </FooterTab>
        </Footer>
        :
        null
    }
  }
  
  export default TabBarComponent