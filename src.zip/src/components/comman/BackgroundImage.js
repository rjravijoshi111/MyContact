import React from 'react';
import {ImageBackground, Platform, SafeAreaView, StatusBar} from 'react-native';
import images from "@src/config/path/Images";
const BackgroundImage = ({ children,style }) => {
    const { container } = styles;

    return (
        <ImageBackground source={images.backgroundApp} style={[container,style]}>
            <SafeAreaView style={{flex: 1}}>
                {children}
            </SafeAreaView>
        </ImageBackground>
    );
};

const styles = {
    container: {
        flex: 1,
        width:null,
        height: null,
       // paddingTop: Platform.OS === 'ios' ? 0 : StatusBar.currentHeight+10,

    },

};

export { BackgroundImage };