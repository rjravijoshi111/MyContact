import React, { Component } from "react"
import { StyleSheet, Text, View, Image, TouchableOpacity, Alert, Modal } from "react-native"
import PropTypes from "prop-types"

class AlertDialog extends Component {

    constructor(props) {
        super(props)
        this.state = {
            modalVisible: false,
            askAlways: true,
            alertsArr: []
        }
    
        this.checkbox = true
        this.modalID = null
        this.checkSaveBtnIdx = null
        this.title = " "
        this.messagesView = null
        this.buttons = []
        this.invisibleTime = null
    }

    customeAlert(messagesView) {
        // const typeError = this.typeChecker(title, messagesView, buttons, " ", 0)
        // if (typeError) {
        //   console.warn("TypeError, check the alert parameter")
        //   return
        // }
        // this.messagesView = messagesView
        this.openModal()
    }

    simpleAlert(title,msg,onPress = null){
        this.messagesView = (<View>
            <View style={{paddingBottom:10,marginTop:20}}>
                <Text style={styles.msgTextStyle}>{msg}</Text>
            </View>
            <View style={{borderBottomWidth:1, borderBottomColor:'#434546',marginVertical:25, width :'80%',alignSelf:'center'}} />
            <View>
                <Text style={[styles.msgTextStyle,{color:'#355c7d'}]} onPress={() => {
                                        onPress()
                                        this.setModalVisible(false)
                                    }}>{"Ok"}</Text>
            </View>
            
        </View>)
        this.openModal()
    }

    openModal(alertData = null) {
        this.setModalVisible(true)
        // if (alertData == null) {
        //         this.setModalVisible(true)
        //     return
        // }
        // alertData.show ? this.setModalVisible(true) : this.buttons[this.checkSaveBtnIdx].onPress()
    }

    setModalVisible(visible, buttonIdx = null) {
        this.setState({ modalVisible: visible })
    }

    render(){
        const { children } = this.props;
        return(
            <View>
                <Modal
                    // {...this.props.modalProps}
                    visible={this.state.modalVisible}
                    transparent={true}
                    animationType={ "slide"}
                    onRequestClose={() => this.setModalVisible(false)}
                    >
                    <View style={styles.modalContainer}>
                        <View style={styles.modalView}>
                            {/* {this.messagesView} */}
                            {children ? children : this.messagesView}
                            {/* {(this.title != "") && <Text style={styles.titleText}>
                                {this.title}
                            </Text>}
                            {this.messagesView}
                            <View style={styles.buttonContainer}>
                                {this.buttons.map((button, index) => {
                                return (
                                    <TouchableOpacity
                                    key={index}
                                    onPress={() => {
                                        button.onPress()
                                        this.setModalVisible(false, index)
                                    }}
                                    style={[styles.button,{borderLeftWidth: (index > 0 ) ? 1 : 0}]}
                                    >
                                    <Text style={{color:'#355c7d'}}>
                                        {button.text}
                                    </Text>
                                    </TouchableOpacity>
                                )
                                })}
                            </View> */}
                        </View>
                    </View>
                </Modal>
            </View>
        )
    }
}

export { AlertDialog };

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: "rgba(49,49,49, 0.7)",
        justifyContent: "center",
        alignItems: "center"
    },
    modalView: {
        backgroundColor: "#fff",
        borderRadius: 5,
        width: 275,
        padding:20
        // borderColor: "black",
        // borderWidth: StyleSheet.hairlineWidth
    },
    checkBox: {
        marginBottom: 10
    },
    checkBoxText: {
        marginLeft: 4,
        alignSelf: "center",
        fontSize: 15,
        justifyContent: "center"
    },
    titleText: {
        fontSize: 17,
        fontWeight: "600",
        padding: 15,
        alignSelf: "center"
    },
    msgTextStyle :{
        fontSize: 15,
        textAlign: "center",
        color : '#355c7d',
        fontWeight : 'bold'
    },
    buttonContainer: {
        flexDirection: "row",
        justifyContent: "flex-end",
        borderColor: "gray",
        // borderTopWidth: StyleSheet.hairlineWidth
    },
    buttonText: {
        fontSize: 17
    },
    button: {
        flex:1,
        justifyContent: "center",
        alignItems: "center",
        paddingVertical: 5,
        marginVertical : 10,
        borderColor: "gray",
    }
})