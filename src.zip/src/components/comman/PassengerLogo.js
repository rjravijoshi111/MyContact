import React, {Component} from 'react';
import {Dimensions, ImageBackground, View,StyleSheet} from "react-native";
import images from "@src/config/path/Images";
import Image from 'react-native-image-progress';
import ProgressBar from 'react-native-progress/Pie';

let widthFactor = 0.6;
const PassengerLogo =({ style,imageSrc }) => {
    return (
        <View style={[styles.circleContainer]}>
            <ImageBackground source={images.roleCircle} style={[styles.circle]}>
                <Image
                    resizeMode={'cover'}
                    source={imageSrc}
                    indicator={ProgressBar}
                    style={[styles.roleImage]}/>
            </ImageBackground>
        </View>
    );
};


const heightFactor = widthFactor*0.7;
const circleFactor = widthFactor*0.4;
const roleFactor = circleFactor*0.6;
const styles = StyleSheet.create({
    roleImage:{
        width:'94%',
        height:'93%',
        overflow: 'hidden',
        borderRadius: 50,
    },
    circle:{
        width:Dimensions.get('window').width*circleFactor,
        height:Dimensions.get('window').width*circleFactor,
        justifyContent: 'center',
        alignItems: 'center'

    },
    circleContainer:{
        elevation:5,
        zIndex:100
    }
});

export { PassengerLogo };