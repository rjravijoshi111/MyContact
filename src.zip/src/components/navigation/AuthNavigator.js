import React from "react";
import {Image, Platform, StatusBar} from 'react-native';
import { createStackNavigator,HeaderBackButton } from 'react-navigation';
import Login from '../Guest/Login';
import Register from '../Guest/Register';
import ConfirmEmail from '../Guest/ConfirmEmail';
import ForgotPassword from '../Guest/ForgotPassword';
const AuthStack = createStackNavigator({
    Login: {
        screen: Login,
        navigationOptions: {
            title: "Login",
            header: null,
        }
    },
    Register: {
        screen: Register,
        navigationOptions: ({navigation})=>({
            header: null,
        })
    },
    ForgotPassword: {
        screen: ForgotPassword,
        navigationOptions: ({navigation})=>({
            header: null,
        })
    },
    ConfirmEmail: {
        screen: ConfirmEmail,
        navigationOptions: ({navigation})=>({
            title: "Login/Register",
            headerTransparent: true,
            headerStyle: {
                backgroundColor: 'transparent',
                borderBottomWidth: 0,
                elevation: 2,
                shadowColor: 'black',   
                shadowRadius: 5,
                shadowOpacity: 0.1,
                shadowOffset: {
                    height: 3,
                    width: 0,
                },

                paddingTop: Platform.OS === 'ios' ? 0 : StatusBar.currentHeight,

            },
            headerTitleStyle: {
                alignSelf: "center",
                fontSize: 20,
                fontWeight: 'normal'
            },
            headerLeft: <HeaderBackButton onPress={() => navigation.goBack()} />,
        })

    }
},
{
    initialRouteName: "Login",
    /*navigationOptions: ({ navigation }) => ({
        headerTitle: (
            <Image
                style={{ height: "50%", resizeMode: "contain" }}
                source={images.logoApp}
            />
        ),
        headerStyle: {
            backgroundColor: colors.app,
            elevation: 0,
            shadowOpacity: 0,
            borderBottomWidth: 0
        },
        headerTitleStyle: {
            alignSelf: "center",
            fontSize: 16
        },
        headerBackTitleStyle: {
            color: colors.blue
        },
        headerTintColor: "white",
        shadowColor: "red"
    })*/
});

export default AuthStack;
