import { createSwitchNavigator,createAppContainer } from 'react-navigation';
import AuthHandler from './AuthHandler';
import Auth from './AuthNavigator';

import App from './AppNavigator';

const NavStack = createSwitchNavigator(
    {
        App,
        Auth,
        AuthHandler,
    },
    {
        initialRouteName: 'AuthHandler',
    },
);
const Navigation = createAppContainer(NavStack);

export default Navigation;