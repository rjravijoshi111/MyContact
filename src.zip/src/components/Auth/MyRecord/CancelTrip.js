import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem, Picker } from "native-base";
import Lang from '@src/config/localization';
import { AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import DatePicker from 'react-native-datepicker';
const { height, width } = Dimensions.get("window");

export default class CancelTrip extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            queList : []
        }
    }

    onPressSave = () => {
        const { emptyRouteAlertMsg,emptyReasoneAlertMsg } = Lang.cancelTrip;
        let SimpleView = (<View style={styles.alertView}>
            <Text style={styles.alertLabel}>{emptyRouteAlertMsg}</Text>
        </View>)
        this.awesomAlert.alert("", SimpleView, [
            { text: "OK", onPress: () => console.log("OK touch") }
        ])
    }

    render() {
        const { title,cancelRouteMsg,choose,resoneMsg,selectResone,vactionMsg,select } = Lang.cancelTrip;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header> 
                <Content style={{minHeight : height}}>
                    <View style={{marginTop:30}}>
                        <Text style={[styles.label,{marginHorizontal:7}]}>{cancelRouteMsg}</Text>
                        <View style={styles.selectView}>
                            <Picker
                                mode={"dropdown"}
                                iosHeader={choose}
                                iosIcon={<FontAwesome name="caret-down" style={{marginRight:10}} size={9} />}
                                placeholder={choose}
                                placeholderStyle={{ color: "#000" }}
                                selectedValue={this.state.selectedColor}
                                style={{ height: 40, width: width,marginLeft:-7}}
                                onValueChange={(itemValue, itemPosition) => this.setState({ selectedColor: itemValue, selectedColorId: (itemValue != -1 && itemValue != '-1') ? this.state.color.filter(x => x.clrName == itemValue)[0].pcClrID : -1 })}
                                >
                                <Picker.Item label={"Select Color"} value={"-1"} />
                                {this.state.queList.map((item, key) => {
                                    return (<Picker.Item label={item.clrName} value={item.clrName} key={key} />)
                                })}
                            </Picker> 
                        </View>
                    </View>
                    <View style={{marginTop:30}}>
                        <Text style={[styles.label,{marginHorizontal:7}]}>{resoneMsg}</Text>
                        <View style={styles.selectView}>
                            <Picker
                                mode={"dropdown"}
                                iosHeader={selectResone}
                                iosIcon={<FontAwesome name="caret-down" style={{marginRight:10}} size={9} />}
                                placeholder={selectResone}
                                placeholderStyle={{ color: "#000" }}
                                selectedValue={this.state.selectedColor}
                                style={{ height: 40, width: width,marginLeft:-7}}
                                onValueChange={(itemValue, itemPosition) => this.setState({ selectedColor: itemValue, selectedColorId: (itemValue != -1 && itemValue != '-1') ? this.state.color.filter(x => x.clrName == itemValue)[0].pcClrID : -1 })}
                                >
                                <Picker.Item label={"Select Color"} value={"-1"} />
                                {this.state.queList.map((item, key) => {
                                    return (<Picker.Item label={item.clrName} value={item.clrName} key={key} />)
                                })}
                            </Picker> 
                        </View>
                    </View>
                    <View style={{marginTop:30}}>
                        <Text style={[styles.label,{marginHorizontal:7}]}>{vactionMsg}</Text>
                        <View style={[styles.selectView,{height:40,justifyContent:'center'}]}>
                            <Text>{select}</Text>
                        </View>

                        <DatePicker
                            style={styles.inputContainer}
                            date={new Date()} //initial date from state
                            mode="date" //The enum of date, datetime and time
                            // placeholder={birthday}
                            format="DD-MM-YYYY"
                            // maxDate={today}
                            confirmBtnText="Confirm"
                            cancelBtnText="Cancel"
                            showIcon={false}
                            customStyles={{
                                dateInput: [styles.input, { alignItems: 'flex-start', borderWidth: 0 }],
                                placeholderText: {},
                                // dateText:{textAlign:'left'}
                            }}
                            onDateChange={(date) => this.dateChanged(date)}
                        />
                    </View>
                    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                        <Button style={styles.okButton} onPress={this.onPressSave}>
                            <Text style={[styles.label, { fontWeight: 'bold',color:'#fff' }]}>{"Ok"}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    selectView:{
        // marginHorizontal : 20,
        backgroundColor:'#fff',
        marginTop: 5
    },
    label:{
        fontSize : 15,
        color :'#000'
    },
    okButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 150,
        paddingHorizontal: 25
    },
    alertView:{
        paddingVertical: 20, marginHorizontal: 30, borderBottomWidth: 1, borderBottomColor: '#434546', alignItems: 'center', marginTop: 20
    },
    alertLabel:{
        textAlign: 'center', fontSize: 15,color:'#355c7d',fontWeight:'bold'
    }
});
