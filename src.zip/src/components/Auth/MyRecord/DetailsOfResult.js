import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Text, Body, Content, View, Card, List } from "native-base";
import ProgressBarAnimated from 'react-native-progress-bar-animated';

import Lang from '@src/config/localization';
import { PassengerLogo, AlertDialog } from '@comman';
import { Dimensions, StyleSheet, Image, TouchableOpacity, Alert, FlatList } from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import { connect } from "react-redux";

const { height, width } = Dimensions.get("window");

class DetailsOfResult extends Component {

    constructor(props) {
        super(props);
        this.state = {
            image_url: images.passenger
        }
    }

    rejectedRequest = () => {
        const { rejectMsg, rejectedRequest } = Lang.acceptOrReject;
        const { yes, no } = Lang.common;
        this.awesomAlert.simpleAlert("", rejectedRequest, () => { })
    }

    onPressReject = () => {
        const { rejectMsg } = Lang.acceptOrReject;
        const { yes, no } = Lang.common;

        let SimpleView = (<View style={styles.rejectAlertView}>
            <Text style={styles.rejectAlertTitle}>{rejectMsg}</Text>

            <View style={{ marginTop: 30 }}>
                <Button style={styles.yesButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                    <Text style={[styles.label, { fontWeight: 'bold' }]}>{yes}</Text>
                </Button>

                <Text style={styles.noButton} onPress={() => console.log("Dismiss")}>{no}</Text>
            </View>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }

    render() {
        const { title } = Lang.home;
        const { input, carDetails, brand, model, plates, depatureMsg, press, startRoute } = Lang.detailsOfResult;
        const { route, countess, house, car, meeting, avenue, by_car, point_of_arrival, pass, santa_fe, work, passengers_contribution,
            credits, to_accept, to_refuse } = Lang.acceptOrReject;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
                        <View style={styles.profilePic}>
                            <PassengerLogo imageSrc={this.state.image_url} />
                        </View>
                        <Card style={styles.ratingView}>
                            <Text style={styles.label}>{"Andres Galvez"}</Text>
                            <Text style={styles.label}>{"4.1"}</Text>
                            <StarRating
                                disabled={true}
                                maxStars={5}
                                rating={3}
                                starSize={25}
                                emptyStarColor={"#EDBF3F"}
                                fullStarColor={"#EDBF3F"}
                            // selectedStar={(rating) => this.onStarRatingPress(rating)}
                            />
                            <Text style={[styles.label, { marginTop: 10 }]}>{"Enviar mensaje"}</Text>
                        </Card>
                    </View>
                    <View style={styles.passengerTextView}>
                        <Text style={{ flex: 0.8, fontSize: 12 }}>
                            {route}
                        </Text>
                        <Text style={[styles.label, { flex: 0.2 }]}>
                            {"LMM"}
                            <Text style={{ color: 'lightgray', fontWeight: 'normal', fontSize: 12 }}>
                                {"JVSD"}
                            </Text>
                        </Text>
                    </View>
                    <View style={{ flexDirection: 'row', marginHorizontal: 10 }}>
                        <Image source={images.barra_RUUTA} style={{ height: 150, width: 10, marginVertical: 10 }} resizeMode={"stretch"} />
                        <View style={{ flexDirection: 'column', margin: 5, flex: 1, justifyContent: 'space-around' }}>
                            <Text style={[styles.label]}>
                                {countess + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {house}
                                </Text>
                            </Text>
                            <Text style={[styles.label, styles.label3]}>
                                {car}
                            </Text>
                            <Text style={[styles.label]}>
                                {meeting + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {avenue}
                                </Text>
                            </Text>
                            <Text style={[styles.label, styles.label3]}>
                                {by_car}
                            </Text>

                            <Text style={[styles.label]}>
                                {point_of_arrival + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {pass}
                                </Text>
                            </Text>
                            <Text style={[styles.label, styles.label3]}>
                                {car}
                            </Text>
                            <Text style={[styles.label]}>
                                {santa_fe + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {work}
                                </Text>
                            </Text>
                        </View>
                    </View>
                    <View style={[styles.passengerTextView, { marginTop: 10 }]}>
                        <Text style={{ flex: 0.7, fontSize: 12 }}>
                            {input}
                        </Text>
                        <Text style={[styles.label2, styles.label]}>
                            {credits}
                        </Text>
                    </View>
                    <View style={[styles.passengerTextView, { marginTop: 10 }]}>
                        <Text style={{ flex: 0.7, fontSize: 12 }}>
                            {carDetails}
                        </Text>
                    </View>

                    <View style={{ marginTop: 10, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 10 }}>
                        <View style={{ paddingVertical: 5 }}>
                            <Text style={[styles.label2]}>
                                {brand + " : "}
                                <Text style={[styles.label, styles.label]}>
                                    {'Skoda'}
                                </Text>
                            </Text>
                            <Text style={[styles.label2]}>
                                {model + " : "}
                                <Text style={[styles.label, styles.label]}>
                                    {'Citigo, 2014'}
                                </Text>
                            </Text>
                            <Text style={[styles.label2]}>
                                {plates + " : "}
                                <Text style={[styles.label, styles.label]}>
                                    {'NDH898JKL'}
                                </Text>
                            </Text>
                            <Text style={[styles.label2]}>
                                {"Color" + " : "}
                                <Text style={[styles.label, styles.label]}>
                                    {'Gris'}
                                </Text>
                            </Text>
                        </View>
                        {/* <View style={{borderWidth:1,alignItems:'center'}}> */}
                        <Image source={images.iconNews} style={{ height: 69, width: 69 }} />
                        {/* </View> */}
                        {/* <View style={{borderWidth:1}}> */}
                        <Image source={images.boarding_pass_con_sombra} style={{ width: 110, height: 75 }} />
                        {/* </View> */}
                    </View>
                    <View style={{ flexDirection: 'row', marginHorizontal: 10, alignItems: 'center' }}>
                        <Image source={images.icono_triangulo_rojo} style={{ height: 30, width: 30 }} resizeMode={"contain"} />
                        <Text style={[styles.label, { marginHorizontal: 10 }]} numberOfLines={2}>{depatureMsg}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', marginHorizontal: 10, alignItems: 'center', marginTop: 10 }}>
                        <Text style={[styles.label]} numberOfLines={2}>{press}</Text>
                        <Image source={images.start} style={{ height: 20, width: 20 }} resizeMode={"contain"} />
                        <Text style={styles.label}>{startRoute}</Text>
                    </View>

                    {/* <View style={{margin:10}}>
                        <Text style={styles.bottomRightText} onPress={this.onPressReject}>{to_refuse}</Text>
                        <Button style={styles.inviteFriendButton} onPress={() => this.props.navigation.navigate('RequestList')}>
                            <Text style={[styles.label, { fontWeight: 'bold' }]}>{to_accept}</Text>
                        </Button>
                    </View> */}
                </Content>
            </Container>
        )
    }
}

const mapStateToProps = state => ({
    user: state.profile.user,
    loading: state.auth.loading,
    unique_person: state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({

});
export default connect(mapStateToProps)(DetailsOfResult);

const styles = StyleSheet.create({
    emptyListStyle: {
        height: height - 150,
        width,
        alignItems: 'center',
        justifyContent: 'center'
    },
    noReviewText: {
        // fontFamily:'Roboto-Light',
        fontSize: 15,
        color: '#000',
        marginTop: 20
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    label2: {
        color: '#355c7d',
        fontWeight: 'bold'
    },
    label3: {
        color: '#000', fontSize: 7
    },
    ratingView: {
        marginTop: 60,
        alignItems: 'center', justifyContent: 'center', width: width / 1.8, paddingVertical: 30, alignSelf: 'center', marginBottom: 30
    },
    watermarkImage: {
        width: 200, height: 200, position: 'absolute', zIndex: 0, alignSelf: 'center', marginTop: 50
    },
    profilePic: {
        position: 'absolute', zIndex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    inviteFriendButton: {
        borderRadius: 0,
        justifyContent: 'center',
        alignSelf: 'center',
        // justifyContent: 'center',
        // marginTop: 30
    },
    passengerTextView: {
        flexDirection: 'row', backgroundColor: '#fff', paddingVertical: 5, paddingHorizontal: 10, justifyContent: 'space-between'
    },
    bottomView: {
        flex: 1, flexDirection: 'row', marginTop: 20, alignItems: 'center', justifyContent: 'center'
    },
    bottomRightText: {
        textAlign: 'center', position: 'absolute', right: 40, fontSize: 9, textDecorationLine: 'underline', color: '#355c7d',
    },
    rejectAlertTitle: {
        textAlign: 'center', fontSize: 15, marginHorizontal: 40
    },
    yesButton: {
        borderRadius: 0, width: 100, alignItems: 'center', justifyContent: 'center'
    },
    noButton: {
        textAlign: 'center', fontSize: 9, textDecorationLine: 'underline', color: '#355c7d', marginTop: 10
    },
    rejectAlertView: {
        alignItems: 'center'
    },
    profilePic2: {
        alignItems: 'center',
        justifyContent: 'center',
    },
});