import React from 'react';
import { createStackNavigator } from "react-navigation";

import RouteTransformer from './RouteTransformer';
import RoutesEffectiveConductorPassage from './RoutesEffectiveConductorPassage';
import CancelTrip from './CancelTrip';
import DetailsOfResult from './DetailsOfResult';
export default createStackNavigator(

    {
        RouteTransformer:{
            screen:RouteTransformer
        },
        RoutesEffectiveConductorPassage:{
            screen:RoutesEffectiveConductorPassage
        },
        CancelTrip:{
            screen:CancelTrip
        },
        DetailsOfResult: {
            screen: DetailsOfResult
        },
    },
    {
        initialRouteName: 'RouteTransformer',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);