import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, FlatList, StyleSheet, View, Image, TouchableOpacity, TextInput } from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import Ionicons from 'react-native-vector-icons/Ionicons'
const { height, width } = Dimensions.get("window");
export default class RouteTransformer extends React.Component {
    constructor(props) {
        super(props);
        const { discriminatoryLanguage, misconduct, bullying, strayObject, anotherReason, registeredReport, text1, text2 } = Lang.routeTransformer;
        this.state = {
            selectRoute: 1,
            myReviewsList: [1, 2, 3],
            alertDialogList: [{ title: discriminatoryLanguage, isSelected: false },
            { title: misconduct, isSelected: false },
            { title: bullying, isSelected: false },
            { title: strayObject, isSelected: false },
            { title: anotherReason, isSelected: false }],

            alertDialogList2: [{ title: registeredReport },
            { title: text1 },
            { title: text2 }]
        }
    }

    _renderItem = (item) => {
        const { reportProblem } = Lang.routeTransformer;
        return (
            <ListItem navigation={this.onPressItem} buttonText={reportProblem} buttonColor={"#f81a00"} />
        )
    }

    // _ListEmptyComponent = () =>{
    //     const { noReveiw} = Lang.myReviews;
    //     return(
    //         <View style={styles.emptyListStyle}>
    //             <Image source={images.thumbsup_sin_background} style={{width:150,height:150}} resizeMode={"cover"} />
    //             <Text style={styles.noReviewText}>{noReveiw}</Text>
    //         </View>
    //     )
    // }

    _alertDialogRender = (item) => {
        const { submit } = Lang.routeTransformer;
        let data = item.item
        return (
            <View style={{ flex: 1 }}>
                <View style={styles.alertDialogList}>
                    <Text style={styles.alertDialogText}>
                        {data.title}
                    </Text>
                    <Ionicons name='ios-radio-button-off' size={18} />
                </View>
            </View>
        );
    }

    _alertDialogRender2 = (item) => {
        const { submit, registeredReport } = Lang.routeTransformer;
        let data = item.item
        return (
            <View style={{ flex: 1 }}>
                <View style={styles.alertDialogList}>
                    <Text style={styles.alertDialogText}>
                        {data.title}
                    </Text>
                </View>
            </View>
        );
    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }
    onPressItem2 = () => {
        const { reportProblem } = Lang.routeTransformer;

        let SimpleView = (<View >
            <View style={styles.alertDialogView}>
                <View style={{ padding: 5 }}>
                    <Image source={images.image_report_a_problem_con_sombra} style={{ height: 75, width: 48.5 }} resizeMode={"cover"} />
                </View>
                <Text style={styles.title}>
                    {reportProblem}
                </Text>
            </View>

            <FlatList
                style={{ marginTop: 15, backgroundColor: 'transparent' }}
                data={this.state.alertDialogList2}
                renderItem={this._alertDialogRender2}
                // ListEmptyComponent={this._ListEmptyComponent}
                keyExtractor={(item, index) => index.toString()}
            />

            <Button style={styles.okButton}>
                <Text style={{ alignItems: 'center' }}>Ok</Text>
            </Button>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }
    render() {
        const { myHistory } = Lang.myHistory;
        const { routesMade, futureRoutes, cancel, reportProblem, submit } = Lang.routeTransformer;

        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                >
                    <View >
                        <Text
                            onPress={() => this.awesomAlert.setModalVisible(false)}
                            style={{ color: '#355c7d', fontSize: 12 }}>
                            {cancel}
                        </Text>
                        <View style={styles.alertDialogView}>
                            <View style={{ padding: 5 }}>
                                <Image source={images.image_report_a_problem_con_sombra} style={{ height: 75, width: 48.5 }} resizeMode={"cover"} />
                            </View>
                            <Text style={styles.title}>
                                {reportProblem}
                            </Text>
                        </View>

                        <FlatList
                            style={{ marginTop: 15, backgroundColor: 'transparent' }}
                            data={this.state.alertDialogList}
                            renderItem={this._alertDialogRender}
                            // ListEmptyComponent={this._ListEmptyComponent}
                            keyExtractor={(item, index) => index.toString()}
                        />
                        <View style={styles.textInputView}>
                            <TextInput
                                multiline
                                style={styles.textInputStyle}
                                underlineColorAndroid='transparent'
                                onSubmitEditing={this.props.submitSubscriber}
                                ref={c => this.textInput = c}
                            />
                        </View>

                        <Button style={styles.inviteFriendButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                            <Text>{submit}</Text>
                        </Button>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{myHistory}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                {/* <Content> */}
                <View style={styles.selectRouteContainer}>
                    <TouchableOpacity style={[styles.selectRoute, { flex: 1, borderColor: '#d2d2d2', borderWidth: this.state.selectRoute === 1 ? 1 : null }]} onPress={() => this.setState({ selectRoute: 1 })}>
                        <Text style={[styles.label, { color: '#355c7d' }]}>{routesMade}</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.selectRoute, { flex: 1, borderColor: '#d2d2d2', borderWidth: this.state.selectRoute === 2 ? 1 : null }]} onPress={() => this.setState({ selectRoute: 2 })}>
                        <Text style={[styles.label, { color: '#355c7d' }]}>{futureRoutes}</Text>
                    </TouchableOpacity>
                </View>
                <View>
                    <FlatList
                        style={{ backgroundColor: 'transparent' }}
                        data={this.state.alertDialogList}
                        renderItem={this._renderItem}
                        // ListEmptyComponent={this._ListEmptyComponent}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </View>
                {/* </Content> */}
            </Container>
        )
    }
}
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 125, width: 227
    },
    titleText: {
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 15, marginTop: 20
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 50, textAlign: 'center', marginTop: 20
    },
    label: {
        fontSize: 12,
        fontFamily: 'Roboto'
    },
    label2: {
        fontWeight: 'bold',
        color: '#355c7d'
    },
    label3: {
        textAlign: 'right'
    },
    selectRouteContainer: {
        marginHorizontal: 20,
        flexDirection: 'row', justifyContent: 'space-between'
    },
    selectRoute: {
        borderRadius: 0,
        height: 30,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 30
    },
    seeButton: {
        borderRadius: 0,
        height: 18,
        backgroundColor: '#ff0000',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    itemMailContainer: {
        paddingHorizontal: 10, backgroundColor: '#fff', marginHorizontal: 20, marginTop: 20
    },
    itemTopMiddaleView: {
        flex: 1, paddingHorizontal: 10, justifyContent: 'space-evenly'
    },
    itemMiddleView: {
        flexDirection: 'row', flex: 1, alignItems: 'center'
    },
    itemMiddleInnerView: {
        justifyContent: 'space-between', height: '100%', paddingVertical: 2, paddingLeft: 10
    },
    itemTopRightView: {
        flex: 0.6, alignItems: 'flex-end', justifyContent: 'space-around'
    },
    title: { marginTop: 15, color: '#355c7d', fontSize: 15, fontWeight: 'bold' },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
    alertDialogText:
    {
        fontSize: 12, color: '#010101', fontFamily: 'Roboto'
    },
    textInputView: {
        marginTop: 20,
        height: 50.5,
        borderColor: '#000',
        borderWidth: 0.5
    },
    textInputStyle: {
        fontSize: 12,
        flex: 9,
        color: colors.black,
        paddingLeft: 10,
    },
    inviteFriendButton: {
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 15
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 25,
        marginBottom: 25
    },
});
