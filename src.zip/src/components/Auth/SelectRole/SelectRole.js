import React, {Component} from 'react';
import {StyleSheet, View,Dimensions, TouchableOpacity,ImageBackground,Text,Image} from 'react-native';
import {BackgroundImage} from "@src/components/comman";
import {connect} from "react-redux";
import Lang from '@src/config/localization';
import images from "@src/config/path/Images";
import colors from '@src/config/Colors';
import {roleSelected} from '@modules/selectRole/role.action';
const imgScale = 562/329;

const widthFactor = 0.42;
const heightFactor = widthFactor*imgScale;

const circleFactor = widthFactor*0.6;

const roleFactor = widthFactor*0.9;
class SelectRole extends Component {

    onRoleChange(role) {
        this.props.roleSelected(role);
    }
    render(){
        return (
            <BackgroundImage>
                    <View style={styles.container}>
                        <Text style={styles.roleHeader}>{Lang.selectRole.roleHeader}</Text>
                        <Text style={styles.roleHeader}>{Lang.selectRole.driverOrPassenger}</Text>
                        <View style={styles.cardsContainer}>
                            <RoleCard
                                action={this.onRoleChange.bind(this,1)}
                                roleImage={images.passengerShadowed}
                                roleText={Lang.selectRole.passenger}/>
                            <RoleCard
                                action={this.onRoleChange.bind(this,2)}
                                roleImage={images.driverShadowed}
                                roleText={Lang.selectRole.driver}/>
                        </View>
                    </View>
            </BackgroundImage>
        );
    }
}
const RoleCard = ({roleImage,roleText,action}) =>{

    return(
        <TouchableOpacity onPress={action} activeOpacity={0.8}>
            <View style={styles.cardParent}>
                <View style={styles.circleContainer}>
                    <ImageBackground source={images.roleCircle} style={styles.circle}>
                        <Text>{roleText}</Text>
                    </ImageBackground>
                </View>
                <ImageBackground source={images.cardImage} style={styles.cardImage}>
                    <Image source={roleImage} style={styles.roleImage}/>
                </ImageBackground>
            </View>
        </TouchableOpacity>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    aStyle:{
        width:1,
    },

    cardsContainer:{
        width:Dimensions.get('window').width,
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'space-around',
    },

    cardParent:{
        paddingVertical:Dimensions.get('window').width*circleFactor/2,
    },

    circleContainer:{
        elevation:5,
        zIndex:100,
        position:'absolute',
        top:0,
        left:Dimensions.get('window').width*( (widthFactor/2) - (circleFactor/2) ),
    },

    roleImage:{
        resizeMode:'contain',
        width:Dimensions.get('window').width*roleFactor,
    },

    roleHeader:{
        fontSize:18,
        color:colors.black,
        paddingBottom:24,
        //fontWeight:'bold',
    },

    circle:{
        width:Dimensions.get('window').width*circleFactor,
        height:Dimensions.get('window').width*circleFactor,
        alignItems:'center',
        justifyContent:'center',
    },

    cardImage:{
        width:Dimensions.get('window').width*widthFactor,
        height:Dimensions.get('window').width*heightFactor,

        justifyContent:'center',
        alignItems:'center',
    },
});
const mapStateToProps = state => ({
    user_role:state.role.user_role
});
const mapDispatchToProps = dispatch => ({
    roleSelected: (role) => dispatch(roleSelected(role))
});
export default connect(mapStateToProps,mapDispatchToProps)(SelectRole);