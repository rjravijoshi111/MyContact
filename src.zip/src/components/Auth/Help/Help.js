import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class Help extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            dataList: [
                { image: images.help, title: "Preguntas frecuentes", navigate: '' },
                { image: images.icono_como_funciona, title: "¿Cómo funciona?", navigate: '' },
                { image: images.icono_Terminos_y_condiciones, title: "Politica de privacidad", navigate: '' },
                { image: images.icono_triangulo_rojo, title: "Términos y condiciones", navigate: '' },
                { image: images.guigo_redondo_verde, title: "Califica la app", navigate: '' },
                { image: images.icono_contact_us, title: "Contáctanos", navigate: 'ContactUs' }
            ]
        }
    }
    onPressItem = () => {
        const { experience, whatThikAboutApp, qualify } = Lang.help;
        let SimpleView = (<View >
            <View style={styles.alertDialogView}>
                <View style={{ padding: 5 }}>
                    <Image source={images.guigo_redondo_verde} style={{ height: 67, width: 67 }} resizeMode={"cover"} />
                </View>
                <Text style={styles.alertDialogTextTitle}>
                    {experience}
                </Text>
                <Text style={styles.alertDialogText}>
                    {whatThikAboutApp}
                </Text>
                <Button style={styles.qualifyButton} onPress={() => this.props.navigation.navigate('RequestList')}>
                    <Text style={{ fontSize: 15, color: "#fff" }}>{qualify}</Text>
                </Button>
                <Text style={styles.alertDialogTextTitle}>
                    No
                </Text>
            </View>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }

    _renderItem = (item) => {
        let data = item.item;
        return (
            <TouchableOpacity
                onPress={() => this.props.navigation.navigate(data.navigate)}
                style={{ height: 86.5, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: 'lightgray', flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ marginHorizontal: 10 }}>
                    <Image source={data.image} style={{ width: 34.5, height: 34, resizeMode: 'contain' }} />
                </View>
                <View style={{ flex: 1, justifyContent: 'center' }}>
                    <Text style={{ alignItems: 'center', justifyContent: 'center', color: '#000', fontSize: 15 }}>
                        {data.title}
                    </Text>
                </View>
                <View style={{ justifyContent: 'flex-end' }}>
                    <Image source={images.baseline_keyboard_arrow_right} style={{ width: 10, height: 15, marginHorizontal: 10 }} />
                </View>
            </TouchableOpacity>
        )
    }

    render() {
        const { title, message, invitation, findingDriver, surprisesAndReward } = Lang.help;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <FlatList
                        bounces={false}
                        style={{ backgroundColor: 'transparent', paddingTop: 20 }}
                        data={this.state.dataList}
                        renderItem={this._renderItem}
                        // ListEmptyComponent={this._ListEmptyComponent}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    qualifyButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 30
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogTextTitle:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginTop: 10
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row' },
    alertDialogText:
    {
        fontSize: 12, color: '#434546', fontFamily: 'Roboto', marginVertical: 10
    },
});