import React from 'react';
import { createStackNavigator } from "react-navigation";

import Help from './Help';
import ContactUs from './ContactUs';

export default createStackNavigator(

    {
        Help: {
            screen: Help
        },
        ContactUs:{
            screen:ContactUs
        }
    },
    {
        initialRouteName: 'Help',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);