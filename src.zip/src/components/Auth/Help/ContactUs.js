import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class ContactUs extends React.Component {

    constructor(props) {
        super(props);

    }

    render() {
        const { title, submit ,enterYourText} = Lang.contactUs;
        return (
            <Container>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} >
                        <Text style={{ fontSize: 12.5, color: '#434546' }}>
                            {submit}
                        </Text>
                    </Right>
                </Header>
                <Content>
                    <View style={{ margin: 20 }}>
                        <View style={{ alignItems: 'center', flexDirection: 'row' }}>
                            <Text style={{ fontSize: 12.5, margin: 10, flex: 0.2 }}>
                                De :
                            </Text>
                            <View style={styles.inputContainer}>
                                <TextInput style={styles.input}
                                    placeholder={"mons.jade@gmail.com"}
                                    // onChangeText={this.firstNameChanged.bind(this)}
                                    value={"mons.jade@gmail.com"}
                                ></TextInput>
                            </View>
                        </View>
                        <View style={{ alignItems: 'center', flexDirection: 'row' }}>
                            <Text style={{ fontSize: 12.5, margin: 10, flex: 0.2 }}>
                                A :
                            </Text>
                            <View style={styles.inputContainer}>
                                <TextInput style={styles.input}
                                    placeholder={"soporte@guigo.com.mx"}
                                    // onChangeText={this.firstNameChanged.bind(this)}
                                    value={"soporte@guigo.com.mx"}
                                ></TextInput>
                            </View>
                        </View>
                    </View>
                    <View style={styles.extraText}>
                        <TextInput style={styles.input}
                            multiline
                            placeholder={enterYourText}
                            // onChangeText={this.firstNameChanged.bind(this)}
                            // value={enterYourText}
                        ></TextInput>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    inputContainer: {
        justifyContent: 'center',
        height: 18,
        backgroundColor: '#fff',
        width: 222.5,
        borderBottomWidth: 1,
        borderBottomColor: '#D5D5D7',
    },
    input: {
        paddingLeft: 10,
        color: "#000",
        fontSize: 10,
        fontStyle: "normal",
        letterSpacing: 0,
    },
    extraText: {
        marginLeft:20,
        justifyContent: 'flex-start',
        width: 346.5,
        height: 484,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#D5D5D7',
    }
});