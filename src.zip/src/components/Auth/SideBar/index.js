import React, { Component } from "react";
import { View, Image, ScrollView, Switch, TouchableOpacity } from "react-native";
import { Container, Content, Text, ListItem } from "native-base";
import { NavigationActions, DrawerActions } from 'react-navigation';
import images from "@src/config/path/Images";
import { connect } from 'react-redux';
import { PassengerLogo } from '@comman';
import Lang from '@src/config/localization';
import colors from '@src/config/Colors';
import { roleSelected } from '@modules/selectRole/role.action';
import Storage from "@modules/utils/Storage";
import { store } from '../../../reducers'
import * as ProfileAction from "@modules/profile/profile.action";
class SideBar extends React.Component {
    navigateToScreen = (route) => () => {
        const navigateAction = NavigationActions.navigate({
            routeName: route
        });
        this.props.navigation.dispatch(navigateAction);
        this.props.navigation.dispatch(DrawerActions.closeDrawer())
    }

    constructor(props) {
        super(props);

        this.state = {
            image_url: images.passenger
        }
    }

    componentDidMount() {
        Storage.getItem('user_profile').then(result => {
            if (result) {
                console.log("Drawer screen->", JSON.stringify(result))
                store.dispatch(ProfileAction.setUserProfile(result));
                this.setState({
                    image_url: { uri: result.profile_image_url }
                })
            }
        });
    }

    render() {
        const { home, routes, credits, record, payments, invite, settings, help } = Lang.mainDrawer;
        return (

            <View style={styles.container}>
                <View
                    style={{
                        height: '30%',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderBottomColor: 'black',
                        borderBottomWidth: 1,
                    }}
                >
                    <View style={styles.logoContainer}>
                        <PassengerLogo imageSrc={this.state.image_url} />
                    </View>
                    <View style={styles.changeRoleContainer}>
                        <Text>Passenger</Text>
                        <Switch
                            value={(this.props.user_role == 1) ? false : true}
                            style={styles.switch}
                            trackColor={colors.blue}
                            onValueChange={(role) => this.props.roleSelected((role) ? 2 : 1)}
                        /><Text>Driver</Text>
                    </View>
                </View>
                <View style={{ flex: 1 }}>
                    {/* <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("Main")}>
                        <View style={[styles.itemMenu,{flex:1}]}>
                            <Image style={styles.iconItem} source={images.routes}/>
                            <Text style={styles.itemTitle}> {"Home"} </Text>
                        </View>
                    </TouchableOpacity> */}
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("MyRoute")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.routes} />
                            <Text style={styles.itemTitle}> {routes} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("MyRecord")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.record} />
                            <Text style={styles.itemTitle}> {record} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("MyCredits")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.credits} />
                            <Text style={styles.itemTitle}> {credits} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={() => { this.props.navigation.closeDrawer() }}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.payments} />
                            <Text style={styles.itemTitle}> {payments} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("InviteFriend")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.invite} />
                            <Text style={styles.itemTitle}> {invite} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("Settings")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.settings} />
                            <Text style={styles.itemTitle}> {settings} </Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.itemMenu} onPress={this.navigateToScreen("Help")}>
                        <View style={styles.itemMenu}>
                            <Image style={styles.iconItem} source={images.help} />
                            <Text style={styles.itemTitle}> {help} </Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}
const icSize = 30;

const paddingTopFactor = 0.08;
const styles = {
    container: {
        backgroundColor:'#fff',
        flex: 1
    },
    logoContainer: {

    },
    itemMenu: {
        //borderColor:'red',
        //borderWidth:1,
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        // width: '100%',
    },
    iconItem: {
        //borderWidth:1,
        borderColor: 'white',
        resizeMode: 'contain',
        height: icSize,
        width: icSize,
        marginRight: 12,
        marginLeft: 12
    },

    itemTitle: {
        fontSize: 14,
        color: colors.black,
    },
    changeRoleContainer: {
        flexDirection: 'row',
        marginTop: 10
    },
    switch: {
        transform: [{ scaleX: 0.75 }, { scaleY: 0.75 }]
    },
    navItemStyle: {
        padding: 10
    },
    navSectionStyle: {
        backgroundColor: 'lightgrey'
    },
    sectionHeadingStyle: {
        paddingVertical: 10,
        paddingHorizontal: 5
    },
    footerContainer: {
        padding: 20,
        backgroundColor: 'lightgrey'
    }
};

const mapStateToProps = state => ({
    user_role: state.role.user_role,
    user: state.profile.user,
});
const mapDispatchToProps = dispatch => ({
    roleSelected: (role) => dispatch(roleSelected(role)),
});
export default connect(mapStateToProps, mapDispatchToProps)(SideBar);