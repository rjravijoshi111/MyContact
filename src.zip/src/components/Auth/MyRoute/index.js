import React from 'react';
import { createStackNavigator } from "react-navigation";

import MyRoute from './MyRoute';
import CreateDrivePath from './CreateDrivePath';
import CreatePassengerRoute from './CreatePassengerRoute';
import StartPoint from './StartPoint';
import RegisterRoute from './RegisterRoute';

export default createStackNavigator(

    {
        MyRoute:{
            screen:MyRoute
        },
        CreateDrivePath:{
            screen:CreateDrivePath
        },
        CreatePassengerRoute:{
            screen:CreatePassengerRoute
        },
        StartPoint:{
            screen:StartPoint
        },
        RegisterRoute:{
            screen:RegisterRoute
        }
    },
    {
        initialRouteName: 'MyRoute',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);