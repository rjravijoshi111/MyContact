import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import Slider from 'react-native-slider';
const { height, width } = Dimensions.get("window");
export default class RegisterRoute extends React.Component {

    constructor(props) {
        super(props);

        this.state = {

        }
    }

    onPressSave = () => {
        const { chooseNameOfRoute } = Lang.createDrivePath;
        let SimpleView = (<View style={{ paddingVertical: 20, marginHorizontal: 30, borderBottomWidth: 1, borderBottomColor: '#434546', alignItems: 'center', marginTop: 20 }}>
            <Text style={{ textAlign: 'center', fontSize: 15 }}>{chooseNameOfRoute}</Text>
        </View>)
        this.awesomAlert.alert("", SimpleView, [
            { text: "OK", onPress: () => console.log("OK touch") }
        ])
    }

    render() {
        const { myRoute, houseWork, workHouse, houseWork1, workHouse1, add } = Lang.registerRoute;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{myRoute}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{marginTop:30}}>
                        <View style={styles.imageContainer}>
                            <Image source={images.mis_rutas} style={styles.images} resizeMode={"contain"} />
                        </View>
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{houseWork}</Text>
                            <Image source={images.baseline_keyboard_arrow_right} style={{height:20,width:10}} resizeMode={"contain"} />                            
                        </View>
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{workHouse}</Text>
                            <Image source={images.baseline_keyboard_arrow_right} style={{height:20,width:10}} resizeMode={"contain"} />                            
                        </View>
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{houseWork1}</Text>
                            <Image source={images.baseline_keyboard_arrow_right} style={{height:20,width:10}} resizeMode={"contain"} />                            
                        </View>
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{workHouse1}</Text>
                            <Image source={images.baseline_keyboard_arrow_right} style={{height:20,width:10}} resizeMode={"contain"} />                            
                        </View>
                        <Button style={styles.saveButton} onPress={this.onPressSave}>
                            <Text style={[styles.label, { fontWeight: 'bold' }]}>{add}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 211, width: 289
    },
    numberImages: { height: 35.5, width: 35.5 },
    titleText: {
        fontFamily: 'Roboto', fontSize: 15, marginTop: 20
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    itemView: {
        flexDirection: 'row',
        paddingHorizontal:10,
        alignItems:'center',
        justifyContent: 'space-between',
        height: 40,
        backgroundColor: '#fff',
        marginTop: 10,
    },
    textStyle: {
        color: '#000',
        fontFamily: 'Roboto',
        fontSize: 12,
    },
    saveButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 150,
        paddingHorizontal: 25
    },


    imageContainer: {
        height: height - 340,
        width,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: 0.3
    }
});
