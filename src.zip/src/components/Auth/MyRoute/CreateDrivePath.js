import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { connect } from 'react-redux';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput, Modal, TouchableOpacity, Animated } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import Slider from 'react-native-slider';
import { AlertDialog } from '@comman';
import {startPointAddressChanged,endPointAddressChanged,
    startPointChanged,endPointChanged,routeNameChanged,
    startHoursChanged,desireStopChanged,frequencyDaysChanged , } from  "@modules/myRoute/myRoute.action";
import {validateCreatePath} from '@src/config/Validation';
import {createRoute} from "@modules/myRoute/myRoute.service";
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import Geocoder from 'react-native-geocoding';

const { height, width } = Dimensions.get("window");
class CreateDrivePath extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            addressModalVisible : false,
            startPointAddress : '',
            startPointLatitude : null,
            startPointLongitude : null,
            endPointAddress : '',
            endPointLatitude : null,
            endPointLongitude : null,
            isStartPoint : true,
            desireStop_1 : new Animated.Value(1),
            desireStop_2 : new Animated.Value(1),
            desireStop_3 : new Animated.Value(1),
            selectedDesirePoint : '',
            frequency:[],
            frequencyDay_1 : new Animated.Value(1),
            frequencyDay_2 : new Animated.Value(1),
            frequencyDay_3 : new Animated.Value(1),
            frequencyDay_4 : new Animated.Value(1),
            frequencyDay_5 : new Animated.Value(1),
            frequencyDay_6 : new Animated.Value(1),
            frequencyDay_7 : new Animated.Value(1),
            closingHour : '00:00'
        }
    }

    onPressSave = () => {
        // const { chooseNameOfRoute } = Lang.createDrivePath;
        // this.awesomAlert.simpleAlert("", chooseNameOfRoute, () => { })

        const { startPointAddress,endPointAddress,startHours,routeName,desireStop,frequencyDays,startPoint,endPoint } = this.props;
        const fields = { startPointAddress,endPointAddress,startHours,routeName,desireStop,frequencyDays };
        const result = validateCreatePath(fields,this.awesomAlert);
        if(result){
            // let client_id = "0D4416AB-37DE-4585-AB45-930A7CD38B28";
            let startPointData = {
                "latitude": startPoint.lat,
                "longitude": startPoint.lng
            }

            let endPointData = {
                "latitude": endPoint.lat,
                "longitude": endPoint.lng
            }
            let data = { 'start': startPointData, 'end': endPointData, 'name': routeName, 'start_hour': startHours, 'places': desireStop, 'repeat_days': frequencyDays }
            this.props.createRoute(data,this);
        }
    }

    addressSelect = (address,points) =>{
        if(this.state.isStartPoint){
            this.props.startPointAddressChanged(address)
            this.props.startPointChanged(points)
        }else{
            this.props.endPointAddressChanged(address)
            this.props.endPointChanged(points)
        }
        this.setState({ addressModalVisible : false })
    }

    routeNameChanged = (text) =>{
        this.props.routeNameChanged(text)
    }

    getCurrentLocation(){
        Geocoder.init('AIzaSyDPJm1qJnmQXWvvczS301HMwg7euUZnu_Q');
        navigator.geolocation.getCurrentPosition(
            (position) => {
                console.log("wokeeey");
                console.log(position);
                
                Geocoder.from(position.coords.latitude, position.coords.longitude)
                .then(json => {
                    let points = {
                        latitude : json.results[0].geometry.location.lat,
                        longitude : json.results[0].geometry.location.lng,
                    }
                    this.addressSelect(json.results[0].formatted_address);
                    this.props.startPointChanged(points)
                })
                .catch(error => console.warn(error));
            },
            (error) => this.setState({ error: error.message }),
            { enableHighAccuracy: false, timeout: 200000, maximumAge: 1000 },
        );
    }

    addressModal(){
        const { title, completeAddress,currentLocation ,address1,address2,example,note} = Lang.startPoint;
        return(
            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.addressModalVisible}
                onRequestClose={() => {
                    this.setState({ addressModalVisible : false })
                }}>

                <Container>
                    <Header>
                        <Left style={{ flex: 0.2 }}>
                            <Text style={styles.headerbuttonText} onPress={() => this.setState({ addressModalVisible : false })}>{"Cancel"}</Text>
                        </Left>
                        <Body>
                            <Title>{title}</Title>
                        </Body>
                        <Right style={{ flex: 0.2 }} >
                            <Text style={styles.headerbuttonText} onPress={this.addressSelect}>{"OK"}</Text>
                        </Right>
                    </Header>

                    <Content>
                        <View style={{marginTop:20}}>
                            <View >
                                <GooglePlacesAutocomplete
                                    placeholder={completeAddress}
                                    minLength={2} // minimum length of text to search
                                    autoFocus={false}
                                    returnKeyType={'search'} // Can be left out for default return key https://facebook.github.io/react-native/docs/textinput.html#returnkeytype
                                    keyboardAppearance={'light'} // Can be left out for default keyboardAppearance https://facebook.github.io/react-native/docs/textinput.html#keyboardappearance
                                    listViewDisplayed='auto'    // true/false/undefined
                                    fetchDetails={true}
                                    renderDescription={row => row.description} // custom description render
                                    onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
                                        let address = details && details.formatted_address || ''
                                        let points = details && details.geometry && details.geometry.location || ''
                                        console.log("Points-->",JSON.stringify(points))
                                        this.addressSelect(address,points);
                                    }}
                                    getDefaultValue={() => ''}
                                    query={{
                                        // available options: https://developers.google.com/places/web-service/autocomplete
                                        key: 'AIzaSyDPJm1qJnmQXWvvczS301HMwg7euUZnu_Q',
                                        language: 'en', // language of the results
                                        types: 'geocode' // default: 'geocode'
                                    }}
                                    styles={{
                                        textInputContainer: {
                                            width: '100%'
                                        },
                                        description: {
                                            fontWeight: 'bold'
                                        },
                                        predefinedPlacesDescription: {
                                            color: '#1faadb'
                                        }
                                    }}
                                    currentLocation={false} // Will add a 'Current location' button at the top of the predefined places list
                                    currentLocationLabel="Current location"
                                    nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
                                    GoogleReverseGeocodingQuery={{
                                        // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
                                    }}
                                    GooglePlacesSearchQuery={{
                                        // available options for GooglePlacesSearch API : https://developers.google.com/places/web-service/search
                                        rankby: 'distance',
                                        type: 'cafe'
                                    }}
                                    GooglePlacesDetailsQuery={{
                                        // available options for GooglePlacesDetails API : https://developers.google.com/places/web-service/details
                                        fields: 'formatted_address',
                                    }}
                                    filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities
                                    // predefinedPlaces={[homePlace, workPlace]}
                                    predefinedPlacesAlwaysVisible={true}
                                    debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 0ms.
                                    // renderLeftButton={()  => <Image source={require('path/custom/left-icon')} />}
                                    // renderRightButton={() => <Text>{"Custom text after the input"}</Text>}
                                />
                            </View>
                            <TouchableOpacity style={styles.modalItemView} onPress={() => this.getCurrentLocation()}>
                                <Image source={images.posicion_actual} style={styles.images} resizeMode={"contain"} />
                                <Text style={[styles.label,{marginHorizontal: 10}]}>{currentLocation}</Text>
                            </TouchableOpacity>

                            <View style={{ justifyContent:'space-around',height:40,alignItems:'center',marginTop:20}}>                            
                                <Text style={styles.label}>{example}</Text>
                                <Text style={[styles.label,{marginTop:10}]}>{note}</Text>
                            </View>
                        </View>
                    </Content>
                </Container>
            </Modal>
        )
    }

    onDesireChange = (type) => {

        if(type == 1){
            Animated.parallel([
                Animated.timing(this.state.desireStop_1,{
                    toValue : 1.5
                }),
                Animated.timing(this.state.desireStop_2,{
                    toValue : 1
                }),
                Animated.timing(this.state.desireStop_3,{
                    toValue : 1
                })
            ]).start()
        }else if(type == 2){
            Animated.parallel([
                Animated.timing(this.state.desireStop_1,{
                    toValue : 1
                }),
                Animated.timing(this.state.desireStop_2,{
                    toValue : 1.5
                }),
                Animated.timing(this.state.desireStop_3,{
                    toValue : 1
                })
            ]).start()
        }else{
            Animated.parallel([
                Animated.timing(this.state.desireStop_1,{
                    toValue : 1
                }),
                Animated.timing(this.state.desireStop_2,{
                    toValue : 1
                }),
                Animated.timing(this.state.desireStop_3,{
                    toValue : 1.5
                })
            ]).start()
        }

        this.props.desireStopChanged(type)
    };

    onFrequencySelect = (id) =>{
        const { frequency } = this.state;
        let tempFrequency = frequency;
        if(id == 1){
            if(frequency.indexOf(id) > -1){
                Animated.spring(this.state.frequencyDay_1,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_1,{
                    toValue : 1.5
                }).start()
            }
        }else if(id == 2){

            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_2,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_2,{
                    toValue : 1.5
                }).start()
            }

        }else if(id == 3){
            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_3,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_3,{
                    toValue : 1.5
                }).start()
            }
        }else if(id == 4){
            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_4,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_4,{
                    toValue : 1.5
                }).start()
            }
        }else if(id == 5){
            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_5,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_5,{
                    toValue : 1.5
                }).start()
            }
        }else if(id == 6){
            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_6,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_6,{
                    toValue : 1.5
                }).start()
            }
        }else{
            if(frequency.indexOf(id) >= 0){
                Animated.spring(this.state.frequencyDay_7,{
                    toValue : 1
                }).start()
            }else{
                Animated.spring(this.state.frequencyDay_7,{
                    toValue : 1.5
                }).start()
            }
        }
        let index = tempFrequency.indexOf(id);
        if(index >= 0){
            tempFrequency.splice(index,1);
        }else{
            tempFrequency = [...tempFrequency,id]
        }
        
        this.setState(prevState => ({
            frequency: tempFrequency
        }))
        this.props.frequencyDaysChanged(tempFrequency)
    };

    onSliderValueChange = (num) =>{
        var hours   = Math.floor(Number(num) / 3600);
        var minutes = Math.floor((Number(num) - (hours * 3600)) / 60);
        this.setState({
            closingHour : hours + ":" + minutes
        })
        this.props.startHoursChanged(Math.floor(Number(num) / 60))
    }

    render() {
        const { myRoute, startingPoint, address, pointOfArrival, nameYourRoute, homeWork, closingHour, desiredStops, frequencyOfYourRoute, save, deleteRoute } = Lang.createDrivePath;
        return (
            <Container>
                {this.addressModal()}
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{myRoute}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{}}>
                        <View style={styles.imageContainer}>
                            <Image source={images.mis_rutas} style={styles.images} resizeMode={"contain"} />
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{startingPoint}</Text>
                            <TouchableOpacity onPress={() => this.setState({addressModalVisible : true,isStartPoint : true})} style={[styles.textInputStyle, {justifyContent:'center'}]}>
                                <Text style={{fontSize:12}}>{(this.props.startPointAddress != '') ? this.props.startPointAddress : address}</Text>
                            </TouchableOpacity>
                            {/* <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                value={this.props.startPointAddress}
                                placeholder={address}
                                onFocus={() => this.setState({addressModalVisible : true,isStartPoint : true})}
                                {...this.props}
                                ref={c => this.textInput = c}
                            /> */}
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{pointOfArrival}</Text>
                            <TouchableOpacity onPress={() => this.setState({addressModalVisible : true,isStartPoint : false})} style={[styles.textInputStyle, {justifyContent:'center'}]}>
                                <Text style={{fontSize:12}}>{this.props.endPointAddress != '' ? this.props.endPointAddress : address}</Text>
                            </TouchableOpacity>
                            {/* <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                value={this.props.endPointAddress}
                                placeholder={address}
                                onFocus={() => this.setState({addressModalVisible : true,isStartPoint : false})}
                                {...this.props}
                                ref={c => this.textInput = c}
                            /> */}
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{nameYourRoute}</Text>
                            <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                value={this.props.routeName}
                                placeholder={homeWork}
                                onChangeText={this.routeNameChanged.bind(this)}
                                {...this.props}
                                ref={c => this.textInput = c}
                            />
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{closingHour}</Text>
                            <View style={{flexDirection:'row',justifyContent:'space-between',marginHorizontal:10,marginTop:5}}>
                                <Text style={styles.label}>{this.state.closingHour}</Text>
                                <Text style={styles.label}>{"00:00"}</Text>
                            </View>
                            <View style={{ flexDirection: 'row', width: width, alignItems: 'center' }}>
                                <View style={{ height: 8, width: 8, borderRadius: 4, backgroundColor: '#355c7d', marginLeft: 10 }} />
                                <Slider
                                    minimumValue={0}
                                    maximumValue={86400}
                                    value={0}
                                    animateTransitions={true}
                                    thumbStyle={{ opacity: 0.9, height: 24, width: 25, borderRadius: 12.5 }}
                                    style={{ width: '90%', marginLeft: -2 }}
                                    minimumTrackTintColor={"#355c7d"}
                                    maximumTrackTintColor={"#EDBF3F"}
                                    onValueChange={this.onSliderValueChange.bind(this)} />
                                <View style={{ height: 8, width: 8, borderRadius: 4, backgroundColor: '#EDBF3F', marginLeft: -2 }} />
                            </View>
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{desiredStops}</Text>
                            <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginVertical: 10 }}>
                                <TouchableOpacity onPress={this.onDesireChange.bind(this,1)}>
                                    <Animated.Image source={images.circulo_Numero_1} style={[styles.numberImages,
                                            {transform : [{scale : this.state.desireStop_1}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onDesireChange.bind(this,2)}>
                                    <Animated.Image source={images.circulo_Numero_2} style={[styles.numberImages,
                                            {transform : [{scale : this.state.desireStop_2}],marginHorizontal : 15}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onDesireChange.bind(this,3)}>
                                    <Animated.Image source={images.circulo_Numero_3} style={[styles.numberImages,
                                            {transform : [{scale : this.state.desireStop_3}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                            </View>
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{frequencyOfYourRoute}</Text>
                            <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginVertical: 10, justifyContent: 'space-around' }}>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,1)}>
                                    <Animated.Image source={images.circulo_Lunes} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_1}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,2)}>
                                    <Animated.Image source={images.circulo_Martes} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_2}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,3)}>
                                    <Animated.Image source={images.circulo_Miercoles} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_3}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,4)}>
                                    <Animated.Image source={images.circulo_Jueves} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_4}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,5)}>
                                    <Animated.Image source={images.circulo_Viernes} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_5}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,6)}>
                                    <Animated.Image source={images.circulo_Sabado} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_6}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={this.onFrequencySelect.bind(this,7)}>
                                    <Animated.Image source={images.circulo_domingo} style={[styles.numberImages,
                                            {transform : [{scale : this.state.frequencyDay_7}]}
                                    ]}  resizeMode={"contain"}/>
                                </TouchableOpacity>
                            </View>
                        </View>

                        <Button style={styles.saveButton} onPress={this.onPressSave}>
                            <Text style={[styles.label, { fontWeight: 'bold', color: '#fff' }]}>{save}</Text>
                        </Button>
                        {/* <Text style={styles.deleteText}>{deleteRoute}</Text> */}
                    </View>
                </Content>
            </Container>
        );
    }
}
const mapStateToProps = state => ({
    startPointAddress:state.myRoute.startPointAddress,
    endPointAddress:state.myRoute.endPointAddress,
    startPoint:state.myRoute.startPoint,
    endPoint:state.myRoute.endPoint,
    startHours:state.myRoute.startHours,
    routeName:state.myRoute.routeName,
    desireStop:state.myRoute.desireStop,
    frequencyDays:state.myRoute.frequencyDays,
});

const mapDispatchToProps = dispatch => ({
    startPointAddressChanged: (props) => dispatch(startPointAddressChanged(props)),
    endPointAddressChanged: (props) => dispatch(endPointAddressChanged(props)),
    startPointChanged: (props) => dispatch(startPointChanged(props)),
    endPointChanged: (props) => dispatch(endPointChanged(props)),
    routeNameChanged: (props) => dispatch(routeNameChanged(props)),
    startHoursChanged: (props) => dispatch(startHoursChanged(props)),
    desireStopChanged: (props) => dispatch(desireStopChanged(props)),
    frequencyDaysChanged: (props) => dispatch(frequencyDaysChanged(props)),
    createRoute: (props,_this) => dispatch(createRoute(props,_this)),
    loadingChanged: (loading) => dispatch(loadingChanged(loading)),
});
export default connect(mapStateToProps, mapDispatchToProps)(CreateDrivePath);

const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 211, width: 289
    },
    numberImages: { height: 35.5, width: 35.5 },
    titleText: {
        fontFamily: 'Roboto', fontSize: 15, marginTop: 20
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    textStyle: {
        color: '#000',
        fontFamily: 'Roboto',
        fontSize: 15,
        paddingLeft: 10
    },
    saveButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginVertical: 15,
        paddingHorizontal: 25
    },
    textInputStyle: {
        height: 38,
        backgroundColor: '#fff',
        fontSize: 12,
        flex: 9,
        color: colors.black,
        marginTop: 5,
        paddingLeft: 10
    },
    deleteText: {
        fontSize: 12.5,
        textDecorationLine: 'underline',
        color: '#355c7d',
        marginTop: 10,
        textAlign: 'center'
    },
    itemView: {
        marginTop: 10,
    },
    imageContainer: {
        height: height - 340,
        width,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: 0.3
    },
    images: {
        height: 23, width: 23
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 50, textAlign: 'center', marginTop: 20
    },
    inviteFriendButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 75
    },
    headerbuttonText:{
        fontSize: 12.5,
        color: '#355c7d'
    },
    label:{
        fontSize: 12.5,
        color: '#000'
    },
    modalItemView: {
        flexDirection: 'row' ,alignItems:'center',backgroundColor:'#fff',
        height:40,
        marginTop:5,
        paddingHorizontal:5

        // fontSize: 12,
        // justifyContent: 'center',
        // backgroundColor: '#fff',
        // height: 38,
        // marginVertical: 5,
    }
});
