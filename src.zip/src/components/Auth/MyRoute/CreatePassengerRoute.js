import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import {  AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import Slider from 'react-native-slider';
const { height, width } = Dimensions.get("window");
export default class CreatePassengerRoute extends React.Component {

    constructor(props){
        super(props);

        this.state ={

        }
    }

    onPressSave = () => {
        const { chooseNameOfRoute } = Lang.createDrivePath;
        let SimpleView = (<View style={{paddingVertical:20,marginHorizontal:30,borderBottomWidth:1,borderBottomColor:'#434546',alignItems:'center',marginTop:20}}>
            <Text style={{textAlign:'center',fontSize:15}}>{chooseNameOfRoute}</Text>
        </View>)
        this.awesomAlert.alert("", SimpleView, [
          { text: "OK", onPress: () => console.log("OK touch") }
        ])
      }
    
    render() {
        const { myRoute, startingPoint, address, pointOfArrival, nameYourRoute, homeWork, closingHour, desiredStops, frequencyOfYourRoute,save,deleteRoute } = Lang.createDrivePath;
        return (
            <Container>
                <AlertDialog 
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{myRoute}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{}}>
                        <View style={styles.imageContainer}>
                            <Image source={images.mis_rutas} style={styles.images} resizeMode={"contain"} />
                        </View>
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{startingPoint}</Text>
                            <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                defaultValue={address}
                                onSubmitEditing={this.props.submitSubscriber}
                                {...this.props}
                                ref={c => this.textInput = c}
                            />
                        </View>
                        
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{pointOfArrival}</Text>
                            <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                defaultValue={address}
                                onSubmitEditing={this.props.submitSubscriber}
                                {...this.props}
                                ref={c => this.textInput = c}
                            />
                        </View>
                        
                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{nameYourRoute}</Text>
                            <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                defaultValue={homeWork}
                                onSubmitEditing={this.props.submitSubscriber}
                                {...this.props}
                                ref={c => this.textInput = c}
                            />
                        </View>

                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{closingHour}</Text>
                            <Slider
                                minimumValue={0}
                                maximumValue={100}
                                value={20}
                                animateTransitions={true}
                                thumbStyle={{opacity:0.7,height : 24,width:25, borderRadius:12.5}}
                                style={{marginHorizontal:10}}
                                minimumTrackTintColor={"#355c7d"}
                                maximumTrackTintColor={"#EDBF3F"}
                                onValueChange={(value) => this.setState({ value })} />
                        </View>


                        <View style={styles.itemView}>
                            <Text style={styles.textStyle}>{frequencyOfYourRoute}</Text>
                            <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginVertical: 10 ,justifyContent:'space-around'}}>
                                <Image source={images.circulo_Lunes} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_Martes} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_Miercoles} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_Jueves} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_Viernes} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_Sabado} style={styles.numberImages} resizeMode={"contain"} />
                                <Image source={images.circulo_domingo} style={styles.numberImages} resizeMode={"contain"} />
                            </View>
                        </View>
                        
                        <Button style={styles.saveButton} onPress={this.onPressSave}>
                            <Text style={[styles.label,{fontWeight:'bold'}]}>{save}</Text>
                        </Button>
                        <Text style={styles.deleteText}>{deleteRoute}</Text>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 211, width: 289
    },
    numberImages: { height: 35.5, width: 35.5 },
    titleText: {
        fontFamily: 'Roboto', fontSize: 15, marginTop: 20
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    textStyle: {
        color: '#000',
        fontFamily: 'Roboto', 
        fontSize: 15, 
        paddingLeft:10
    },
    saveButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 15,
        paddingHorizontal : 25
    },
    textInputStyle: {
        height: 38,
        backgroundColor: '#fff',
        fontSize: 12,
        flex: 9,
        color: colors.black,
        marginTop:5,
        paddingLeft:10
    },
    deleteText:{
        fontSize: 12.5,
        textDecorationLine:'underline',
        color: '#355c7d',
        marginTop:10,
        textAlign:'center'
    },
    itemView:{
        marginTop: 10,
    },
    imageContainer :{
        height: height - 340,
        width,
        position :'absolute',
        alignItems:'center',
        justifyContent:'center',
        opacity:0.3
    }
});
