import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';

import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
const { height, width } = Dimensions.get("window");
export default class StartPoint extends React.Component {
    
    render() {
        const { header, searchMatch, search, doNotApp, sessionActive, inviteFriends } = Lang.home;
        const { title, completeAddress,currentLocation ,address1,address2,example,note} = Lang.startPoint;
        return (
            <Container>
                <Content>
                    <View style={{marginTop:20}}>
                        <View style={styles.itemView}>
                            <TextInput
                                style={[styles.textInputStyle, this.props.style]}
                                underlineColorAndroid='transparent'
                                placeholder={completeAddress}
                                onSubmitEditing={this.props.submitSubscriber}
                                {...this.props}
                                ref={c => this.textInput = c}
                            />
                        </View>
                        <View style={styles.itemView}>
                            <Image source={images.posicion_actual} style={styles.images} resizeMode={"contain"} />
                            <Text style={[styles.label,{marginHorizontal: 10}]}>{currentLocation}</Text>
                        </View>

                        <View style={[styles.itemView,{paddingLeft:35}]}>
                            <Text style={styles.label}>{address1}</Text>
                        </View>

                        <View style={[styles.itemView,{paddingLeft:35}]}>
                            <Text style={styles.label}>{address2}</Text>
                        </View>

                        <View style={{ justifyContent:'space-around',height:40,alignItems:'center',marginTop:20}}>                            
                            <Text style={styles.label}>{example}</Text>
                            <Text style={[styles.label,{marginTop:10}]}>{note}</Text>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 23, width: 23
    },
    titleText: {
        alignItems: 'center',
        fontFamily: 'Roboto', fontSize: 12, marginTop: 20
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 50, textAlign: 'center', marginTop: 20
    },
    inviteFriendButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 75
    },
    headerbuttonText:{
        fontSize: 12.5,
        color: '#355c7d'
    },
    label:{
        fontSize: 12.5,
        color: '#000'
    },
    itemView: {
        flexDirection: 'row' ,alignItems:'center',backgroundColor:'#fff',height:40,
        marginTop:5,
        paddingHorizontal:5

        // fontSize: 12,
        // justifyContent: 'center',
        // backgroundColor: '#fff',
        // height: 38,
        // marginVertical: 5,
    }
});
