import React from 'react';
import { createStackNavigator, createAppContainer } from "react-navigation";
import Home from './Home';
import RequestList from './RequestList';
import AcceptOrReject from './AcceptOrReject';
import RequestAccepted from './RequestAccepted';
import NoDriverFound from './NoDriverFound';
import ProfileSeenByPassenger from './ProfileSeenByPassenger';
import SearchFor from './SearchFor';

const navigator = createStackNavigator(
    {
        Home: {
            screen: Home
        },
        RequestList: {
            screen: RequestList
        },
        AcceptOrReject: {
            screen: AcceptOrReject
        },
        RequestAccepted: {
            screen: RequestAccepted
        },
        NoDriverFound: {
            screen:NoDriverFound
        },
        ProfileSeenByPassenger: {
            screen:ProfileSeenByPassenger
        },
        SearchFor:{
            screen: (screenProps) => <SearchFor {...screenProps} />
        }
    },
    {
        initialRouteName: 'SearchFor',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);

export default createAppContainer(navigator);