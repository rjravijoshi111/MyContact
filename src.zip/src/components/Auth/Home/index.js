import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { connect } from 'react-redux';

import DriverStackNavigator from './DriverStackNavigator';
import PassengerStackNavigator from './PassengerStackNavigator';

class Home extends Component{

    constructor(props){
        super(props);
    }

    render(){
        return(
            (this.props.user_role == 2) ? <DriverStackNavigator screenProps={this.props} /> : <PassengerStackNavigator screenProps={this.props}/>
        )
    }
}
const mapStateToProps = state => ({
    user_role:state.role.user_role
});


const mapDispatchToProps = dispatch => ({
    
});
export default connect(mapStateToProps, mapDispatchToProps)(Home);