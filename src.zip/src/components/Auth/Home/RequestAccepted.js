import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content,Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';

import {Dimensions, ImageBackground, StyleSheet, View,Image} from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
const { height, width } = Dimensions.get("window");
export default class RequestAccepted extends React.Component {
    render() {
        const { title,header,searchMatch,search,doNotApp,sessionActive,inviteFriends } = Lang.home;
        const { waiting,trip_details,message_service} = Lang.requestAccepted;
        return (
            <Container>
                <Header>
                    <Left style={{flex:0.2}}>
                    <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                    <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content>
                    <View style={styles.content}> 
                        <Image source={images.luchador_con_sombra} style={styles.images} resizeMode={"contain"} />
                        <Text style={styles.titleText}>{waiting}</Text>

                        <Text style={styles.subTitleText}>{trip_details}</Text>

                        <Button style={styles.inviteFriendButton} onPress={() => this.props.navigation.navigate('RequestList')}>
                            <Text>{message_service}</Text>
                        </Button>
                        
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor*0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    content:{
        height:height-130,alignItems:'center',justifyContent:'center'
    },
    images :{
        height:125,width:142
    },
    titleText:{
        fontFamily : 'Roboto', fontWeight:'bold',fontSize:15,marginTop:20
    },
    subTitleText:{
        color:'#020202',
        fontFamily : 'Roboto',fontSize:12,marginHorizontal:50,textAlign:'center',marginTop:20
    },  
    inviteFriendButton:{
        borderRadius:0,
        alignSelf:'center',
        justifyContent :'flex-end',
        marginTop : 75
    }

});
