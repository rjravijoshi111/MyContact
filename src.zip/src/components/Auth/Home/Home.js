import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content,Text, Card, CardItem } from "native-base";
import { connect } from 'react-redux';
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import {store} from "../../../reducers";
import {NavigationActions, NavigationEvents} from "react-navigation";
import {Dimensions, ImageBackground, StyleSheet, View,Image} from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import {getRouteRequest} from  "@modules/home/home.service";
const { height, width } = Dimensions.get("window");

class HomeScreen extends React.Component {

    constructor(props){
        super(props);

    }

    componentDidMount(){
    }

    render() {
        const { title,header,searchMatch,search,doNotApp,sessionActive,inviteFriends } = Lang.home;
        return (
            <Container>
                <NavigationEvents
                    onWillFocus={payload => this.props.getRouteRequest()}
                    onDidFocus={payload => console.log('did focus',payload)}
                    onWillBlur={payload => console.log('will blur',payload)}
                    onDidBlur={payload => console.log('did blur',payload)}
                    />
                <Header>
                    <Left style={{flex:0.2}}>
                        <Button
                            transparent
                            onPress={() => this.props.screenProps.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }}  />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content>
                    <View style={styles.content}> 
                        <Image source={images.conductor} style={styles.images} resizeMode={"contain"} />
                        <Text style={styles.titleText}>{doNotApp}</Text>
                        <Text style={styles.subTitleText}>{sessionActive}</Text>
                        <Button style={styles.inviteFriendButton} onPress={() => store.dispatch(NavigationActions.navigate({ routeName: 'InviteFriend' }))}>
                            <Text>{inviteFriends}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}

const mapStateToProps = state => ({
    routeRequest:state.home.routeRequest,
});

const mapDispatchToProps = dispatch => ({
    getRouteRequest: () => dispatch(getRouteRequest())
});
export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);
const widthFactor = 0.8;
const heightFactor = widthFactor*0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content:{
        height:height-130,alignItems:'center',justifyContent:'center'
    },
    images :{
        height:125,width:227
    },
    titleText:{
        fontFamily : 'Roboto', fontWeight:'bold',fontSize:15,marginTop:20
    },
    subTitleText:{
        fontFamily : 'Roboto',fontSize:12,marginHorizontal:50,textAlign:'center',marginTop:20
    },  
    inviteFriendButton:{
        borderRadius:0,
        alignSelf:'center',
        justifyContent :'flex-end',
        marginTop : 75
    }
});