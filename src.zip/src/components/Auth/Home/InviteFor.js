import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { PassengerLogo, AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
const { height, width } = Dimensions.get("window");

export default class InviteFor extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            image_url: images.passenger
        }
    }

    render() {
        const { title, reday, find_match, search_for, no_match, active_session, without_match } = Lang.passenger;
        return (
            <Container>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={styles.content}>
                        <Image source={images.passenger} style={styles.images} resizeMode={"contain"} />
                        <Text style={styles.lable}>{reday}</Text>

                        <Text style={styles.lable}>{find_match}</Text>
                        <Button style={styles.searchForButton} onPress={() => this.props.navigation.navigate('RequestList')}>
                            <Icon name="menu" style={{ color: "yellow" }} />
                            <Text>{search_for}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        marginTop: 30,
        height: height - 130, alignItems: 'center'
    },
    images: {
        height: 104.5, width: 91.5
    },
    lable: {
        fontFamily: 'Roboto', fontSize: 20, marginTop: 20, color: '#000'
    },
    searchForButton: {
        flexDirection: 'column',
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 100
    }
});
