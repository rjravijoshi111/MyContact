import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { ListItem } from '@comman';
import { Dimensions, FlatList, StyleSheet, View, Image, TouchableOpacity } from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
const { height, width } = Dimensions.get("window");
export default class RequestList extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            myReviewsList: [1, 2, 3],
        }
    }

    _renderItem = (item) => {
        const { countless, sntaFe, closingHours, input,see_request } = Lang.requestList;
        return (
            <ListItem navigation={() => this.props.navigation.navigate("AcceptOrReject")} buttonText={see_request} buttonColor={"#355c7d"} />  
        )
    }

    // _ListEmptyComponent = () =>{
    //     const { noReveiw} = Lang.myReviews;
    //     return(
    //         <View style={styles.emptyListStyle}>
    //             <Image source={images.thumbsup_sin_background} style={{width:150,height:150}} resizeMode={"cover"} />
    //             <Text style={styles.noReviewText}>{noReveiw}</Text>
    //         </View>
    //     )
    // }

    render() {
        const { title } = Lang.home;
        return (
            <Container>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                {/* <Content> */}
                <View>
                    <FlatList
                        style={{ backgroundColor: 'transparent' }}
                        data={this.state.myReviewsList}
                        renderItem={this._renderItem}
                        // ListEmptyComponent={this._ListEmptyComponent}
                        keyExtractor={(item, index) => index.toString()}
                    />
                </View>
                {/* </Content> */}
            </Container>
        )
    }
}
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 125, width: 227
    },
    titleText: {
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 15, marginTop: 20
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 50, textAlign: 'center', marginTop: 20
    },
    inviteFriendButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 75
    },
    label: {
        fontSize: 12,
        fontFamily: 'Roboto'
    },
    label2: {
        fontWeight: 'bold',
        color: '#355c7d'
    },
    label3: {
        textAlign: 'right'
    },
    seeButton: {
        borderRadius: 0,
        height: 18,
        backgroundColor: '#355c7d',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 5
    },
    itemMailContainer: {
        paddingHorizontal: 10, backgroundColor: '#fff', marginHorizontal: 20, marginTop: 20
    },
    itemTopMiddaleView: {
        flex: 1, paddingHorizontal: 10, justifyContent: 'space-evenly'
    },
    itemMiddleView: {
        flexDirection: 'row', flex: 1, alignItems: 'center'
    },
    itemMiddleInnerView: {
        justifyContent: 'space-between', height: '100%', paddingVertical: 2, paddingLeft: 10
    },
    itemTopRightView: {
        flex: 0.6, alignItems: 'flex-end', justifyContent: 'space-around'
    }
});
