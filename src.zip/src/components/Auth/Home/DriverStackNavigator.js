import React from 'react';
import { createStackNavigator, createAppContainer } from "react-navigation";
import Home from './Home';
import RequestList from './RequestList';
import AcceptOrReject from './AcceptOrReject';
import RequestAccepted from './RequestAccepted';
import NoDriverFound from './NoDriverFound';
import ProfileSeenByPassenger from './ProfileSeenByPassenger';
import SearchFor from './SearchFor';
const navigator = createStackNavigator(
    {
        Home: {
            screen:(screenProps) => <Home {...screenProps} />
        },
        RequestList: {
            screen: RequestList
        },
        AcceptOrReject: {
            screen: AcceptOrReject
        },
        RequestAccepted: {
            screen: RequestAccepted
        },
        NoDriverFound: {
            screen:NoDriverFound
        },
        ProfileSeenByPassenger: {
            screen:ProfileSeenByPassenger
        },
        SearchFor:{
            screen:SearchFor
        }
    },
    {
        initialRouteName: 'Home',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);

export default createAppContainer(navigator);