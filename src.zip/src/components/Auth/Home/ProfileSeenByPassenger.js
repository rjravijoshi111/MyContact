import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { PassengerLogo, AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import StarRating from 'react-native-star-rating';
import images from "@src/config/path/Images";
import Slider from 'react-native-slider';
const { height, width } = Dimensions.get("window");

export default class ProfileSeenByPassenger extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            image_url: images.passenger
        }
    }
    render() {
        const { title, profession, CEO, phone, verified, identification, driverLicense, chat, news, music, lastConneection, responseRate } = Lang.profile;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ marginTop: 10, alignItems: 'center' }}>
                        <View style={styles.profilePic}>
                            <PassengerLogo imageSrc={this.state.image_url} />
                        </View>
                        <View style={{ marginTop: 10 }}>
                            <Text style={[styles.label,{ textAlign: 'center' }]}>{"Andres Galvez"}</Text>
                            <Text style={[styles.label,{ textAlign: 'center' }]}>{"28 year"}</Text>
                            <StarRating
                                disabled={true}
                                maxStars={5}
                                rating={3}
                                starSize={25}
                                emptyStarColor={"#EDBF3F"}
                                fullStarColor={"#EDBF3F"}
                            // selectedStar={(rating) => this.onStarRatingPress(rating)}
                            />
                        </View>
                    </View>
                    <View style={{marginTop:10}}>
                        <View style={styles.itemView}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.textStyle}>{profession}</Text>
                            </View>
                            <View style={styles.verifiedContainer}>
                                <Text style={styles.textStyle}>{CEO}</Text>
                            </View>
                        </View>
                        <View style={styles.itemView}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.textStyle}>{phone}</Text>
                            </View>
                            <View style={styles.verifiedContainer}>
                                <Text style={styles.textStyle}>{verified}</Text>
                                <Image source={images.verificado} style={styles.imageContainer} resizeMode={"contain"} />
                            </View>
                        </View>
                        <View style={styles.itemView}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.textStyle}>{profession}</Text>
                            </View>
                            <View style={styles.verifiedContainer}>
                                <Text style={styles.textStyle}>{verified}</Text>
                                <Image source={images.verificado} style={styles.imageContainer} resizeMode={"contain"} />
                            </View>
                        </View>
                        <View style={styles.itemView}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.textStyle}>{identification}</Text>
                            </View>
                            <View style={styles.verifiedContainer}>
                                <Text style={styles.textStyle}>{verified}</Text>
                                <Image source={images.verificado} style={styles.imageContainer} resizeMode={"contain"} />
                            </View>
                        </View>
                        <View style={styles.itemView}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.textStyle}>{driverLicense}</Text>
                            </View>
                            <View style={styles.verifiedContainer}>
                                <Text style={styles.textStyle}>{verified}</Text>
                                <Image source={images.verificado} style={styles.imageContainer} resizeMode={"contain"} />
                            </View>
                        </View>
                    </View>
                    
                    <View style={styles.preferencesIconContainer}>
                        
                        <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={() => alert("Chat")}>
                            <View style={[styles.block_sex]}>
                                <Image source={images.iconChat} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                <Text style={styles.imageLable}>{chat}</Text>
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={() => alert("News")}>
                            <View style={[styles.block_sex]}>
                                <Image source={images.iconNews} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                <Text style={styles.imageLable}>{news}</Text>
                            </View>
                        </TouchableOpacity>
                        
                        <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={() => alert("Music")}>
                            <View style={[styles.block_sex]}>
                                <Image source={images.iconMusic} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                <Text style={styles.imageLable}>{music}</Text>
                            </View>
                        </TouchableOpacity> 

                    </View>
                    <View style={{paddingHorizontal:10}}>
                        <Text style={styles.label}>{lastConneection}</Text>
                        <Text style={[styles.label,{marginTop:5}]}>{responseRate}</Text>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;


const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    profilePic: {

        alignItems: 'center',
        justifyContent: 'center',
    },
    images: {
        height: 211, width: 289
    },
    numberImages: { height: 35.5, width: 35.5 },
    titleText: {
        fontFamily: 'Roboto', fontSize: 15, marginTop: 20
    },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    itemView: {
        flexDirection: 'row',
        paddingHorizontal: 10,
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical:5,
        backgroundColor: '#fff',
        marginTop: 10,
    },
    textStyle: {
        color: '#355c7d',
        fontFamily: 'Roboto',
        fontSize: 12,
    },
    saveButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 150,
        paddingHorizontal: 25
    },
    verifiedContainer:
    {
        flexDirection: 'row', flex: 0.4, justifyContent: 'space-between'
    },
    imageContainer:{ 
        height: 21.5, width: 16, marginRight: 10 
    },
    preferencesIconContainer:{
        flexDirection:'row',
        justifyContent : 'space-around',
        width : '70%',
        alignSelf:'center',
        paddingVertical:10,
        marginTop : 20,
        marginBottom:20
    },
    preferencesTouchIconContainer:{
        justifyContent:'center',
        alignItems:'center'
    },
    block_sex: {
        borderColor: "purple",
        borderWidth: 0,
        alignItems: "center",
        margin:12,
        width: 35.5,
        height: 35.5,
    },
    imageLable:{
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0,
        marginTop:10
    },
});
