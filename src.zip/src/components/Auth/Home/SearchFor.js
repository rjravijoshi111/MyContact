import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { PassengerLogo, AlertDialog } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
const { height, width } = Dimensions.get("window");

export default class SearchFor extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            image_url: images.passenger
        }
    }

    render() {
        const { title, reday, find_match, search_for, no_match, active_session, without_match } = Lang.passenger;
        return (
            <Container>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.screenProps.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={styles.content}>
                        <View style={{ alignItems: 'center' }}>
                            <View style={{ height: 145, width: 145, borderRadius: 72.5, alignItems: 'center', justifyContent: 'center' }}>
                                <Image source={images.roleCircle} style={{ position: 'absolute', zIndex: 0, height: '100%', width: '100%' }} />
                                <Image source={images.passengerShadowed} style={styles.images} resizeMode={"center"} />
                            </View>
                            <View style={{ width: width - 40, borderRightWidth: 1, borderBottomWidth: 1, borderColor: 'lightgray', paddingVertical: 50, alignItems: 'center', marginTop: -50 }}>
                                <Text style={styles.lable}>{reday}</Text>
                                <Text style={styles.lable}>{find_match}</Text>
                            </View>
                        </View>
                        <View style={{}}>
                            <Button style={styles.searchForButton} onPress={() => this.props.navigation.navigate('RequestList')}>
                                <MaterialIcons name="location-on" style={{ color: "#fff" }} size={30} />
                                <Text>{search_for}</Text>
                            </Button>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        justifyContent: 'space-around',
        // paddingTop: 30,
        backgroundColor: '#fff',
        height: height - 130, alignItems: 'center'
    },
    images: {
        height: 100, width: 91.5,
    },
    lable: {
        fontFamily: 'Roboto', fontSize: 20, marginTop: 20, color: '#000'
    },
    searchForButton: {
        backgroundColor: '#f2c300',
        flexDirection: 'column',
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        height: 60,
        width: 178,
        // marginTop: 60
    }
});