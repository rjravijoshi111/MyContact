import React from 'react';
import {createStackNavigator} from "react-navigation";
import Profile from './Profile';
import UpdateProfile from './UpdateProfile';
import MyReviews from './MyReviews';
import MyCar from './MyCar';
import ProfileSeenByPassenger from './ProfileSeenByPassenger';

export default createStackNavigator(

    {
        Profile:{
            screen:Profile
        },
        UpdateProfile:{
            screen: UpdateProfile
        },
        MyReviews:{
            screen: MyReviews
        },
        MyCar:{
            screen: MyCar
        },
        ProfileSeenByPassenger: {
            screen: ProfileSeenByPassenger
        }
    },
    {
        initialRouteName:'Profile',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }

);