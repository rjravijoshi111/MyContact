/* @flow */

import React, { Component } from 'react';
import Lang from '@src/config/localization';
import Tooltip from 'rn-tooltip';
import {
    View,
    StyleSheet,
    TextInput,
    Dimensions,
    Animated,
    TouchableOpacity,
    Image, Switch,
} from 'react-native';
import images from "@src/config/path/Images";
import {PassengerLogo,AlertDialog} from '@comman';
import {Body, Button, Container, Content, Header, Icon, Left, Title,Text, Right} from "native-base";
import {connect} from "react-redux";
import DatePicker from 'react-native-datepicker';
import {validateUpdateProfile} from '@src/config/Validation';
import {updateProfile,updateProfilePhoto,updatePersonalDoc,updateEmergancyContact} from  "@modules/profile/profile.service";
import ImagePicker from 'react-native-image-picker';
import {Spinner as Spin} from "../../comman";
import RNFetchBlob from "rn-fetch-blob";
import Spinner from 'react-native-loading-spinner-overlay';
import * as AuthAction from "@modules/auth/auth.action";

import {getEmergancyContact,getProfileData} from "@modules/profile/profile.service";
import * as ProfileAction from "../../../modules/profile/profile.action";
import Storage from "@modules/utils/Storage";


class UpdateProfile extends Component {

    constructor(props){
        super(props);
        this.dateChanged = this.dateChanged.bind(this);
        this.selectPhotoTapped = this.selectPhotoTapped.bind(this);
    }

    state = {
        dob: '',
        person_gender:null,
        phone:'',
        email:'',
        company_name:'',
        curp:'',
        rfc:'',
        preferences:[],
        trip_woman:false,
        birthday:'',
        name:'',
        city : '',
        date:null,
        last_name:'',
        birth_day:0,
        birth_month:0,
        birth_year:1900,
        profile_image_url:null,
        avatarSource: images.passenger,
        spinner: false,
        emergencyContact_firstName : '',
        emergencyContact_email : '',
        emergencyContact_phone : '',
        maleScaleAnim : new Animated.Value(1),
        femaleScaleAnim : new Animated.Value(1),
        smokarScaleAnim : new Animated.Value(0.5),
        newsScaleAnim : new Animated.Value(0.5),
        chatScaleAnim : new Animated.Value(0.5),
        musicScaleAnim : new Animated.Value(0.5),
        isTravelWithWomen : false,
        ini_done:false,
        receipt_done:false,
        license_done:false
    };

    componentDidMount() {
        this.props.navigation.dispatch(AuthAction.setLoadingIndicator(true));
        const {name,last_name,birth_day,birth_month,birth_year,city,profile_image_url,phone,person_gender,email,company_name,curp,percent_complete,preferences,rfc,documents} = this.props.user;
        this.setState({ name: name,last_name,phone:phone,email:email,person_gender:person_gender,city,rfc,preferences,
            maleScaleAnim : (person_gender == 1) ? new Animated.Value(1.5) : new Animated.Value(1),
            femaleScaleAnim : (person_gender == 2) ? new Animated.Value(1.5) : new Animated.Value(1),
            company_name:company_name,curp:curp});
        if(birth_day != 0){
            this.setState({birthday: birth_day+"-"+birth_month+"-"+birth_year});
            this.setState({date: birth_day+"-"+birth_month+"-"+birth_year});
            this.setState({birth_day:birth_day,birth_month:birth_month,birth_year:birth_year});
        }
        if(profile_image_url){
            this.setState({avatarSource: {uri: profile_image_url}});
        }
        preferences.map((item) =>{
            if(item == 1){
                this.setState({smokarScaleAnim : new Animated.Value(1)})
            }else if(item == 2){
                this.setState({newsScaleAnim : new Animated.Value(1)})
            }else if(item == 3){
                this.setState({chatScaleAnim : new Animated.Value(1)})
            }else if(item == 5){
                this.setState({isTravelWithWomen : true})
            }else{
                this.setState({musicScaleAnim : new Animated.Value(1)})
            }
        });
        documents.map((item) =>{
            if(item.type == 1 && item.url != ""){
                this.setState({ini_done : true})
            }else if(item.type == 2 && item.url != ""){
                this.setState({receipt_done : true})
            }else if(item.type == 3 && item.url != ""){
                this.setState({license_done : true})
            }
        });
        this.props.navigation.dispatch(getEmergancyContact()).then(()=>{
            const {emergancy_contact} = this.props.user;
            this.setState({emergencyContact_firstName :emergancy_contact.name,emergencyContact_email:emergancy_contact.email,emergencyContact_phone:emergancy_contact.phone});
            this.props.navigation.dispatch(AuthAction.setLoadingIndicator(false));
        });

    }
    selectPhotoTapped(id,type) {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
                skipBackup: true,
            },
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled photo picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            } else {
                let source = { uri: response.uri };

                // You can also display the image using data:
                // let source = { uri: 'data:image/jpeg;base64,' + response.data };

                if(type  == 'profile'){
                    this.setState({
                        spinner: !this.state.spinner
                    });
                    this.props.updateProfilePhoto({data: RNFetchBlob.wrap(response.path), filename: response.fileName , type: response.type, name: 'files'}).then(response=>{
                    // let data = {name: response.fileName,type: response.type,uri:response.uri}
                    // const formData = new FormData();
                    // formData.append('files', data);
                    // this.props.updateProfilePhoto(formData).then(response=>{
                        this.setState({
                            avatarSource: source,
                        });
                        this.setState({
                            spinner: !this.state.spinner
                        });
                    });
                }else{
                    this.props.updatePersonalDoc({data: RNFetchBlob.wrap(response.path), filename: response.fileName , type: response.type, name: 'files',doc_type:id}).then(res=>{
                        if(id == 1){
                            this.setState({ini_done : true})
                        }else if(id == 2){
                            this.setState({receipt_done : true})
                        }else if(id == 3){
                            this.setState({license_done : true})
                        }
                    });
                    // let data = {name: response.fileName,type: response.type,uri:response.uri}
                    // const formData = new FormData();
                    // formData.append('files', data);
                    // formData.append('doc_type', id);
                    // this.props.updatePersonalDoc(formData);
                }
            }
        });
    }
    firstNameChanged = (value) => {
        this.setState({ name: value });
       /* this.setState({ name: value.split(' ')[0] });
        this.setState({ last_name: value.split(' ').splice(1).join(' ') });*/
    };

    lastNameChanged = (value) =>{
        this.setState({ last_name: value });
    }

    ageChanged = (value) => {
        this.setState({ age: value });
    };
    dateChanged = (date) => {
        this.setState({birthday: date});
        this.setState({date: date});
        this.setState({birth_day:date.split('-')[0]});
        this.setState({birth_month:date.split('-')[1]});
        this.setState({birth_year:date.split('-')[2]});
    }
    emailChanged = value => this.setState({ email: value });

    cityChanged = value => this.setState({ city: value });

    phoneChanged = value => this.setState({ phone: value });

    companyChanged = value => this.setState({ company_name: value });

    curpChanged = value => this.setState({ curp: value });

    rfcChanged = value => this.setState({rfc:value});

    emergencyContact_firstName = value => this.setState({emergencyContact_firstName:value});
    
    emergencyContact_email = value => this.setState({emergencyContact_email:value});
    
    emergencyContact_phone = value => this.setState({emergencyContact_phone:value});

    driveWithWoman = value => {
        const { preferences } = this.state;
        let tempPreferences = preferences;
        if(value){
            tempPreferences.push(5);
        }else{
            var index = tempPreferences.indexOf(5);
            if (index > -1) {
                tempPreferences.splice(index, 1);
            }
        }
        this.setState({isTravelWithWomen : value, preferences : tempPreferences})
        
    }

    onGenderChange = (type) => {

        if(type == 2){
            Animated.parallel([
                Animated.timing(this.state.femaleScaleAnim,{
                    toValue : 1.5
                }),
                Animated.timing(this.state.maleScaleAnim,{
                    toValue : 1
                })
            ]).start()
        }else{
            Animated.parallel([
                Animated.timing(this.state.femaleScaleAnim,{
                    toValue : 1
                }),
                Animated.timing(this.state.maleScaleAnim,{
                    toValue : 1.5
                })
            ]).start()
        }
        this.setState({person_gender:type});
    };

    onPreferenceSelect = (id) =>{
        const { preferences } = this.state;
        let tempPreferences = preferences
        if(id == 1){
            if(preferences.indexOf(id) > -1){
                Animated.spring(this.state.smokarScaleAnim,{
                    toValue : .5
                }).start()
            }else{
                Animated.spring(this.state.smokarScaleAnim,{
                    toValue : 1
                }).start()
            }
        }else if(id == 2){

            if(preferences.indexOf(id) >= 0){
                Animated.spring(this.state.newsScaleAnim,{
                    toValue : .5
                }).start()
            }else{
                Animated.spring(this.state.newsScaleAnim,{
                    toValue : 1
                }).start()
            }

        }else if(id == 3){
            if(preferences.indexOf(id) >= 0){
                Animated.spring(this.state.chatScaleAnim,{
                    toValue : .5
                }).start()
            }else{
                Animated.spring(this.state.chatScaleAnim,{
                    toValue : 1
                }).start()
            }
        }else{
            if(preferences.indexOf(id) >= 0){
                Animated.spring(this.state.musicScaleAnim,{
                    toValue : .5
                }).start()
            }else{
                Animated.spring(this.state.musicScaleAnim,{
                    toValue : 1
                }).start()
            }
        }
        let index = tempPreferences.indexOf(id);
        if(index >= 0){
            tempPreferences.splice(index,1);
        }else{
            tempPreferences = [...tempPreferences,id]
        }
        
        this.setState(prevState => ({
            preferences: tempPreferences
        }))
        
    };
    onButtonPress() {
        const {name,last_name, email,birth_day,birth_month,birth_year,phone,company_name,curp,rfc,birthday,preferences,person_gender, emergencyContact_firstName, emergencyContact_email,emergencyContact_phone} = this.state;
        const fields = { email,name,last_name,phone,company_name,curp,rfc,birthday,person_gender};
        const result = validateUpdateProfile(fields,this.awesomAlert);
        const uniqueId = this.props.unique_person;
        if(result){
            let city = {
                "city_id": 1
            }
            
            this.props.updateProfile({name,last_name, birth_day,birth_month,birth_year,phone,company_name,curp,preferences,rfc,city,person_gender}).then((res) =>{
                if(res){
                    this.props.updateEmergancyContact({name : emergencyContact_firstName, email : emergencyContact_email, phone:emergencyContact_phone});
                }

            })
            
        }
        return false;
    }

    renderButton() {
        const {saveBtn} = Lang.updateProfile;
        // if (this.props.loading) {
        //     return <Spin style={styles.button} size="large" />;
        // }

        return (
            <Button style={styles.button} onPress={this.onButtonPress.bind(this)}>
                <Text>{saveBtn}</Text>
            </Button>
        );
    }

    errorMsg(){
        this.awesomAlert.simpleAlert("", rejectedRequest, () => {})
    }

    render() {
        var d = new Date();
        var year = d.getFullYear(); //-18
        const today = new Date(year, 1, 1);
        const {title,name,last_name,curp, age, city, phone, email, company_name, gender,rfc, personalInfo, ine, receipt_address,license, preferences, womanpreference, guigoWoman, fullname_c, phone_c, mail_c, saveSettings, setDate, cancelDate, confirmDate, titleAlert, selectSource, sourceCamera, sourceCarrete, sourceCancel,toolTipImageText,smoker,music,chat,news,womenSwitch,emergencyContact,birthday} = Lang.updateProfile;
        return (
            <Container>
                <AlertDialog 
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{flex:0.2}}>
                        <Button  transparent onPress={() => this.props.navigation.navigate('Profile')}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                    <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content>
                    <Spinner
                        visible={this.state.spinner}
                        textContent={'Loading...'}
                        textStyle={styles.spinnerTextStyle}
                    />
                    <View style={styles.container}>
                        <TouchableOpacity onPress={this.selectPhotoTapped.bind(this,0,'profile')}>
                            <View style={styles.topContainerInner}>
                                <PassengerLogo imageSrc={this.state.avatarSource} />
                            </View>
                        </TouchableOpacity>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={name}
                                   onChangeText={this.firstNameChanged.bind(this)}
                                   value={this.state.name}
                        ></TextInput>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={last_name}
                                   onChangeText={this.lastNameChanged.bind(this)}
                                   value={this.state.last_name}
                        ></TextInput>
                    </View>
                    {/* <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={age}
                                   onChangeText={this.ageChanged.bind(this)}
                                   value={this.state.age}
                        ></TextInput>
                    </View> */}
                    <DatePicker
                        style={styles.inputContainer}
                        date={this.state.date} //initial date from state
                        mode="date" //The enum of date, datetime and time
                        placeholder={birthday}
                        format="DD-MM-YYYY"
                        minDate={new Date("17-01-1970")}
                        maxDate={today}
                        confirmBtnText="Confirm"
                        cancelBtnText="Cancel"
                        showIcon={false}
                        customStyles={{
                            dateInput: [styles.input,{alignItems: 'flex-start',borderWidth:0}],
                            placeholderText:{},
                            // dateText:{textAlign:'left'}
                        }}
                        onDateChange={(date) => this.dateChanged(date)}
                    />
                    <View style={[styles.genderContainer]}>
                        <Text style={[styles.label,{color : '#355c7d'}]}>{gender}</Text>
                    </View>
                    <View style={styles.genderIconContainer}>
                        <TouchableOpacity onPress={this.onGenderChange.bind(this,2)}>
                            <Animated.Image source={images.icoP_woman} style={[styles.roleImage,
                                    {transform : [{scale : this.state.femaleScaleAnim}],marginBottom: 20}
                            ]} />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={this.onGenderChange.bind(this,1)}>
                            <Animated.Image source={images.icoP_men} style={[styles.roleImage,{
                                transform : [{scale : this.state.maleScaleAnim}],marginBottom: 20
                            }]} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={phone}
                                   onChangeText={this.phoneChanged.bind(this)}
                                   value={this.state.phone}
                        ></TextInput>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={email}
                                   onChangeText={this.emailChanged.bind(this)}
                                   value={this.state.email}
                        ></TextInput>
                    </View>
                    {/* <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={city}
                                   onChangeText={this.cityChanged.bind(this)}
                                   value={this.state.city}
                        ></TextInput>
                    </View> */}
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={company_name}
                                   onChangeText={this.companyChanged.bind(this)}
                                   value={this.state.company_name}
                        ></TextInput>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={curp}
                                   onChangeText={this.curpChanged.bind(this)}
                                   value={this.state.curp}
                        ></TextInput>
                    </View>
                    <View style={styles.inputContainer}>
                        <TextInput style={styles.input}
                                   placeholder={rfc}
                                   onChangeText={this.rfcChanged.bind(this)}
                                   value={this.state.rfc}
                        ></TextInput>
                    </View>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}>{personalInfo}</Text>
                    </View>

                    <View style={styles.personalInfoContainer}>
                        <View style={styles.updateImageContainer}>
                            <Text style={[styles.personalInfoLabel,styles.label]}>{ine}</Text>
                            <TouchableOpacity onPress={this.selectPhotoTapped.bind(this,1,'personal')}>
                                <Image source={this.state.ini_done ? images.check_doc : images.uploadPlusIcon} style={styles.updateImage} />
                            </TouchableOpacity>
                            <View style={styles.tooltipContainer}>
                                <Tooltip backgroundColor='#CCCCCC' withOverlay={false} withPointer={false} width={200} containerStyle={{
                                    height: "auto"
                                }} popover={<Text>{toolTipImageText}</Text>}>
                                    <Image source={images.imageUploadToolTipIcon} style={styles.updateImageToolTipIcon} />
                                </Tooltip>
                            </View>


                        </View>
                        <View style={styles.updateImageContainer}>
                            <Text style={[styles.personalInfoLabel,styles.label]}>{receipt_address}</Text>
                            <TouchableOpacity onPress={this.selectPhotoTapped.bind(this,2,'personal')}>
                                <Image source={this.state.receipt_done ? images.check_doc : images.uploadPlusIcon} style={styles.updateImage} />
                            </TouchableOpacity>
                        </View>
                        <View style={styles.updateImageContainer}>
                            <Text style={[styles.personalInfoLabel,styles.label]}>{license}</Text>
                            <TouchableOpacity onPress={this.selectPhotoTapped.bind(this,3,'personal')}>
                                <Image source={this.state.license_done ? images.check_doc : images.uploadPlusIcon} style={styles.updateImage} />
                            </TouchableOpacity>
                        </View>
                    </View>
                        <View style={styles.labelContainer}>
                            <Text style={styles.label}>{preferences}</Text>
                        </View>
                        <View style={styles.preferencesIconContainer}>
                            <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={this.onPreferenceSelect.bind(this,1)}>
                                <Animated.View style={[styles.block_sex,{opacity : this.state.smokarScaleAnim}]}>
                                    <Image source={images.iconSmoker} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                    <Text style={styles.imageLable}>{smoker}</Text>
                                </Animated.View>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={this.onPreferenceSelect.bind(this,2)}>
                                <Animated.View style={[styles.block_sex,{opacity : this.state.newsScaleAnim}]}>
                                    <Animated.Image source={images.iconNews} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                    <Text style={styles.imageLable}>{news}</Text>
                                </Animated.View>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={this.onPreferenceSelect.bind(this,3)}>
                                <Animated.View style={[styles.block_sex,{opacity : this.state.chatScaleAnim}]}>
                                    <Animated.Image source={images.iconChat} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                    <Text style={styles.imageLable}>{chat}</Text>
                                </Animated.View>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.preferencesTouchIconContainer} onPress={this.onPreferenceSelect.bind(this,4)}>
                                <Animated.View style={[styles.block_sex,{opacity : this.state.musicScaleAnim}]}>
                                    <Animated.Image source={images.iconMusic} style={[styles.roleImage,{height : '100%',width:'100%'}]} />
                                    <Text style={styles.imageLable}>{music}</Text>
                                </Animated.View>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.switchContainer}>
                            <View>
                                <Text style={styles.label}>{womenSwitch}</Text>
                            </View>
                            <View style={styles.switchInnerContainer}>
                                <Switch
                                    style={styles.switch}
                                    trackColor={{true : '#D892BF', false : '#CCC'}}
                                    value={this.state.isTravelWithWomen}
                                    onValueChange={this.driveWithWoman}
                                />
                            </View>
                        </View>

                        <View style={styles.labelContainer}>
                            <Text style={styles.label}>{emergencyContact}</Text>
                        </View>
                        <View style={styles.inputContainer}>
                            <TextInput style={styles.input} 
                                        placeholder={name}
                                        onChangeText={this.emergencyContact_firstName.bind(this)}
                                        value={this.state.emergencyContact_firstName} />
                        </View>
                        <View style={styles.inputContainer}>
                            <TextInput  style={styles.input} 
                                        placeholder={email}
                                        autoCapitalize={'none'} 
                                        onChangeText={this.emergencyContact_email.bind(this)}
                                        value={this.state.emergencyContact_email}/>
                        </View>
                        <View style={styles.inputContainer}>
                            <TextInput style={styles.input} 
                                        placeholder={phone} 
                                        onChangeText={this.emergencyContact_phone.bind(this)}
                                        value={this.state.emergencyContact_phone}/>
                        </View>
                        <View style={styles.buttonContainer}>
                            {this.renderButton()}
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}

const mapStateToProps = state => ({
    user:state.profile.user,
    loading:state.auth.loading,
    unique_person:state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({
    updateProfile: (data) => dispatch(updateProfile(data)),
    updateEmergancyContact: (data) => dispatch(updateEmergancyContact(data)),
    updateProfilePhoto : (data) => dispatch(updateProfilePhoto(data)),
    updatePersonalDoc: (data) => dispatch(updatePersonalDoc(data))
});
export default connect(mapStateToProps,mapDispatchToProps)(UpdateProfile);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        width: Dimensions.get("window").width,
        top:10

    },
    spinnerTextStyle: {
        color: '#FFF'
    },
    topContainerInner:{
        marginBottom: 20
    },
    inputContainer:{
        backgroundColor:'#fff',
        width:Dimensions.get('window').width,
        borderBottomWidth: 1,
        borderBottomColor:'#D5D5D7',
    },
    input:{
        paddingLeft: 10,
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0,
        height:38
    },
    label:{
        // color:'#c4ccd5',
        paddingLeft: 10,
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0
    },
    imageLable:{
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0
    },
    labelContainer:{
        width:Dimensions.get('window').width,marginVertical:10
    },
    switchContainer:{
        width:Dimensions.get('window').width,
        marginVertical : 10
    },
    switchInnerContainer:{
        flexDirection:'row',
        justifyContent:'center',
        marginTop:20
    },
    block_sex: {
        borderColor: "purple",
        borderWidth: 0,
        alignItems: "center",
        margin:12,
        width: 46,
        height: 46,
    },
    roleImage: {
        //resizeMode: "contain",
        //width: Dimensions.get("window").width * roleFactor,
        //marginTop: 10,
        width: 50,
        height: 50,
    },
    genderContainer:{
        width: "100%",paddingTop:10
    },
    personalInfoLabel:{
        flexBasis:200,
        color:'#000'
    },
    genderIconContainer:{
        flexDirection: 'row',
        justifyContent: 'space-around',
        width:'60%',
        paddingVertical:10
    },
    updateImageContainer:{
        flexDirection: 'row',
        marginTop: 10,
    },
    updateImageToolTipIcon:{
        width:15,
        height:15,

    },
    personalInfoContainer:{
        width:Dimensions.get('window').width
    },
    updateImage:{
        width:25,
        height:25,
        justifyContent:'flex-start',
        flexDirection:'row'
    },
    tooltipContainer:{
        marginLeft: 30,
        justifyContent:'center'
    },
    preferencesIconContainer:{
        flexDirection:'row',
        justifyContent : 'space-around',
        width : '80%',
        paddingVertical:10
    },
    preferencesTouchIconContainer:{
        justifyContent:'center',
        alignItems:'center'
    },
    switch: {
        transform: [{ scaleX: 1.3 }, { scaleY: 1.3 }],
    },
    buttonContainer:{
        marginTop: 20,
        marginBottom: 20
    }
});
