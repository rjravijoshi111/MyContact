import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button,Text, Body, Content,View,Card,Picker} from "native-base";
import ProgressBarAnimated from 'react-native-progress-bar-animated';

import Lang from '@src/config/localization';
import {PassengerLogo,AlertDialog} from '@comman';
import {Dimensions, StyleSheet,Image,TouchableOpacity,Modal,FlatList} from "react-native";
import ImagePicker from 'react-native-image-picker';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import {connect} from "react-redux";

const { height, width } = Dimensions.get("window");

 class MyCar extends Component {

    constructor(props){
        super(props);

        this.state = {
            myCarList :[
                {data : ['Tipo','Tipo1','Tipo2'],selectedValue : '',title:"Tipo"},
                {data : ['Marca','Marca1','Marca2'],selectedValue : '',title:"Marca"},
                {data : ['Modelo','Modelo1','Modelo2'],selectedValue : '',title:"Modelo"},
                {data : ['Color de tu coche','Color de tu coche1','Color de tu coche2'],selectedValue : '',title:"Color de tu coche"},
                {data : ['Holograma','Holograma1','Holograma2'],selectedValue : '',title:"Holograma"},
                {data : ['Engomado','Engomado1','Engomado2'],selectedValue : '',title:"Engomado"},
                {data : ['Placas','Placas1','Placas2'],selectedValue : '',title:"Placas"},
                {data : ['Asientos disponibles','Asientos disponibles1','Asientos disponibles2'],selectedValue : '',title:"Asientos disponibles"},
            ],
            modalVisible: true
        }
    }

    _renderItem = (item)=>{
        let data = item.item;
        return(
            <View style={{height:40,backgroundColor:'#fff',borderBottomWidth:1,borderBottomColor:'lightgray'}}>
                <Picker
                    mode={"dropdown"}
                    selectedValue={data.selectedSize}
                    iosIcon={<Icon name="arrow-down" />}
                    placeholder={data.title}
                    placeholderStyle={{ color: "#000" }}
                    style={{ width: width}}
                    textStyle={styles.label}
                    onValueChange={(itemValue, itemPosition) => console.log(itemValue)}
                    >
                    {/* <Picker.Item label={"Select Size"} value={"-1"} /> */}
                    { data.data.map((item, key)=>{
                        return (<Picker.Item label={item} value={item} key={key} style={{fontSize:12}} />)
                    })}
                </Picker>
            </View>
        )
    }

    _ListEmptyComponent = () =>{
        const { noReveiw} = Lang.myCar;
        return(
            <View style={styles.emptyListStyle}>
                <Image source={images.thumbsup_sin_background} style={{width:150,height:150}} resizeMode={"cover"} />
                <Text style={styles.noReviewText}>{noReveiw}</Text>
            </View>
        )
    }

    selectPhotoTapped(id,type) {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
                skipBackup: true,
            },
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled photo picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            } else {
                let source = { uri: response.uri };

                // You can also display the image using data:
                // let source = { uri: 'data:image/jpeg;base64,' + response.data };
            }
        });
    }

    renderAlert(){
        return(
            <Modal visible={this.state.modalVisible} transparent={true}>
                <View style={{flex:1,backgroundColor:'rgba(0,0,0,.3)',alignItems:'center',justifyContent:'center'}}>
                    <View style={{width: width - 100 ,backgroundColor:'#fff',paddingVertical:20,borderRadius:3}}>
                        <View style={{paddingVertical:20,marginHorizontal:30,borderBottomWidth:1,borderBottomColor:'#434546',alignItems:'center'}}>
                            <Text style={{textAlign:'center',fontSize:15}}>{"Verifica que tu RFC esté bien escrito."}</Text>
                        </View>
                        <View style={{alignItems:'center',marginTop:20}}>
                            <Text>{"OK"}</Text>
                        </View>
                    </View>
                </View>
            </Modal>
        )
    }

    onPressSimpleAlert() {
        this.awesomAlert.simpleAlert("", "Verifica que tu RFC esté bien escrito.", () => console.log("OK touch"))
      }

    render(){
        const { title,addPhotos,cancel } = Lang.myCar;
        return(
            <Container>
                <AlertDialog 
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{flex:0.2}}>
                        <Text style={styles.headerbuttonText} onPress={() => this.props.navigation.goBack()}>{cancel}</Text>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} >
                        <Text style={styles.headerbuttonText}>{"OK"}</Text>
                    </Right>
                </Header>
                {/* <Content> */}
                    <View>
                        <FlatList
                            bounces={false}
                            style={{backgroundColor:'transparent',paddingTop:20}}
                            data={this.state.myCarList}
                            renderItem={this._renderItem}
                            ListEmptyComponent={this._ListEmptyComponent}
                            keyExtractor={(item,index) => index.toString()}
                        />
                        <View style={{paddingTop:20,paddingHorizontal:10}}>
                            <Text style={styles.label}>{addPhotos}</Text>
                            <TouchableOpacity onPress={() => this.onPressSimpleAlert()}>
                                <Image source={images.plus_coche} style={{height:100,width:100,alignSelf:'center',marginTop:20}} resizeMode={"contain"}/>
                            </TouchableOpacity>
                        </View>
                    </View>
                    
                {/* </Content> */}
            </Container>
        )
    }
}

const mapStateToProps = state => ({
    user:state.profile.user,
    loading:state.auth.loading,
    unique_person:state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({

});
export default connect(mapStateToProps)(MyCar);

const styles = StyleSheet.create({
    emptyListStyle :{
        height : height - 150,
        width,
        alignItems:'center',
        justifyContent:'center'
    },
    noReviewText:{
        // fontFamily:'Roboto-Light',
        fontSize:15,
        color : '#000',
        marginTop:20
    },
    label :{
        fontSize:12
    },
    ratingView:{
        alignItems:'center',justifyContent:'center',width: width / 1.8,paddingVertical:30,alignSelf:'center',marginTop:20,marginBottom:30
    },
    watermarkImage:{
        width:200,height:200,position:'absolute',zIndex:0,alignSelf:'center',marginTop:50
    },
    headerbuttonText:{
        fontSize: 12.5,
        color: '#355c7d'
    }
});