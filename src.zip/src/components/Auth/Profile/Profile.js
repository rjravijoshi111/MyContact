import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button,Text, Body, Content,View,ListItem,List} from "native-base";
import ProgressBarAnimated from 'react-native-progress-bar-animated';

import Lang from '@src/config/localization';
import {PassengerLogo} from '@comman';
import {Dimensions, StyleSheet,Image,TouchableOpacity,Alert} from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import {getProfileData,getEmergancyContact} from "@modules/profile/profile.service";
import {connect} from "react-redux";
import Storage from "@modules/utils/Storage";
import * as ProfileAction from "@modules/profile/profile.action";
import {NavigationActions} from "react-navigation";
import * as AuthAction from "@modules/auth/auth.action";


class Profile extends Component {

    constructor(props){
        super(props);
    }

    state = {
        progress: 45,
        progressWithOnComplete: 0,
        progressCustomized: 0,
        image_url : images.passenger
    }
    increase = (key, value) => {
        this.setState({
            [key]: this.state[key] + value,
        });
    }
    handleClick(key){
        this.props.navigation.navigate(key)
        // Call method from parent
        //this.props.onPress();
    }
    
    componentDidMount() {
        this.props.navigation.dispatch(AuthAction.setLoadingIndicator(true));
        this.props.navigation.dispatch(getProfileData()).then( () =>{
            const {profile_image_url,percent_complete} = this.props.user;
            this.setState({ progress: percent_complete});
            if(profile_image_url){
                this.setState({image_url: {uri: profile_image_url}});
            }
            this.props.navigation.dispatch(AuthAction.setLoadingIndicator(false));
        });
    }
    
    render() {
        const { title,profile_Not_Completed,profileCompleted,editProfileBtn,weightco2,savedMoney,guigoTravels,myreviews,myCar } = Lang.profileText
        const barWidth = Dimensions.get('screen').width - 170;
        const progressCustomStyles = {
            backgroundColor: 'red',
            borderRadius: 0,
            borderColor: 'orange',
        };
        
        return (
            <Container>
                <Header>
                    <Left style={{flex:0.2}}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }}  />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content style={styles.container}>
                    <View style={styles.topContainer}>
                            <View style={styles.topContainerInner}>
                                <PassengerLogo imageSrc={this.state.image_url} />
                            </View>
                        <View style={styles.topContainerInner}>
                            <ProgressBarAnimated
                                width={barWidth}
                                value={this.state.progress}
                                borderColor={"#EDBF3F"}
                                backgroundColor={"#EDBF3F"}
                                backgroundColorOnComplete="#EDBF3F"
                            />
                        </View>
                        <View style={styles.topContainerInner}>
                            <Text style={styles.label}>{profile_Not_Completed}</Text>
                        </View>
                        <View style={styles.topContainerInner}>
                            <Button style={styles.editButton} onPress={() => this.props.navigation.navigate('UpdateProfile')}>
                                <Text>{editProfileBtn}</Text>
                            </Button>
                        </View>
                    </View>
                    <View style={styles.middleContainer}>
                        <TouchableOpacity style={styles.iconContainer}>
                            <Image source={images.monedas} style={[styles.iconSave,styles.icon]} resizeMode={"contain"} />
                            <Text style={styles.iconText}>{savedMoney}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.iconContainer}>
                            <Image source={images.guigo_coche_blanco} style={[styles.iconGuigo,styles.icon]} resizeMode={"contain"} />
                            <Text style={styles.iconText}>{guigoTravels}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.iconContainer}>
                            <Image source={images.nube_Co2} style={[styles.iconWeight,styles.icon]} resizeMode={"contain"} />
                            <Text style={styles.iconText}>{weightco2}</Text>
                        </TouchableOpacity>
                    </View>
                    <View >
                        <List style={styles.bottomContainer}>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <Left>
                                    <Button transparent>
                                        <Image source={images.handFacebook} style={[styles.listItemLeftIcon]} />
                                    </Button>
                                </Left>
                                <Body>
                                <Text>{myreviews}</Text>
                                </Body>
                                <Right>
                                    <Icon name="arrow-forward" />
                                </Right>
                            </ListItem>
                            {this.props.user_role == 2 && <ListItem icon noBorder  button={true} style={styles.listItem} onPress={ this.handleClick.bind(this,"MyCar")}>
                                <Left>
                                    <Button transparent>
                                        <Image source={images.coche_menu} style={[styles.listItemLeftIcon]} />
                                    </Button>
                                </Left>
                                <Body>
                                <Text>{myCar}</Text>
                                </Body>
                                <Right>
                                    <Icon name="arrow-forward" />
                                </Right>
                            </ListItem>}
                        </List>
                    </View>
                </Content>
            </Container>
        );
    }
}

const mapStateToProps = state => ({
    user:state.profile.user,
    loading:state.auth.loading,
    unique_person:state.auth.unique_person,
    user_role:state.role.user_role
});

const mapDispatchToProps = dispatch => ({
    getProfileData: (uniqueId) => dispatch(getProfileData(uniqueId))
});
export default connect(mapStateToProps,mapDispatchToProps)(Profile);
const styles = StyleSheet.create({
    container:{
        // top:20
    },
    topContainer:{
        // justifyContent: 'center',
        alignItems: 'center',
        marginTop:20
    },
    topContainerInner:{
        paddingBottom: 10,

    },
    middleContainer:{
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 50
    },
    icon:{
        height: 42.5,
        width: 60,
    },
    iconSave:{
        width:39.5,
        height: 42.5
    },
    iconGuigo:{
        width: 45,
        height: 32
    },
    iconWeight:{
        width: 60,
        height: 24
    },
    iconContainer:{
        justifyContent:'center',
        alignItems: 'center'
    },
    iconText:{
        width: 84,
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0,
        textAlign: "center",
        color: "#000",
        marginVertical:10
    },
    listItem:{
        marginLeft:0,
        marginBottom: 10,
        paddingHorizontal:10,
        backgroundColor: '#fff'
    },
    listItemLeftIcon:{
        width: 25,
        height: 25,
        resizeMode :'cover'
    },
    bottomContainer:{
        marginTop:50,
    },
    label:{
        fontSize: 15
    },
    editButton:{
        borderRadius:0
    }
});