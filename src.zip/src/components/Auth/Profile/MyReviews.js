import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button,Text, Body, Content,View,Card,List} from "native-base";
import ProgressBarAnimated from 'react-native-progress-bar-animated';

import Lang from '@src/config/localization';
import {PassengerLogo} from '@comman';
import {Dimensions, StyleSheet,Image,TouchableOpacity,Alert,FlatList} from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import {connect} from "react-redux";

const { height, width } = Dimensions.get("window");

 class MyReviews extends Component {

    constructor(props){
        super(props);

        this.state = {
            myReviewsList :[1,2,3],
        }
    }

    _renderItem = (item)=>{
        return(
            <View style={{paddingHorizontal:10,backgroundColor:'#fff',paddingBottom:10,borderBottomWidth:1,opacity:0.7}}>
                <View style={{flexDirection:'row',marginVertical:10}}>
                    <View>
                        <Image source={images.icoP_men} style={{height:50,width:50}} />
                    </View>
                    <View style={{flex:1,justifyContent:'center',paddingHorizontal:10}}>
                        <Text style={styles.label}>{"Jade"}</Text>
                        <StarRating
                            disabled={true}
                            maxStars={5}
                            rating={3}
                            starSize={20}
                            emptyStarColor={"#EDBF3F"}
                            fullStarColor={"#EDBF3F"}
                            // selectedStar={(rating) => this.onStarRatingPress(rating)}
                        />
                    </View>
                    <View style={{flex:0.5,alignItems:'flex-start'}}>
                        
                    </View>
                </View>
                <Text style={styles.label}>{"Viajé con Andres varias veces. El siempre es puntual y responsable. ¡Muy recomendado!"}</Text>
            </View>
        )
    }

    _ListEmptyComponent = () =>{
        const { noReveiw} = Lang.myReviews;
        return(
            <View style={styles.emptyListStyle}>
                <Image source={images.thumbsup_sin_background} style={{width:150,height:150}} resizeMode={"cover"} />
                <Text style={styles.noReviewText}>{noReveiw}</Text>
            </View>
        )
    }

    render(){
        const { title } = Lang.myReviews;
        return(
            <Container>
                <Header>
                    <Left style={{flex:0.2}}>
                        <Button  transparent onPress={() => this.props.navigation.navigate('Profile')}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                {/* <Content> */}
                    {this.state.myReviewsList.length > 0 && <Card style={styles.ratingView}>
                        <Text style={styles.label}>{"Andres Galvez"}</Text>
                        <Text style={styles.label}>{"4.1"}</Text>
                        <StarRating
                            disabled={true}
                            maxStars={5}
                            rating={3}
                            starSize={25}
                            emptyStarColor={"#EDBF3F"}
                            fullStarColor={"#EDBF3F"}
                            // selectedStar={(rating) => this.onStarRatingPress(rating)}
                        />
                    </Card>}
                    <View>
                        <Image source={images.thumbsup_sin_background} style={styles.watermarkImage} resizeMode={"cover"} />
                        <FlatList
                            style={{backgroundColor:'transparent'}}
                            data={this.state.myReviewsList}
                            renderItem={this._renderItem}
                            ListEmptyComponent={this._ListEmptyComponent}
                            keyExtractor={(item,index) => index.toString()}
                        />
                    </View>
                    
                {/* </Content> */}
            </Container>
        )
    }
}

const mapStateToProps = state => ({
    user:state.profile.user,
    loading:state.auth.loading,
    unique_person:state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({

});
export default connect(mapStateToProps)(MyReviews);

const styles = StyleSheet.create({
    emptyListStyle :{
        height : height - 150,
        width,
        alignItems:'center',
        justifyContent:'center'
    },
    noReviewText:{
        // fontFamily:'Roboto-Light',
        fontSize:15,
        color : '#000',
        marginTop:20
    },
    label :{
        fontSize:12
    },
    ratingView:{
        alignItems:'center',justifyContent:'center',width: width / 1.8,paddingVertical:30,alignSelf:'center',marginTop:20,marginBottom:30
    },
    watermarkImage:{
        width:200,height:200,position:'absolute',zIndex:0,alignSelf:'center',marginTop:50
    }
});