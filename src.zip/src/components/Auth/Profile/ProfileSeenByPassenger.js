
import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button,Text, Body, Content,View,ListItem,List} from "native-base";
import ProgressBarAnimated from 'react-native-progress-bar-animated';

import Lang from '@src/config/localization';
import {PassengerLogo} from '@comman';
import {Dimensions, StyleSheet,Image,TouchableOpacity,Modal} from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import {connect} from "react-redux";

 class ProfileSeenByPassenger extends Component {
    state = {
        progress: 45,
        progressWithOnComplete: 0,
        progressCustomized: 0,
        image_url : images.passenger,
        modalVisible : true
    }
    increase = (key, value) => {
        this.setState({
            [key]: this.state[key] + value,
        });
    }
    handleClick(key){
        this.props.navigation.navigate(key)
        // Call method from parent
        //this.props.onPress();
    }
    componentDidMount() {
        const {profile_image_url,percent_complete} = this.props.user;

        this.setState({ progress: percent_complete});
        if(profile_image_url){
            this.setState({image_url: {uri: profile_image_url}});
        }
    }

    onOptionsSelect(key){
        alert(key)
    }

    render() {
        const barWidth = Dimensions.get('screen').width - 170;
        const progressCustomStyles = {
            backgroundColor: 'red',
            borderRadius: 0,
            borderColor: 'orange',
        };
        
        const { title,profession,phone,mail,identification,driverLincense,verified,chat,news,music,lastConnection,responseRate } = Lang.profileSeenByPassenger;
        
        return (
            <Container>
                <Header>
                    <Left style={{flex:0.2}}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }}  />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{flex:0.2}} />
                </Header>
                <Content style={styles.container}>
                    <View style={styles.topContainer}>
                        <View style={styles.topContainerInner}>
                            <PassengerLogo imageSrc={this.state.image_url} />
                        </View>
                        <View style={{alignItems:'center'}}>
                            <Text style={styles.label}>{"Andres Galvez"}</Text>
                            <Text style={styles.label}>{"28 años"}</Text>
                        </View>
                        <View style={styles.topContainerInner}>
                            <StarRating
                                disabled={true}
                                maxStars={5}
                                rating={3}
                                starSize={20}
                                emptyStarColor={"#EDBF3F"}
                                fullStarColor={"#EDBF3F"}
                                // selectedStar={(rating) => this.onStarRatingPress(rating)}
                            />
                        </View>
                    </View>
                    <View>
                        <List style={styles.bottomContainer}>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <View>
                                    <Text style={styles.label}>{profession}</Text>
                                </View>
                                <View>
                                    <View style={styles.listRightInnerView}>
                                        <Text style={[styles.label,styles.verifiedText]}>{"CEO"}</Text>
                                    </View>
                                </View>
                            </ListItem>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <View>
                                    <Text style={styles.label}>{phone}</Text>
                                </View>
                                <View>
                                    <View style={styles.listRightInnerView}>
                                        <Text style={[styles.label,styles.verifiedText]}>{verified}</Text>
                                        <Image source={images.varified} style={styles.verifiedImage} resizeMode={"contain"} />
                                    </View>
                                </View>
                            </ListItem>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <View>
                                    <Text style={styles.label}>{mail}</Text>
                                </View>
                                <View style={styles.listRightInnerView}>
                                    <Text style={[styles.label,styles.verifiedText]}>{verified}</Text>
                                    <Image source={images.varified} style={styles.verifiedImage} resizeMode={"contain"} />
                                </View>
                            </ListItem>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <View>
                                    <Text style={styles.label}>{identification}</Text>
                                </View>
                                <View style={styles.listRightInnerView}>
                                    <Text style={[styles.label,styles.verifiedText]}>{verified}</Text>
                                    <Image source={images.varified} style={styles.verifiedImage} resizeMode={"contain"} />
                                </View>
                            </ListItem>
                            <ListItem icon noBorder button={true} onPress={ this.handleClick.bind(this,"MyReviews")} style={styles.listItem}>
                                <View>
                                    <Text style={styles.label}>{driverLincense}</Text>
                                </View>
                                <View style={styles.listRightInnerView}>
                                    <Text style={[styles.label,styles.verifiedText]}>{verified}</Text>
                                    <Image source={images.varified} style={styles.verifiedImage} resizeMode={"contain"} />
                                </View>
                            </ListItem>
                        </List>
                    </View>
                    <View >
                        <View style={styles.optionsIconContainer}>
                            <TouchableOpacity style={styles.optionsTouchIconContainer} onPress={this.onOptionsSelect.bind(this,"Chat")}>
                                <View style={[styles.block_sex]}>
                                    <Image source={images.iconChat} style={styles.roleImage} />
                                    <Text style={styles.imageLable}>{chat}</Text>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.optionsTouchIconContainer} onPress={this.onOptionsSelect.bind(this,"News")}>
                                <View style={[styles.block_sex]}>
                                    <Image source={images.iconNews} style={styles.roleImage} />
                                    <Text style={styles.imageLable}>{news}</Text>
                                </View>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.optionsTouchIconContainer} onPress={this.onOptionsSelect.bind(this,"Music")}>
                                <View style={[styles.block_sex]}>
                                    <Image source={images.iconMusic} style={styles.roleImage} />
                                    <Text style={styles.imageLable}>{music}</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.bottomTextView}>
                            <Text style={styles.label}>{lastConnection}</Text>
                            <Text style={styles.label}>{responseRate}</Text>
                        </View>
                    </View>

                </Content>

            </Container>
        );
    }
}

const mapStateToProps = state => ({
    user:state.profile.user,
    loading:state.auth.loading,
    unique_person:state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({

});
export default connect(mapStateToProps,mapDispatchToProps)(ProfileSeenByPassenger);
const styles = StyleSheet.create({
    container:{
        top:20
    },
    topContainer:{
        // justifyContent: 'center',
        alignItems: 'center',
    },
    topContainerInner:{
        paddingBottom: 10,
        alignItems:'center'
    },
    middleContainer:{
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginTop: 50
    },
    icon:{
        height: 42.5,
        width: 60,
    },
    iconSave:{
        width:39.5,
        height: 42.5
    },
    iconGuigo:{
        width: 45,
        height: 32
    },
    iconWeight:{
        width: 60,
        height: 24
    },
    iconContainer:{
        justifyContent:'center',
        alignItems: 'center'
    },
    iconText:{
        width: 84,
        fontSize: 12,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0,
        textAlign: "center",
        color: "#000",
        marginVertical:10
    },
    listItem:{
        marginLeft:0,
        marginBottom: 5,
        // paddingVertical:5,
        justifyContent:'space-between',
        paddingHorizontal:10,
        backgroundColor: '#fff',
        height:30
    },
    listItemLeftIcon:{
        width: 25,
        height: 25,
        resizeMode :'cover'
    },
    bottomContainer:{
        marginTop:15,
    },
    label:{
        fontSize: 12
    },
    editButton:{
        borderRadius:0
    },
    verifiedText:{
        color: "#355c7d",
    },
    verifiedImage:{
        height:20,width:25
    },
    listRightInnerView:{
        width:100,
        flexDirection:'row',
        justifyContent:'space-between'
    },
    optionsIconContainer:{
        flexDirection:'row',
        justifyContent : 'space-around',
        width : '60%',
        alignSelf:'center',
        paddingVertical:10
    },
    optionsTouchIconContainer:{
        justifyContent:'center',
        alignItems:'center'
    },
    block_sex: {
        borderColor: "purple",
        borderWidth: 0,
        alignItems: "center",
        margin:12,
        width: 35,
        height: 35,
    },
    roleImage: {
        width: '100%',
        height: '100%'
    },
    imageLable:{
        fontSize: 9,
        fontWeight: "300",
        fontStyle: "normal",
        letterSpacing: 0,
        marginTop:10
    },
    bottomTextView:{
        marginVertical:10,marginHorizontal:10
    }
});