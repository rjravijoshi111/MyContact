import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class CardDetails extends React.Component {

    render() {
        const { title, details, add } = Lang.cardDetails;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("Settings")}>
                            <Icon name="arrow-back" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ top: 30 }}>
                        <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 40 }}>
                            <Image source={images.image_credit_card_con_sombra} style={{ width: 152, height: 94.5, resizeMode: 'cover' }} />
                            <View style={{ margin: 50 }}>
                                <Text style={{ textAlign: 'center', fontSize: 15 }}>
                                    {details}
                                </Text>
                            </View>
                            <Button
                                onPress={() => this.props.navigation.navigate("CurrentCardDetails")}
                                style={styles.addButton}>
                                <Text>{add}</Text>
                            </Button>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    addButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 30,
        marginBottom: 25
    },
});