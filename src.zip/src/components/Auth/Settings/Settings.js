import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem, } from "native-base";
import Lang from '@src/config/localization';
import { NavigationActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { connect } from 'react-redux';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import { updateProfile } from "@modules/profile/profile.service";
import AsyncStorage from '@react-native-community/async-storage';

const { height, width } = Dimensions.get("window");
class Settings extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            notification: props.user && props.user.preferences && props.user.preferences.filter(x => x == 6).legth != 0 || false,
            post: props.user && props.user.preferences && props.user.preferences.filter(x => x == 7).legth != 0 || false,
            newsletter: props.user && props.user.preferences && props.user.preferences.filter(x => x == 2).legth != 0 || false,
        }
    }

    componentDidMount() {
        const { user } = this.props;

    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }

    changeSetting() {

        // let preferences = this.props.user;

        // this.props.updateProfile({name,last_name, birth_day,birth_month,birth_year,phone,company_name,curp,preferences,rfc,city,person_gender}).then((res) =>{

        // });
    }

    taponYes = () => {

        AsyncStorage.removeItem("authToken", () => {
            this.awesomAlert.setModalVisible(false)
            this.props.logout()
        })
    }

    render() {
        const { title, signOut, signOutMessage, and, notifications, post, newsletter, changePassword, bankAccount } = Lang.settings;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                >
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 30 }}>
                        <Image source={images.icono_cerrar_sesion} style={{ height: 49.5, width: 49 }} resizeMode={"contain"} />
                        <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {signOut}</Text>
                        <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> {signOutMessage}</Text>
                        <Button style={styles.okButton} onPress={this.taponYes}>
                            <Text style={{ alignItems: 'center' }}>{and}</Text>
                        </Button>
                        <Text style={{ fontSize: 12.5, color: '#355c7d', textAlign: 'center' }} onPress={() => this.awesomAlert.setModalVisible(false)}> No</Text>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>

                    <TouchableOpacity onPress={() => this.props.navigation.navigate(data.navigate)} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.notification_bell} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {notifications}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <TouchableOpacity onPress={() => this.setState({ notification: !this.state.notification })}>
                                <Image source={this.state.notification ? images.baseline_toggle_on : images.baseline_toggle_off} style={styles.toggleButton} />
                            </TouchableOpacity>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this.props.navigation.navigate(data.navigate)} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.icono_perfil_correo} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {post}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <TouchableOpacity onPress={() => this.setState({ post: !this.state.post })}>
                                <Image source={this.state.post ? images.baseline_toggle_on : images.baseline_toggle_off} style={styles.toggleButton} />
                            </TouchableOpacity>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this.props.navigation.navigate(data.navigate)} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.icono_newsletter} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {newsletter}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <TouchableOpacity onPress={() => this.setState({ newsletter: !this.state.newsletter })}>
                                <Image source={this.state.newsletter ? images.baseline_toggle_on : images.baseline_toggle_off} style={styles.toggleButton} />
                            </TouchableOpacity>
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity onPress={() => this.props.navigation.navigate('BankAccount')} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.icono_payment} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {bankAccount}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <Image source={images.baseline_keyboard_arrow_right} style={styles.arrowButton} />
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this.props.navigation.navigate('ChangePassword')} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.icono_cambiar_contrasena} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {changePassword}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <Image source={images.baseline_keyboard_arrow_right} style={styles.arrowButton} />
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this.onPressItem()} style={styles.row}>
                        <View style={{ marginHorizontal: 10 }}>
                            <Image source={images.icono_cerrar_sesion} style={styles.letfImages} />
                        </View>
                        <View style={styles.middleView}>
                            <Text style={styles.titleText}>
                                {signOut}
                            </Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <Image source={images.baseline_keyboard_arrow_right} style={styles.arrowButton} />
                        </View>
                    </TouchableOpacity>
                </Content>
            </Container>
        );
    }
}
const mapStateToProps = state => ({
    user: state.profile.user,
});
const mapDispatchToProps = dispatch => ({
    logout: () => dispatch(NavigationActions.navigate({ routeName: 'Auth' })),
    updateProfile: (data) => dispatch(updateProfile(data)),
    // logout: () => dispatch(NavigationActions.navigate({ routeName: 'Auth' })),
});
export default connect(mapStateToProps, mapDispatchToProps)(Settings);
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    qualifyButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 30
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogTextTitle:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginTop: 10
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row' },
    alertDialogText:
    {
        fontSize: 12, color: '#434546', fontFamily: 'Roboto', marginVertical: 10
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 25,
        marginBottom: 25
    },
    row: {
        height: 86.5, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: 'lightgray', flexDirection: 'row', alignItems: 'center'
    },
    letfImages: {
        width: 34.5, height: 34, resizeMode: 'contain'
    },
    middleView: {
        flex: 1, justifyContent: 'center'
    },
    titleText: {
        alignItems: 'center', justifyContent: 'center', color: '#000', fontSize: 15
    },
    toggleButton: {
        width: 40, height: 20, marginHorizontal: 10, resizeMode: 'cover'
    },
    arrowButton: {
        width: 10, height: 15, marginHorizontal: 10, resizeMode: 'cover'
    }
});