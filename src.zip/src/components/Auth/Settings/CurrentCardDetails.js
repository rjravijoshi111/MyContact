import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class CurrentCardDetails extends React.Component {

    onPress = () => {
        const { yourCardDeleted } = Lang.cardDetails;
        this.awesomAlert.simpleAlert("", yourCardDeleted, () => this.props.navigation.navigate("EnterCardDetails"))
    }

    render() {
        const { title, subTitle, addNewCard, add, deleteCard } = Lang.cardDetails;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("Settings")}>
                            <Icon name="arrow-back" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ top: 30 }}>
                        <Text style={{ marginLeft: 10, fontSize: 15 }}>
                            {subTitle}
                        </Text>
                        <View style={{ alignItems: 'center', marginTop: 40 }}>
                            <Image source={images.image_credit_card_con_sombra} style={{ width: 152, height: 94.5, resizeMode: 'cover' }} />
                            <View style={styles.textView}>
                                <Text style={{ fontSize: 12 }}>
                                    Master Card
                                </Text>
                            </View>
                            <View style={styles.textView}>
                                <Text style={{ fontSize: 12 }}>
                                    5555 XXXX XXXX XXX
                                </Text>
                            </View>
                            <View style={{ margin: 10 }}>
                                <Image source={images.baseline_toggle_off} style={{ width: 40, height: 20, marginHorizontal: 10, resizeMode: 'cover' }} />
                            </View>
                            <TouchableOpacity
                                onPress={this.onPress}
                                style={{ alignItems: 'center', justifyContent: 'center' }}>
                                <Text style={{ fontSize: 9, color: "#355c7d" }}>
                                    {deleteCard}
                                </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{ marginTop: 100 }}>
                            <Text style={{ marginLeft: 10, fontSize: 15 }}>
                                {addNewCard}
                            </Text>
                            <Button
                                onPress={() => this.props.navigation.navigate("CurrentCardDetails")}
                                style={styles.addButton}>
                                <Text>{add}</Text>
                            </Button>
                        </View>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    textView: { backgroundColor: '#fff', height: 24, width: "100%", alignItems: 'center', justifyContent: 'center', marginTop: 30 },
    qualifyButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 30
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogTextTitle:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginTop: 10
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row' },
    alertDialogText:
    {
        fontSize: 12, color: '#434546', fontFamily: 'Roboto', marginVertical: 10
    },
    addButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 30,
        marginBottom: 25
    },
});