import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class BankAccount extends React.Component {

    onPress = () => {
        const { bankAccountEliminated } = Lang.bankAccount;
        this.awesomAlert.simpleAlert("", bankAccountEliminated, () => this.props.navigation.navigate("BankAccountDetails"))
    }

    render() {
        const { title, currentBankAccount, deleteBankAccount } = Lang.bankAccount;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("Settings")}>
                            <Icon name="arrow-back" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <Text style={{ marginTop: 30, marginLeft: 10, fontSize: 15 }}>
                        {currentBankAccount}
                    </Text>
                    <View style={{ alignItems: 'center', marginTop: 40 }}>
                        <Image source={images.image_cuenta_con_sombra} style={{ width: 105, height: 113, resizeMode: 'cover' }} />
                        <View style={styles.textView}>
                            <Text style={{ fontSize: 12 }}>
                                Banorte
                                </Text>
                        </View>
                        <View style={styles.textView}>
                            <Text style={{ fontSize: 12 }}>
                                5555 XXXX XXXX XXX
                                </Text>
                        </View>
                        <TouchableOpacity
                            onPress={this.onPress}
                            style={styles.deleteBankAccountButton}>
                            <Text style={{ fontSize: 9, color: "#355c7d" }}>
                                {deleteBankAccount}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    qualifyButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 30
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogTextTitle:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginTop: 10
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row' },
    alertDialogText:
    {
        fontSize: 12, color: '#434546', fontFamily: 'Roboto', marginVertical: 10
    },
    textView: {
        backgroundColor: '#fff', height: 24, width: "100%", alignItems: 'center', justifyContent: 'center', marginTop: 20
    },
    deleteBankAccountButton:
        { alignItems: 'center', justifyContent: 'center', marginTop: 30 }

});