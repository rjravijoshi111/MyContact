import React from 'react';
import { createStackNavigator } from "react-navigation";

import Settings from './Settings';
import BankAccount from './BankAccount';
import BankAccountDetails from './BankAccountDetails';
import ChangePassword from './ChangePassword';
import CardDetails from './CardDetails';
import CurrentCardDetails from './CurrentCardDetails';
import EnterCardDetails from './EnterCardDetails';

export default createStackNavigator(
    {
        Settings: {
            screen: Settings
        },
        BankAccount: {
            screen: BankAccount
        },
        BankAccountDetails: {
            screen: BankAccountDetails
        },
        ChangePassword: {
            screen: ChangePassword
        },
        CardDetails: {
            screen: CardDetails
        },
        CurrentCardDetails: {
            screen: CurrentCardDetails
        },
        EnterCardDetails: {
            screen: EnterCardDetails
        }
    },
    {
        initialRouteName: 'Settings',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);