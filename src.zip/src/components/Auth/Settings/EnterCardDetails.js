import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class EnterCardDetails extends React.Component {

    onPress = () => {
        const { alertDeleteCard, add } = Lang.enterCardDetails;
        let SimpleView = (<View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
            <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {alertDeleteCard}</Text>
            <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                <Text style={{ alignItems: 'center' }}>{add}</Text>
            </Button>
            <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> No</Text>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }

    onPressItem = () => {
        const { somthingWentWrong, dataIsNotValid } = Lang.enterCardDetails;
        let SimpleView = (<View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
            <Image source={images.image_credit_card_con_sombra} style={{ height: 46, width: 75.5 }} resizeMode={"contain"} />
            <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {somthingWentWrong}</Text>
            <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> {dataIsNotValid}</Text>
            <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                <Text style={{ alignItems: 'center' }}>OK</Text>
            </Button>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }

    render() {
        const { cancel, title, subTitle, name, surName, cardNumber, expireDate, securityCode, addressLinkedToYourCard, address1, address2, city, state, postalCode, country, add } = Lang.enterCardDetails;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Text
                            onPress={() => this.props.navigation.navigate("BankAccount")}
                            style={{ color: '#355c7d', fontSize: 12 }}>
                            {cancel}
                        </Text>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ top: 20 }}>
                        <Text style={{ marginLeft: 5, fontSize: 15 }}>
                            {subTitle}
                        </Text>
                        <View style={{ marginTop: 20 }}>
                            <View style={styles.textInputView}>
                                <View style={{ flex: 1, justifyContent: 'center' }}>
                                    <Text style={styles.textView}>
                                        {name}
                                    </Text>
                                </View>
                            </View>
                            <View style={styles.textInputView}>
                                <View style={{ flex: 1, justifyContent: 'center' }}>
                                    <Text style={styles.textView}>
                                        {surName}
                                    </Text>
                                </View>
                            </View>
                            <View style={styles.textInputView}>
                                <View style={{ flex: 1, justifyContent: 'center' }}>
                                    <Text style={styles.textView}>
                                        {cardNumber}
                                    </Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ justifyContent: 'space-between', marginTop: 20, flexDirection: 'row', alignItems: 'center' }}>
                            <View style={[styles.textInputView, { flex: 0.4 }]}>
                                <Text style={styles.textView}>
                                    {expireDate}
                                </Text>
                            </View>
                            <View style={[styles.textInputView, { flex: 0.4 }]}>
                                <Text style={styles.textView}>
                                    {securityCode}
                                </Text>
                            </View>
                        </View>
                        <View style={{ top: 20 }}>
                            <Text style={{ marginLeft: 5, fontSize: 15 }}>
                                {addressLinkedToYourCard}
                            </Text>
                            <View style={{ marginTop: 20 }}>
                                <View style={styles.textInputView}>
                                    <View style={{ flex: 1, justifyContent: 'center' }}>
                                        <Text style={styles.textView}>
                                            {address1}
                                        </Text>
                                    </View>
                                </View>
                                <View style={styles.textInputView}>
                                    <View style={{ flex: 1, justifyContent: 'center' }}>
                                        <Text style={styles.textView}>
                                            {address2}
                                        </Text>
                                    </View>
                                </View>
                                <View style={styles.textInputView}>
                                    <View style={{ flex: 1, justifyContent: 'center' }}>
                                        <Text style={styles.textView}>
                                            {city}
                                        </Text>
                                    </View>
                                </View>
                                <View style={styles.textInputView}>
                                    <View style={{ flex: 1, justifyContent: 'center' }}>
                                        <Text style={styles.textView}>
                                            {state}
                                        </Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                    <Button
                        onPress={() => this.onPressItem()}
                        style={styles.addButton}>
                        <Text>{add}</Text>
                    </Button>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    inputContainer: {
        justifyContent: 'center',
        height: 18,
        backgroundColor: '#fff',
        width: 222.5,
        borderBottomWidth: 1,
        borderBottomColor: '#D5D5D7',
    },
    input: {
        paddingLeft: 10,
        color: "#000",
        fontSize: 10,
        fontStyle: "normal",
        letterSpacing: 0,
    },
    textInputView: {
        height: 38, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: 'lightgray', flexDirection: 'row', alignItems: 'center'
    },
    textView: {
        paddingLeft: 5, alignItems: 'center', justifyContent: 'center', color: '#000', fontSize: 12
    },
    addButton: {
        width: 113,
        height: 50.5,
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'center',
        marginTop: 75
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 30,
        marginBottom: 10
    },
});