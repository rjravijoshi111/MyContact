import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { connect } from 'react-redux';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TextInput, Keyboard } from "react-native";
import { oldPasswordChanged, newPasswordChanged, newPasswordRepeatChanged, setPasswordChangeError } from "../../../modules/settings/settings.action";
import { changePassword } from '../../../modules/settings/settings.service';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import { validatechangePassword } from '@src/config/Validation';
const { height, width } = Dimensions.get("window");
class ChangePassword extends React.Component {

    onPress = () => {
        // const { passwordIncorrect } = Lang.changePassword;
        // this.awesomAlert.simpleAlert("", passwordIncorrect, () => console.log("Test"))
        const { old_password, new_password, new_password_repeat } = this.props;

        const fields = { old_password, new_password, new_password_repeat };
        const result = validatechangePassword(fields, this.awesomAlert);
        if (result) {
            this.props.changePassword(old_password, new_password);
            // .then(() => {
            // this.awesomAlert.simpleAlert("", "Password update successfully", () => this.props.navigation.navigate("Settings"));
            // });
        }
    }

    componentWillReceiveProps(newProps) {
        if (newProps.passwordChangedSuccessfully) {
            this.awesomAlert.simpleAlert("", "Password update successfully", () => {
                this.props.setPasswordChangeError(null);
                newProps.navigation.goBack()
            });
        }
    }

    oldPasswordChanged(text) {
        this.props.oldPasswordChanged(text);
    }

    newPasswordChanged(text) {
        this.props.newPasswordChanged(text);
    }

    newPasswordRepeatChanged(text) {
        this.props.newPasswordRepeatChanged(text);
    }

    render() {
        const { title, save, currentPassword, newPassword, confirmNewPassword } = Lang.changePassword;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                />
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.navigate("Settings")}>
                            <Icon name="arrow-back" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ marginTop: 10 }}>
                        <View style={{ marginTop: 20 }}>
                            <Text style={{ margin: 5, fontSize: 15, color: '#000' }}>
                                {currentPassword}
                            </Text>
                            <View style={styles.inputContainer}>
                                <TextInput style={styles.input}
                                    placeholder={""}
                                    onChangeText={this.oldPasswordChanged.bind(this)}
                                    value={this.props.old_password}
                                    returnKeyType='next'
                                    submitSubscriber={() => this.inputNewPassword.textInput.focus()}
                                />
                            </View>
                        </View>
                        <View style={{ marginTop: 20 }}>
                            <Text style={{ margin: 5, fontSize: 15, color: '#000' }}>
                                {newPassword}
                            </Text>
                            <View style={styles.inputContainer}>
                                <TextInput style={styles.input}
                                    placeholder={""}
                                    onChangeText={this.newPasswordChanged.bind(this)}
                                    value={this.props.new_password}
                                    ref={input => (this.inputNewPassword = input)}
                                    returnKeyType='next'
                                    submitSubscriber={() => this.inputNewRepeatPassword.textInput.focus()}
                                />
                            </View>
                        </View>
                        <View style={{ marginTop: 20 }}>
                            <Text style={{ margin: 5, fontSize: 15, color: '#000' }}>
                                {confirmNewPassword}
                            </Text>
                            <View style={styles.inputContainer}>
                                <TextInput style={styles.input}
                                    placeholder={""}
                                    onChangeText={this.newPasswordRepeatChanged.bind(this)}
                                    value={this.props.new_password_repeat}
                                    ref={input => (this.inputNewRepeatPassword = input)}
                                    returnKeyType='done'
                                    submitSubscriber={() => Keyboard.dismiss()}
                                />
                            </View>
                        </View>
                        <Button style={styles.saveButton} onPress={this.onPress}>
                            <Text style={{ fontSize: 15, color: "#fff" }}>{save}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}

const mapStateToProps = state => ({
    old_password: state.settings.old_password,
    new_password: state.settings.new_password,
    new_password_repeat: state.settings.new_password_repeat,
    passwordChangedSuccessfully: state.settings.passwordChangedSuccessfully
});


const mapDispatchToProps = dispatch => ({
    changePassword: (oldPassword, newPasseord) => dispatch(changePassword(oldPassword, newPasseord)),
    oldPasswordChanged: (password) => dispatch(oldPasswordChanged(password)),
    newPasswordChanged: (password) => dispatch(newPasswordChanged(password)),
    newPasswordRepeatChanged: (password) => dispatch(newPasswordRepeatChanged(password)),
    setPasswordChangeError: (err) => dispatch(setPasswordChangeError(err)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ChangePassword);

const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    saveButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 80
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogTextTitle:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginTop: 10
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row' },
    alertDialogText:
    {
        fontSize: 12, color: '#434546', fontFamily: 'Roboto', marginVertical: 10
    },
    inputContainer: {
        justifyContent: 'center',
        height: 38,
        backgroundColor: '#fff',
        width: "100%",
        borderBottomWidth: 1,
        borderBottomColor: '#D5D5D7',
    },
    input: {
        paddingLeft: 10,
        color: "#000",
        fontSize: 10,
        fontStyle: "normal",
        letterSpacing: 0,
    },
});