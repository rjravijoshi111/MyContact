import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, FlatList, TouchableOpacity, TextInput } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");
export default class BankAccountDetails extends React.Component {

    onPress = () => {
        const { alertDialogWarning } = Lang.bankAccountDetails;
        this.awesomAlert.simpleAlert("", alertDialogWarning, () => this.props.navigation.navigate("BankAccountDetails"))
    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }

    render() {
        const { title, fillInformation, cancel, bankName, beneficiary, clabAccount, addressRelatedAccount, address1, address2, city, state, postalCode, country, add, alertDialogConfirm, thankYou } = Lang.bankAccountDetails;
        return (
            <Container>
                <AlertDialog ref={ref => (this.awesomAlert = ref)}>
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 30 }}>
                        <Image source={images.image_cuenta_con_sombra} style={{ height: 61.5, width: 65.5 }} resizeMode={"contain"} />
                        <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {thankYou}</Text>
                        <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> {alertDialogConfirm}</Text>
                        <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                            <Text style={{ alignItems: 'center' }}>OK</Text>
                        </Button>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Text
                            onPress={() => this.props.navigation.navigate("BankAccount")}
                            style={{ color: '#355c7d', fontSize: 12 }}>
                            {cancel}
                        </Text>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ top: 20 }}>
                        <Text style={{ marginLeft: 5, fontSize: 15 }}>
                            {fillInformation}
                        </Text>
                        <View style={{ marginTop: 20 }}>
                            <View style={styles.textView}>

                                <Text style={styles.textStyle}>
                                    {bankName}
                                </Text>

                            </View>
                            <View style={styles.textView}>

                                <Text style={styles.textStyle}>
                                    {beneficiary}
                                </Text>

                            </View>
                            <View style={styles.textView}>

                                <Text style={styles.textStyle}>
                                    {clabAccount}
                                </Text>

                            </View>
                        </View>
                        <View style={{ top: 20 }}>
                            <Text style={{ marginLeft: 5, fontSize: 15 }}>
                                {addressRelatedAccount}
                            </Text>
                            <View style={{ marginTop: 20 }}>
                                <View style={styles.textView}>

                                    <Text style={styles.textStyle}>
                                        {address1}
                                    </Text>

                                </View>
                                <View style={styles.textView}>

                                    <Text style={styles.textStyle}>
                                        {address2}
                                    </Text>

                                </View>
                                <View style={styles.textView}>

                                    <Text style={styles.textStyle}>
                                        {city}
                                    </Text>

                                </View>
                                <View style={styles.textView}>

                                    <Text style={styles.textStyle}>
                                        {state}
                                    </Text>

                                </View>
                                <View style={styles.textView}>

                                    <Text style={styles.textStyle}>
                                        {postalCode}
                                    </Text>
                                </View>
                                <View style={styles.textView}>
                                    <Text style={styles.textStyle}>
                                        {country}
                                    </Text>
                                </View>
                            </View>
                        </View>
                    </View>
                    <Button
                        onPress={() => this.onPressItem()}
                        style={styles.addButton}>
                        <Text>{add}</Text>
                    </Button>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    inputContainer: {
        justifyContent: 'center',
        height: 18,
        backgroundColor: '#fff',
        width: 222.5,
        borderBottomWidth: 1,
        borderBottomColor: '#D5D5D7',
    },
    input: {
        paddingLeft: 10,
        color: "#000",
        fontSize: 10,
        fontStyle: "normal",
        letterSpacing: 0,
    },
    textView: {
        height: 38, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: 'lightgray', flexDirection: 'row', alignItems: 'center'
    },
    textStyle:
    {
        paddingLeft: 5, alignItems: 'center', justifyContent: 'center', color: '#000', fontSize: 12
    },
    addButton: {
        width: 113,
        height: 50.5,
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'center',
        marginTop: 75
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 30,
        marginBottom: 25
    },
});