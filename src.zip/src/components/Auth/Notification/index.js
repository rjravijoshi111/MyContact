import React from 'react';
import { createStackNavigator } from "react-navigation";
import NotificationOfPassengerRouteConfirmed from './NotificationOfPassengerRouteConfirmed';
import NotificationsOfPassenger from './NotificationsOfPassenger';
import RequestAccepted from './RequestAccepted';
import SendRequestToDriver from './SendRequestToDriver';

export default createStackNavigator(

    {
        NotificationsOfPassenger: {
            screen: NotificationsOfPassenger
        },
        NotificationOfPassengerRouteConfirmed: {
            screen: NotificationOfPassengerRouteConfirmed
        },
        RequestAccepted: {
            screen: RequestAccepted
        },
        SendRequestToDriver: {
            screen: SendRequestToDriver
        }
    },
    {
        initialRouteName: 'NotificationsOfPassenger',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }

);