import React, { Component } from 'react';
import { View, StyleSheet, Dimensions, Image, Text, TouchableOpacity, FlatList, TextInput } from 'react-native';
import Lang from '@src/config/localization';
import { Container, Header, Title, Left, Right, Icon, Button, Body, Content } from "native-base";
let screenWidth = Dimensions.get('screen').width;
import { AlertDialog, ListItem } from '@comman';
let barWidth = screenWidth - 170;
let screenHeight = Dimensions.get('screen').height;
import images from "@src/config/path/Images";
import StarRating from 'react-native-star-rating';
import { Rating, AirbnbRating } from 'react-native-ratings';

let _this = null;
let TAG = "==:== Notification : "

class Notifications extends Component {

    constructor(props) {
        super(props);
        _this = this;
        console.log(TAG, "==" + JSON.stringify(props));
        this.state = {
            notifications: [{
                id: '1',
                text: '¡Tu ruta con Andrés ha sido cancelada! Haz click aquí para obtener más detalles y encontrar un nuevo match.',
                date: '28/07'
            }, {
                id: '2',
                text: '¡Andrés tiene un asiento disponible para ti! Resérvalo ahora.',
                date: '23/07'
            }, {
                id: '3',
                text: '¡Hay nuevos usuarios a tu alrededor! Descúbrelos ahora.',
                date: '21/07'
            }, {
                id: '4',
                text: 'Andres no aceptó tu solicitud.',
                date: '19/07'
            }, {
                id: '5',
                text: '¡Tu ruta con Andrés está confirmada! Haz click aquí para obtener más detalles.',
                date: '10/07'
            }, {
                id: '6',
                text: '¡Andrés está esperando su calificación! Haz click aquí para proceder',
                date: '10/07'
            }]
        }
    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }
    onStarRatingPress(rating) {
        _this.setState({
            starCount: rating
        });
    }

    rateYourDriver = () => {
        const { rateYourDriver, starDeserve, submit, later, commentYourExperience } = Lang.notification;
        let SimpleView = (<View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
            <Image source={images.icono_como_funciona} style={{ height: 66.5, width: 59 }} resizeMode={"contain"} />
            <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {rateYourDriver}</Text>
            <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> {starDeserve}</Text>

            <StarRating
                disabled={false}
                emptyStar={'ios-star-outline'}
                fullStar={'ios-star'}
                halfStar={'ios-star-half'}
                iconSet={'Ionicons'}
                maxStars={5}
                rating={this.state.starCount}
                selectedStar={(rating) => this.onStarRatingPress(rating)}
                fullStarColor={'yellow'}
            />
            <Text style={{ width: "100%", color: '#000', fontSize: 12, marginVertical: 5 }}>
                {commentYourExperience}
            </Text>

            <TextInput style={styles.input}
                multiline
            ></TextInput>

            <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                <Text style={{ alignItems: 'center', color: '#fff' }}>{submit}</Text>
            </Button>
            <Text style={{ alignItems: 'center', color: "#355c7d" }}>{later}</Text>
        </View>)
        this.awesomAlert.customeAlert(SimpleView)
    }

    _renderItem({ item }) {
        return (
            <View>
                <TouchableOpacity
                    onPress={() => _this.rateYourDriver()}
                    // onPress={() => _this.props.navigation.navigate('NotificationOfPassengerRouteConfirmed')} key={item.id}
                    style={{ padding: screenWidth * 0.03 }}>
                    <View style={{ alignItems: 'flex-end' }}>
                        <Text style={{ fontSize: screenWidth * 0.025 }}>{item.date}</Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                            <Image style={{ height: screenWidth * 0.085, width: screenWidth * 0.085 }} source={images.notification_profile_guigo} />
                        </View>
                        <View style={{ justifyContent: 'center' }}>
                            <Text style={{ width: screenWidth * 0.80, fontSize: screenWidth * 0.035, marginLeft: screenWidth * 0.03, textAlign: 'left', color: '#000' }}>{item.text}</Text>
                        </View>
                    </View>
                </TouchableOpacity>
                <View style={{ backgroundColor: 'rgb(67,69,70)', height: screenHeight * 0.001 }} />
            </View>
        )
    }

    render() {
        const { title, no_notification , tripCancle, information, searhFor, later } = Lang.notification;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                >
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
                        <Image source={images.oops} style={{ height: 32.5, width: 137 }} resizeMode={"contain"} />
                        <Text style={{ fontSize: 15, color: '#355c7d', paddingVertical: 20 }}> {tripCancle}</Text>
                        <Text style={{ fontSize: 12, color: '#000000', textAlign: 'center' }}> {information}</Text>
                        <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                            <Text style={{ alignItems: 'center', color: '#fff' }}>{searhFor}</Text>
                        </Button>
                        <Text style={{ alignItems: 'center', color: "#355c7d" }}>{later}</Text>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    {(this.state.notifications.length == 0) ?
                        <View style={{ flex: 1 }}>
                            <View style={{ height: screenHeight * 0.50, width: screenWidth, justifyContent: 'flex-end', alignItems: 'center' }}>
                                <Image resizeMode={'contain'} style={{ height: screenWidth * 0.60, width: screenWidth * 0.60 }} source={images.notification_bell} />
                            </View>
                            <View style={{ height: screenHeight * 0.20, justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{ width: screenWidth * 0.80, fontSize: screenWidth * 0.04, textAlign: 'center', color: '#000' }}>{no_notification}</Text>
                            </View>
                        </View> :
                        <View style={{ flex: 1, paddingTop: screenHeight * 0.02 }}>
                            <FlatList
                                data={this.state.notifications}
                                renderItem={this._renderItem}
                                keyExtractor={(item, index) => item.id} />
                        </View>}
                </Content>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 30,
        marginBottom: 10
    },
    input: {
        borderColor: '#000',
        borderWidth: 0.5,
        paddingLeft: 10,
        width: 250,
        height: 69,
        color: "#000",
        fontSize: 10,
        fontStyle: "normal",
        letterSpacing: 0,
    },
});

export default Notifications;

