import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { DrawerActions } from 'react-navigation';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, ImageBackground, StyleSheet, View, Image, TouchableOpacity } from "react-native";
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";

const { height, width } = Dimensions.get("window");

let _this = null
export default class InviteFriend extends React.Component {

    constructor(props) {
        super(props);
        _this = this
        this.state = {
            isLinkCopy: false
        }
    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }
    render() {
        const { title, message, invitation, findingDriver, surprisesAndReward, inviteYourFriend, copyLink } = Lang.inviteFriend;
        return (
            <Container>
                <AlertDialog ref={ref => (this.awesomAlert = ref)}>
                    <View >
                        <Text style={{ color: '#355c7d', fontSize: 12 }} onPress={() => this.awesomAlert.setModalVisible(false)}>
                            cancel
                        </Text>
                        <View style={styles.alertDialogView}>
                            <View style={{ padding: 5 }}>
                                <Image source={images.inviteFriend} style={{ height: 87, width: 114 }} resizeMode={"cover"} />
                            </View>
                            <Text style={styles.alertDialogText} >
                                {inviteYourFriend}
                            </Text>
                            <TouchableOpacity
                                onPress={() => _this.setState({ isLinkCopy: true })}
                                style={{ padding: 5, alignItems: 'center', justifyContent: 'center', marginBottom: 40 }}>
                                <Image source={images.shareIcon} style={{ height: 87.5, width: 87.5 }} resizeMode={"cover"} />
                                {this.state.isLinkCopy && <View style={{ backgroundColor: '#ebebeb', position: 'absolute', height: 26, width: 201.5, opacity: 0.9 }}>
                                    <Text style={{ color: '#000', textAlign: 'center', alignSelf: 'center' }}>{copyLink}</Text>
                                </View>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={styles.content}>
                        <View style={{ alignItems: 'center' }}>
                            <Image source={images.inviteFriend} style={styles.images} resizeMode={"contain"} />
                            <Text style={styles.titleText}>{message}</Text>
                        </View>
                        <View style={[styles.subTitleView, { marginTop: 60 }]}>
                            <Image source={images.thumbsup} style={{ height: 23.5, width: 23.5 }} resizeMode={"contain"} />
                            <Text style={styles.subTitleText}>{invitation}</Text>
                        </View>
                        <View style={styles.subTitleView}>
                            <Image source={images.thumbsup} style={{ height: 23.5, width: 23.5 }} resizeMode={"contain"} />
                            <Text style={styles.subTitleText}>{findingDriver}</Text>
                        </View>
                        <View style={styles.subTitleView}>
                            <Image source={images.thumbsup} style={{ height: 23.5, width: 23.5 }} resizeMode={"contain"} />
                            <Text style={styles.subTitleText}>{surprisesAndReward}</Text>
                        </View>
                        <Button style={styles.inviteFriendButton} onPress={this.onPressItem}>
                            <Text>{title}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        );
    }
}
const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    content: {
        height: height - 150, justifyContent: 'center'
    },
    images: {
        height: 121.5, width: 121.5, alignItems: 'center'
    },
    subTitleView: { flexDirection: 'row', margin: 10, alignItems: 'center' },
    titleText: {
        marginHorizontal: 30,
        fontFamily: 'Roboto', fontWeight: 'bold', fontSize: 18, marginTop: 20, color: '#355c7d', textAlign: 'center'
    },
    subTitleText: {
        fontFamily: 'Roboto', fontSize: 12, marginHorizontal: 10, justifyContent: 'center', color: '#000'
    },
    inviteFriendButton: {
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        marginTop: 50
    },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
    alertDialogText:
    {
        fontSize: 15, color: '#355c7d', fontFamily: 'Roboto', marginVertical: 30
    },
});