import React from 'react';
import { createStackNavigator } from "react-navigation";

import InviteFriend from './InviteFriend';

export default createStackNavigator(

    {
        InviteFriend: {
            screen: InviteFriend
        }
    },
    {
        initialRouteName: 'InviteFriend',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);