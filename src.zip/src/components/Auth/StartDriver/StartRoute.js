import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem } from "native-base";
import Lang from '@src/config/localization';
import { AlertDialog, ListItem } from '@comman';
import { Dimensions, FlatList, StyleSheet, View, Image, TouchableOpacity, TextInput } from "react-native";
import StarRating from 'react-native-star-rating';
import colors from '@src/config/Colors';
import images from "@src/config/path/Images";
import Ionicons from 'react-native-vector-icons/Ionicons'
const { height, width } = Dimensions.get("window");
export default class StartRoute extends React.Component {
    constructor(props) {
        super(props);
        const { discriminatoryLanguage, misconduct, bullying, strayObject, anotherReason, registeredReport, text1, text2 } = Lang.routeTransformer;
        this.state = {
            selectRoute: 1,
            myReviewsList: [1, 2, 3],
            alertDialogList: [{ title: discriminatoryLanguage, isSelected: false },
            { title: misconduct, isSelected: false },
            { title: bullying, isSelected: false },
            { title: strayObject, isSelected: false },
            { title: anotherReason, isSelected: false }],
        }
    }

    _renderItem = (item) => {
        const { reportProblem } = Lang.routeTransformer;
        return (
            <ListItem navigation={this.onPressItem} buttonText={reportProblem} buttonColor={"#f81a00"} />
        )
    }


    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }

    render() {
        const { myHistory } = Lang.myHistory;
        const { activateLocation, configurationLocation, cancel, activate, noScheduled } = Lang.StartDriver;

        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}>
                    <View>
                        <View style={styles.alertDialogView}>
                            <Text >
                                {activateLocation}
                            </Text>
                            <View style={{ backgroundColor: '#000', width: 200, height: 1, margin: 5 }} />
                            <Text>
                                {configurationLocation}
                            </Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <Button style={[styles.inviteFriendButton, { backgroundColor: "#fff" }]} onPress={() => this.awesomAlert.setModalVisible(false)}>
                                <Text style={{ color: '#355c7d' }}>{cancel}</Text>
                            </Button>
                            <Button style={styles.inviteFriendButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                                <Text>{activate}</Text>
                            </Button>
                        </View>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{myHistory}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ alignItems: 'center', marginTop: 50 }}>
                        <Image source={images.image_start_con_sombra} style={{ justifyContent: 'center', flex: 1, width: 179.5, height: 133, resizeMode: 'cover' }} />
                        <View style={{ marginTop: 80 }}>
                            <Text>
                                {noScheduled}
                            </Text>
                        </View>
                        <Button style={[styles.inviteFriendButton, { marginTop: 80, height: 50.5, width: 113 }]} onPress={() => this.props.navigation.navigate("StartPath")}>
                            <Text style={{ flex: 1, textAlign: 'center' }}>Ok</Text>
                        </Button>
                    </View>
                    {/* <View>
                        <FlatList
                            style={{ backgroundColor: 'transparent' }}
                            data={this.state.alertDialogList}
                            renderItem={this._renderItem}
                            // ListEmptyComponent={this._ListEmptyComponent}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </View> */}
                </Content>
            </Container>
        )
    }
}
const styles = StyleSheet.create({
    content: {
        height: height - 130, alignItems: 'center', justifyContent: 'center'
    },
    images: {
        height: 125, width: 227
    },
    selectRoute: {
        borderRadius: 0,
        height: 30,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 30
    },
    title: { marginTop: 15, color: '#355c7d', fontSize: 15, fontWeight: 'bold' },
    alertDialogView: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    alertDialogList:
        { marginTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
    alertDialogText:
    {
        fontSize: 12, color: '#010101', fontFamily: 'Roboto'
    },
    inviteFriendButton: {
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        justifyContent: 'flex-end',
        margin: 15
    },
});
