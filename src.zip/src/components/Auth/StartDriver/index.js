import React from 'react';
import { createStackNavigator, createAppContainer } from "react-navigation";
import StartRoute from './StartRoute';
import StartPath from './StartPath';
const navigator = createStackNavigator(

    {
        StartRoute: {
            screen: StartRoute
        },
        StartPath: {
            screen: StartPath
        }
    },
    {
        initialRouteName: 'StartPath',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);

export default createAppContainer(navigator);
