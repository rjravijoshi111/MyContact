import React, { Component } from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Text, Body, Content, View, Card, List } from "native-base";
import Lang from '@src/config/localization';
import { PassengerLogo, AlertDialog } from '@comman';
import { Dimensions, StyleSheet, Image, TouchableOpacity, Alert, FlatList } from "react-native";
import images from "@src/config/path/Images";
import { connect } from "react-redux";
import MapView from 'react-native-maps';
const { height, width } = Dimensions.get("window");

class StartPath extends Component {

    constructor(props) {
        super(props);
        this.state = {
            image_url: images.passenger
        }
    }

    onPress = () => {
        this.waitDriver.customeAlert()
    }

    confirmationAlert = () => {
        this.waitDriver.setModalVisible(false)
        this.cancelTripConfirmation.customeAlert()
    }

    onPressYescancelTripAlert() {
        this.cancelTripConfirmation.setModalVisible(false)
        this.cancelTrip.customeAlert()
    }


    waitDriverAlert() {
        const { cancel, waitForPassenger, notTherePassenger, cancelTrip, submitMessage } = Lang.StartDriver;
        const { yes, no } = Lang.common;
        return (
            <AlertDialog
                ref={ref => (this.waitDriver = ref)}
            >
                <View style={{ alignItems: 'flex-end' }}>
                    <Text
                        onPress={() => this.waitDriver.setModalVisible(false)}
                        style={[styles.label, { color: '#355c7d' }]}>
                        {cancel}
                    </Text>
                </View>
                <View style={styles.rejectAlertView}>
                    <Image source={images.image_punto_de_llegada_con_sombra} style={styles.waitDriverAlertView} resizeMode={"contain"} />
                    <Text style={styles.title}>{waitForPassenger}</Text>
                    <Text style={styles.subTitle}>{notTherePassenger}</Text>
                    <View style={{ marginTop: 10 }}>
                        <Button style={styles.yesButton} onPress={() => this.waitDriver.setModalVisible(false)}>
                            <Text style={[styles.label, { fontWeight: 'bold' }]}>{yes}</Text>
                        </Button>
                        <Text style={styles.noButton} onPress={() => this.confirmationAlert()}>{cancelTrip}</Text>
                    </View>
                </View>
            </AlertDialog>
        )
    }

    cancelTripConfirmationAlert() {
        const { yourTripCancle } = Lang.StartDriver;
        const { yes, no } = Lang.common;
        return (<AlertDialog
            ref={ref => (this.cancelTripConfirmation = ref)}
        >
            <View style={{ alignItems: 'center' }}>
                <Text style={styles.title}>{yourTripCancle}</Text>
                <View style={styles.divider} />
                <View style={styles.cancelTripConfirmationAlertView}>
                    <Text style={styles.cancelTripConfirmationAlertText} onPress={() => this.onPressYescancelTripAlert()}>{yes}</Text>
                    <View style={styles.dividerVertical} />
                    <Text style={styles.cancelTripConfirmationAlertText} onPress={() => this.cancelTripConfirmation.setModalVisible(false)}>{no}</Text>
                </View>
            </View>
        </AlertDialog >)
    }

    cancelTripAlert = () => {
        const { yourTripCancle } = Lang.StartDriver;
        return (<AlertDialog
            ref={ref => (this.cancelTrip = ref)}>
            <View style={{ alignItems: 'center' }}>
                <Text style={styles.title}>{yourTripCancle}</Text>
                <View style={styles.divider} />
                <Text style={styles.label} onPress={() => this.cancelTrip.setModalVisible(false)}>Ok</Text>
            </View>
        </AlertDialog>)
    }

    render() {
        const { countess, house, by_car, santa_fe, work } = Lang.acceptOrReject;
        const { startRoute, readyToStart } = Lang.StartDriver;
        const { yes, no } = Lang.common;
        return (
            <Container>
                {this.waitDriverAlert()}
                {this.cancelTripConfirmationAlert()}
                {this.cancelTripAlert()}
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name='arrow-back' style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{startRoute}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <View style={{ alignItems: 'center', }}>
                        {/* <Mapbox.MapView
                            // styleURL={Mapbox.StyleURL.Street}
                            zoomLevel={15}
                            centerCoordinate={[11.256, 43.770]}
                            style={{height: 200, width:'100%' }}>
                        </Mapbox.MapView> */}
                        <MapView
                            initialRegion={{
                                latitude: 37.78825,
                                longitude: -122.4324,
                                latitudeDelta: 0.0922,
                                longitudeDelta: 0.0421,
                            }}
                            style={{ height: 300, width: '100%' }}
                        />
                    </View>

                    <View style={styles.viewContainer}>
                        <Image source={images.barra_RUUTA} style={styles.imageView} resizeMode={"contain"} />
                        <View style={styles.childView}>
                            <Text style={[styles.label]}>
                                {countess + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {house}
                                </Text>
                            </Text>

                            <Text style={[styles.label, styles.label3]}>
                                {by_car}
                            </Text>

                            <Text style={[styles.label]}>
                                {santa_fe + " - "}
                                <Text style={[styles.label2, styles.label]}>
                                    {work}
                                </Text>
                            </Text>
                        </View>
                    </View>
                    <View style={styles.readyToStartView}>
                        <Text style={{ fontSize: 12 }}>
                            {readyToStart}
                        </Text>
                    </View>
                    <View style={styles.buttonViewContainer}>
                        <Button style={styles.startPathButton} onPress={() => this.onPress()}>
                            <Text style={[styles.label, { fontWeight: 'bold' }]}>{no}</Text>
                        </Button>
                        <Button style={styles.startPathButton}>
                            <Text style={[styles.label, { fontWeight: 'bold' }]}>{yes}</Text>
                        </Button>
                    </View>
                </Content>
            </Container>
        )
    }
}

const mapStateToProps = state => ({
    user: state.profile.user,
    loading: state.auth.loading,
    unique_person: state.auth.unique_person
});

const mapDispatchToProps = dispatch => ({

});
export default connect(mapStateToProps)(StartPath);

const styles = StyleSheet.create({
    viewContainer: { flexDirection: 'row', marginHorizontal: 10 },
    childView: { flexDirection: 'column', margin: 10, flex: 1, justifyContent: 'space-between' },
    imageView: { height: 120, width: 10, marginVertical: 10 },
    readyToStartView: { marginTop: 30, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', height: 20 },
    buttonViewContainer: { marginTop: 30, flexDirection: 'row', justifyContent: 'space-around' },
    label: {
        fontSize: 12,
        fontWeight: 'normal',
    },
    label2: {
        color: '#355c7d',
        fontWeight: 'bold'
    },
    label3: {
        color: '#000', fontSize: 7
    },
    startPathButton: {
        width: 113,
        height: 50,
        borderRadius: 0,
        justifyContent: 'center',
        alignSelf: 'center',
        // justifyContent: 'center',
        // marginTop: 30
    },
    title: {
        fontSize: 15, color: '#355c7d', fontWeight: 'bold'
    },
    subTitle: {
        textAlign: 'center',
        marginVertical: 40,
        fontSize: 12,
    },
    yesButton: {
        borderRadius: 0, width: 100, alignItems: 'center', justifyContent: 'center'
    },
    noButton: {
        textAlign: 'center', fontSize: 9, textDecorationLine: 'underline', color: '#355c7d', marginTop: 10
    },
    rejectAlertView: {
        alignItems: 'center'
    },
    divider: { marginVertical: 20, backgroundColor: '#d2d2d2', width: "100%", height: 2 },
    dividerVertical: { backgroundColor: '#000', height: 50, width: 1, marginHorizontal: 50, alignSelf: 'center' },
    waitDriverAlertView: { height: 57, width: 120.5, margin: 10 },
    cancelTripConfirmationAlertView: { flexDirection: 'row', alignItems: 'center' },
    cancelTripConfirmationAlertText: { alignItems: 'center', color: '#000', textAlign: 'center' },
});

