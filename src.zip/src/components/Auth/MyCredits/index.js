import React from 'react';
import { createStackNavigator } from "react-navigation";
import MyCredit from './MyCredit';

export default createStackNavigator(
    {
        MyCredit: {
            screen: MyCredit
        },
        
    },
    {
        initialRouteName: 'MyCredit',
        headerMode: 'none',
        navigationOptions: {
            headerVisible: false,
        }
    }
);