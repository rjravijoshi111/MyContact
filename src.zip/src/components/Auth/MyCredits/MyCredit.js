import React from "react";
import { Container, Header, Title, Left, Icon, Right, Button, Body, Content, Text, Card, CardItem, Picker } from "native-base";
import Lang from '@src/config/localization';

import { Dimensions, ImageBackground, StyleSheet, View, Image } from "react-native";
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import { AlertDialog } from '@comman';
import images from "@src/config/path/Images";
import { getTotalCredit } from "@modules/myCredit/myCredit.service";
import { connect } from "react-redux";
import * as AuthAction from "@modules/auth/auth.action";
const { height, width } = Dimensions.get("window");
class MyCredit extends React.Component {
    state = {
        amountList: ["50.00", "100.00", "150.00", "200.00"],
        total_credit: ''
    }

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        this.props.navigation.dispatch(AuthAction.setLoadingIndicator(true));
        this.props.getTotalCredit().then(() => {
            const TotalCredit = this.props.total_credit;
            this.setState({ total_credit: TotalCredit });
            this.props.navigation.dispatch(AuthAction.setLoadingIndicator(false));
        });
    }

    onPressItem = () => {
        this.awesomAlert.customeAlert()
    }

    render() {
        const { title, wantToBuy, currentBalanceIs, businessCoupon, credits, select_amount, confirm_the_purchase, cancel, transaction_completed, problem_in_purchase } = Lang.myCredit;
        return (
            <Container>
                <AlertDialog
                    ref={ref => (this.awesomAlert = ref)}
                >
                    <View style={{ alignItems: 'center' }}>
                        <Image source={images.cochinito} style={styles.alertDialogImage} resizeMode={"stretch"} />
                        <Text style={styles.alertDialogTitle}> {title}</Text>
                        <Text style={styles.alertDialogText}>Por favor, confirma la compra de {" " + this.state.total_credit + " "}créditos Güigo!</Text>
                        <Button style={styles.okButton} onPress={() => this.awesomAlert.setModalVisible(false)}>
                            <Text style={{ alignItems: 'center' }}>Ok</Text>
                        </Button>
                        <Text style={styles.alertDialogCancleText} onPress={() => this.awesomAlert.setModalVisible(false)}> {cancel}</Text>
                    </View>
                </AlertDialog>
                <Header>
                    <Left style={{ flex: 0.2 }}>
                        <Button
                            transparent
                            onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name="menu" style={{ color: "black" }} />
                        </Button>
                    </Left>
                    <Body>
                        <Title>{title}</Title>
                    </Body>
                    <Right style={{ flex: 0.2 }} />
                </Header>
                <Content>
                    <Text style={styles.textLable}>{wantToBuy}</Text>
                    <View style={styles.selectView}>
                        <Picker
                            mode={"dropdown"}
                            iosHeader={select_amount}
                            iosIcon={<FontAwesome name="caret-down" style={{ marginRight: 10 }} size={9} />}
                            placeholder={select_amount}
                            placeholderStyle={{ color: "#000" }}
                            selectedValue={this.state.total_credit}
                            style={{ height: 40, width: width, marginLeft: -7 }}
                            onValueChange={(itemValue, itemPosition) => this.setState({ total_credit: itemValue })}
                        >
                            <Picker.Item label={select_amount} value={"0"} />
                            {this.state.amountList.map((item, key) => {
                                return (<Picker.Item label={item + " " + credits} value={item} key={key} />)
                            })}
                        </Picker>
                    </View>
                    <Text style={styles.textLable}>{currentBalanceIs}</Text>
                    <Text style={styles.total_creditText}>{this.state.total_credit + " creadit"}</Text>
                    <Text style={styles.textLable}>{businessCoupon}</Text>
                    <View style={styles.textView}>
                        <Text style={styles.couponText}>
                            Güigo! 30Accor
                        </Text>
                    </View>
                    <Button style={styles.okButton} onPress={this.onPressItem}>
                        <Text style={{ alignItems: 'center' }}>Ok</Text>
                    </Button>
                </Content>
            </Container>
        );
    }
}

const mapStateToProps = state => ({
    total_credit: state.myCredit.total_credit
});

const mapDispatchToProps = dispatch => ({
    getTotalCredit: () => dispatch(getTotalCredit())
});

export default connect(mapStateToProps, mapDispatchToProps)(MyCredit);

const widthFactor = 0.8;
const heightFactor = widthFactor * 0.7;

const cardElevation = 4;
const styles = StyleSheet.create({
    selectView: {
        // marginHorizontal : 20,
        backgroundColor: '#fff',
        marginTop: 5
    },
    textView: {
        borderColor: '#ebbe27',
        margin: 10,
        justifyContent: 'center',
        // marginTop: 20,
        height: 39,
        borderWidth: 1
    },
    okButton: {
        justifyContent: 'center',
        width: 113, height: 50.5,
        fontFamily: 'Roboto',
        borderRadius: 0,
        alignSelf: 'center',
        marginTop: 25,
        marginBottom: 25
    },
    textLable: { fontSize: 12, color: '#000', padding: 10, marginTop: 20 },
    total_creditText: { fontSize: 42.5, color: '#ebbe27', marginTop: 15, alignSelf: 'center' },
    couponText: { fontSize: 15, color: '#020202', textAlign: 'center' },
    alertDialogTitle: { fontSize: 15, color: '#355c7d', paddingVertical: 10 },
    alertDialogImage: { height: 77.5, width: 92.5 },
    alertDialogText: { fontSize: 12, color: '#000000', textAlign: 'center' },
    alertDialogCancleText: { fontSize: 12.5, color: '#355c7d', textAlign: 'center' }
});