<!--
If you want to report a bug, you are in the right place!

Please include as much information as possible and make the issue title
as descriptive as you can.
-->

#### Expected behavior

#### Observerd behavior

#### Steps to reproduce the problem

#### Platform information

* **React Native version**:
* **Plugin version**:
* **OS**: <!-- Android / iOS -->
* **OS version**:
